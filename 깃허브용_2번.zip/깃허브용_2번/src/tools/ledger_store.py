"""SQLite store for a ledger folder (JE header/line structure of docs/data-model.md).

python -B src/tools/ledger_store.py build --input data/synthetic/2026Q2-s1
python -B src/tools/ledger_store.py info  --db data/db/2026Q2-s1.sqlite
python -B src/tools/ledger_store.py query --db data/db/2026Q2-s1.sqlite --sql "SELECT COUNT(*) AS n FROM je_header"

The store is built from the analysis input only. Answer-key folders are refused. Queries run
on a read-only connection with an authorizer that allows SELECT and nothing else.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
STORE_VERSION = "0.1.0"
INTEGER_COLUMNS = {"debit", "credit", "sequence_no", "line_no", "amount", "quantity", "unit_price",
                   "invoice_amount", "hours", "base_salary", "approved_bonus", "gross_paid",
                   "per_transaction_limit", "monthly_limit", "bid_amount", "budget"}
CORE = {
    "je_header": ("je_header.csv", "je_id"),
    "je_line": ("je_line.csv", "je_id, line_no"),
}
INDEXES = [
    "CREATE INDEX idx_header_posting ON je_header(posting_date)",
    "CREATE INDEX idx_header_type ON je_header(je_type)",
    "CREATE INDEX idx_header_user ON je_header(entered_by)",
    "CREATE INDEX idx_header_document ON je_header(document_id)",
    "CREATE INDEX idx_line_account ON je_line(account_code)",
    "CREATE INDEX idx_line_vendor ON je_line(vendor_id)",
]
VIEWS = {
    "v_journal_totals": """CREATE VIEW v_journal_totals AS
        SELECT je_id, COUNT(*) AS line_count, SUM(debit) AS debit_total, SUM(credit) AS credit_total,
               SUM(debit) - SUM(credit) AS difference FROM je_line GROUP BY je_id""",
}
READ_ACTIONS = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION,
                sqlite3.SQLITE_RECURSIVE}


def read_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, strict=True)
        rows = list(reader)
        if any(None in row or None in row.values() for row in rows):
            raise ValueError(f"{path.name} 열 개수가 맞지 않는 행이 있습니다.")
        return reader.fieldnames or [], rows


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def load_table(conn, table, fields, rows, key=None):
    kinds = {field: "INTEGER" if field in INTEGER_COLUMNS else "TEXT" for field in fields}
    columns = ", ".join(f"{quote(field)} {kinds[field]}" for field in fields)
    primary = f", PRIMARY KEY ({key})" if key else ""
    conn.execute(f"CREATE TABLE {quote(table)} ({columns}{primary})")
    prepared = [[int(row[field]) if kinds[field] == "INTEGER" and row[field] != "" else row[field]
                 for field in fields] for row in rows]
    marks = ", ".join("?" for _ in fields)
    conn.executemany(f"INSERT INTO {quote(table)} VALUES ({marks})", prepared)


def build_store(input_dir, db_path, coa_path, replace=False):
    input_dir, db_path = Path(input_dir).resolve(), Path(db_path)
    if (ROOT / "evaluator-only/labels") in input_dir.parents or input_dir == ROOT / "evaluator-only/labels":
        raise ValueError("정답표 폴더는 저장소 입력으로 사용할 수 없습니다.")
    for name in ("je_header.csv", "je_line.csv", "source_control_totals.json"):
        if not (input_dir / name).is_file():
            raise ValueError(f"{name} 파일이 없습니다.")
    if db_path.exists() and not replace:
        raise ValueError(f"이미 존재하는 저장소입니다. --replace로 다시 만드세요: {db_path}")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # Build in a scratch folder (SQLite needs to delete its journal) and copy the finished file.
    scratch = tempfile.TemporaryDirectory()
    work_path = Path(scratch.name) / "store.sqlite"
    conn = sqlite3.connect(work_path)
    try:
        conn.execute("PRAGMA foreign_keys = OFF")
        counts = {}
        fields, rows = read_rows(input_dir / "je_header.csv")
        load_table(conn, "je_header", fields, rows, key="je_id")
        counts["je_header"] = len(rows)
        fields, rows = read_rows(input_dir / "je_line.csv")
        load_table(conn, "je_line", fields, rows, key="je_id, line_no")
        counts["je_line"] = len(rows)
        fields, rows = read_rows(Path(coa_path))
        load_table(conn, "coa", fields, rows, key=quote(fields[0]))
        counts["coa"] = len(rows)
        extras = {}
        for path in sorted(input_dir.glob("*.csv")):
            if path.stem in ("je_header", "je_line"):
                continue
            fields, rows = read_rows(path)
            load_table(conn, path.stem, fields, rows)
            counts[path.stem] = len(rows)
        for statement in INDEXES + list(VIEWS.values()):
            conn.execute(statement)
        control = json.loads((input_dir / "source_control_totals.json").read_text(encoding="utf-8-sig"))
        conn.execute("CREATE TABLE control_totals (item TEXT PRIMARY KEY, value TEXT)")
        conn.executemany("INSERT INTO control_totals VALUES (?, ?)",
                         [(key, str(value)) for key, value in control.items()])
        actual = dict(zip(("journal_count", "line_count", "debit_total", "credit_total"),
                          conn.execute("""SELECT (SELECT COUNT(*) FROM je_header),
                              (SELECT COUNT(*) FROM je_line),
                              (SELECT COALESCE(SUM(debit), 0) FROM je_line),
                              (SELECT COALESCE(SUM(credit), 0) FROM je_line)""").fetchone()))
        differences = {key: actual[key] - control[key] for key in actual}
        orphans = conn.execute("""SELECT
            (SELECT COUNT(*) FROM je_line WHERE je_id NOT IN (SELECT je_id FROM je_header)),
            (SELECT COUNT(*) FROM je_header WHERE je_id NOT IN (SELECT je_id FROM je_line))""").fetchone()
        meta = {
            "store_version": STORE_VERSION,
            "source_dir": input_dir.name,
            "reconciled": str(not any(differences.values())).lower(),
            "reconciliation_differences": json.dumps(differences),
            "lines_without_header": str(orphans[0]),
            "headers_without_lines": str(orphans[1]),
            "source_sha256": json.dumps({path.name: sha256_file(path) for path in sorted(input_dir.glob("*"))
                                         if path.is_file()}),
        }
        conn.execute("CREATE TABLE meta (item TEXT PRIMARY KEY, value TEXT)")
        conn.executemany("INSERT INTO meta VALUES (?, ?)", meta.items())
        conn.commit()
    except Exception:
        conn.close()
        scratch.cleanup()
        raise
    conn.close()
    shutil.copyfile(work_path, db_path)
    scratch.cleanup()
    return {"db": str(db_path), "tables": counts, "reconciled": meta["reconciled"] == "true",
            "differences": differences}


def connect_readonly(db_path):
    conn = sqlite3.connect(f"file:{Path(db_path).resolve().as_posix()}?mode=ro&immutable=1", uri=True)
    conn.execute("PRAGMA query_only = ON")
    conn.set_authorizer(lambda action, *_: sqlite3.SQLITE_OK if action in READ_ACTIONS
                        else sqlite3.SQLITE_DENY)
    return conn


def run_query(db_path, sql, limit=200):
    text = sql.strip().rstrip(";").strip()
    if not text or ";" in text:
        raise ValueError("SELECT 문 하나만 실행할 수 있습니다.")
    if text.split(None, 1)[0].lower() not in ("select", "with"):
        raise ValueError("SELECT 문만 실행할 수 있습니다.")
    conn = connect_readonly(db_path)
    try:
        cursor = conn.execute(text)
        columns = [item[0] for item in cursor.description]
        rows = cursor.fetchmany(limit + 1)
    except sqlite3.DatabaseError as exc:
        raise ValueError(f"쿼리를 실행할 수 없습니다: {exc}") from exc
    finally:
        conn.close()
    return {"columns": columns, "rows": [list(row) for row in rows[:limit]],
            "truncated": len(rows) > limit}


def store_info(db_path):
    conn = connect_readonly(db_path)
    try:
        tables = [row[0] for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name")]
        counts = {name: conn.execute(f"SELECT COUNT(*) FROM {quote(name)}").fetchone()[0]
                  for name in tables}
        meta = dict(conn.execute("SELECT item, value FROM meta"))
    finally:
        conn.close()
    meta.pop("source_sha256", None)
    return {"tables": counts, "meta": meta}


def main():
    parser = argparse.ArgumentParser(description="원장 폴더를 읽기 전용 SQLite 저장소로 적재·조회")
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--input", type=Path, required=True)
    build.add_argument("--db", type=Path)
    build.add_argument("--coa", type=Path, default=ROOT / "data/coa/korean_coa.csv")
    build.add_argument("--replace", action="store_true")
    query = sub.add_parser("query")
    query.add_argument("--db", type=Path, required=True)
    query.add_argument("--sql", required=True)
    query.add_argument("--limit", type=int, default=200)
    info = sub.add_parser("info")
    info.add_argument("--db", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "build":
            db = args.db or ROOT / "data/db" / f"{args.input.resolve().name}.sqlite"
            result = build_store(args.input, db, args.coa, args.replace)
        elif args.command == "query":
            result = run_query(args.db, args.sql, args.limit)
        else:
            result = store_info(args.db)
    except (OSError, ValueError, KeyError, sqlite3.DatabaseError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
