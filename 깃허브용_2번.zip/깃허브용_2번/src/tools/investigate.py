"""Read-only investigation tools for the agent layer (docs/agent-design.md, layer A).

Every function opens the SQLite store through ledger_store.connect_readonly and returns plain
JSON-serialisable data. Numbers are computed here, never by the language model. Paths under
data/labels (answer keys) are refused, and nothing in this module writes to the ledger.
"""

from collections import Counter
from datetime import date, datetime
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import ledger_store  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "config/agent-review.json"
FORBIDDEN_DIRS = ("labels",)
INSTRUCTION_HINTS = ("무시", "지시", "시스템", "프롬프트", "승인하", "플래그", "ignore", "instruction",
                     "system", "prompt", "do not report")


def load_config(path=CONFIG_PATH):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def guard_path(path):
    """Refuse answer-key locations. Applies to every file the tools open."""
    parts = {part.lower() for part in Path(path).resolve().parts}
    if any(name in parts for name in FORBIDDEN_DIRS):
        raise PermissionError("정답표 폴더는 조사 도구로 열 수 없습니다.")
    return Path(path)


def mask_user(value, config):
    if not value or not config.get("mask", {}).get("users", True):
        return value
    return value[:1] + "*" * max(len(value) - 1, 1)


USER_KEYS = {"entered_by", "approved_by", "user", "users", "employee_id"}
ACCOUNT_KEYS = {"bank_account", "account_number", "account_no"}


def mask_evidence(value, config):
    """Mask user IDs and bank accounts anywhere inside a flag's evidence."""
    mask = config.get("mask", {})
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if key in USER_KEYS and mask.get("users", True):
                out[key] = ([mask_user(x, config) for x in item] if isinstance(item, list)
                            else mask_user(item, config) if isinstance(item, str) else item)
            elif key in ACCOUNT_KEYS and mask.get("bank_accounts", True) and isinstance(item, str):
                out[key] = "*" * max(len(item) - 4, 0) + item[-4:]
            else:
                out[key] = mask_evidence(item, config)
        return out
    if isinstance(value, list):
        return [mask_evidence(item, config) for item in value]
    return value


def wrap_text(value):
    """Descriptions and counterparty names are data, never instructions."""
    text = value or ""
    lowered = text.lower()
    hits = [hint for hint in INSTRUCTION_HINTS if hint in lowered]
    item = {"text": text, "trusted": False}
    if hits:
        item["instruction_like"] = True
    return item


class Investigator:
    def __init__(self, db_path, report_path=None, config=None):
        self.db = guard_path(db_path)
        self.report = None
        if report_path is not None:
            self.report = json.loads(guard_path(report_path).read_text(encoding="utf-8"))
        self.config = config or load_config()

    # --- low level -------------------------------------------------------------------
    def _rows(self, sql, params=()):
        conn = ledger_store.connect_readonly(self.db)
        try:
            cursor = conn.execute(sql, params)
            names = [item[0] for item in cursor.description]
            return [dict(zip(names, row)) for row in cursor.fetchall()]
        finally:
            conn.close()

    def _has_table(self, name):
        return bool(self._rows("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?", (name,)))

    # --- tools -----------------------------------------------------------------------
    def query_ledger(self, sql, limit=200):
        return ledger_store.run_query(self.db, sql, limit)

    def get_entry(self, je_id):
        headers = self._rows("SELECT * FROM je_header WHERE je_id = ?", (je_id,))
        if not headers:
            raise KeyError(f"전표 {je_id}가 없습니다.")
        header = headers[0]
        lines = self._rows("SELECT * FROM je_line WHERE je_id = ? ORDER BY line_no", (je_id,))
        for key in ("entered_by", "approved_by"):
            header[key] = mask_user(header.get(key), self.config)
        header["description"] = wrap_text(header.get("description"))
        for line in lines:
            line["description"] = wrap_text(line.get("description"))
        return {"je_id": je_id, "header": header, "lines": lines,
                "debit_total": sum(line["debit"] for line in lines),
                "credit_total": sum(line["credit"] for line in lines)}

    def find_similar(self, je_id, limit=None):
        limit = limit or self.config["similar_limit"]
        entry = self.get_entry(je_id)
        total = entry["debit_total"]
        vendors = sorted({line["vendor_id"] for line in entry["lines"] if line["vendor_id"]})
        description = entry["header"]["description"]["text"]
        matches = {}
        def add(rows, reason):
            for row in rows:
                if row["je_id"] != je_id:
                    matches.setdefault(row["je_id"], {"je_id": row["je_id"], "posting_date": row["posting_date"],
                                                      "reasons": []})["reasons"].append(reason)
        add(self._rows("SELECT h.je_id, h.posting_date FROM je_header h JOIN v_journal_totals t "
                       "ON t.je_id = h.je_id WHERE t.debit_total = ?", (total,)), "동일 금액")
        if description:
            add(self._rows("SELECT je_id, posting_date FROM je_header WHERE description = ?",
                           (description,)), "동일 적요")
        for vendor in vendors:
            add(self._rows("SELECT DISTINCT h.je_id, h.posting_date FROM je_line l JOIN je_header h "
                           "ON h.je_id = l.je_id WHERE l.vendor_id = ?", (vendor,)), f"동일 거래처 {vendor}")
        ranked = sorted(matches.values(), key=lambda item: (-len(item["reasons"]), item["posting_date"]))
        return {"je_id": je_id, "criteria": {"debit_total": total, "vendors": vendors},
                "matches": ranked[:limit], "match_count": len(ranked)}

    def get_user_profile(self, user):
        rows = self._rows("SELECT je_id, posting_date, entered_at, je_type, source FROM je_header "
                          "WHERE entered_by = ?", (user,))
        hours, weekdays, types = Counter(), Counter(), Counter()
        for row in rows:
            stamp = datetime.fromisoformat(row["entered_at"])
            hours[stamp.hour] += 1
            weekdays["주말" if stamp.weekday() >= 5 else "평일"] += 1
            types[row["je_type"]] += 1
        flags = Counter()
        if self.report:
            ids = {row["je_id"] for row in rows}
            for finding in self.report["findings"]:
                if finding["je_id"] in ids:
                    flags[finding["type_id"]] += 1
        return {"user": mask_user(user, self.config), "journal_count": len(rows),
                "hour_distribution": dict(sorted(hours.items())), "day_kind": dict(weekdays),
                "je_type_counts": dict(types.most_common(8)), "flag_counts": dict(flags)}

    def get_vendor_profile(self, vendor_id, reference_amount=None):
        lines = self._rows("SELECT l.je_id, l.debit, l.credit, h.posting_date FROM je_line l JOIN je_header h "
                           "ON h.je_id = l.je_id WHERE l.vendor_id = ? ORDER BY h.posting_date", (vendor_id,))
        name = None
        if self._has_table("vendor_master"):
            found = self._rows("SELECT name, business_type FROM vendor_master WHERE vendor_id = ?", (vendor_id,))
            name = found[0] if found else None
        amounts = sorted(max(line["debit"], line["credit"]) for line in lines)
        profile = {"vendor_id": vendor_id, "master": name and {"name": wrap_text(name["name"]),
                   "business_type": name["business_type"]},
                   "line_count": len(lines), "journal_count": len({line["je_id"] for line in lines}),
                   "first_date": lines[0]["posting_date"] if lines else None,
                   "last_date": lines[-1]["posting_date"] if lines else None}
        if amounts:
            n = len(amounts)
            profile["amount_quantiles"] = {"min": amounts[0], "median": amounts[n // 2],
                                           "p90": amounts[min(n - 1, int(n * 0.9))], "max": amounts[-1]}
            if reference_amount is not None:
                profile["reference_amount_rank"] = round(
                    sum(1 for value in amounts if value <= reference_amount) / n, 4)
        return profile

    def compute_stats(self, account_code, start=None, end=None):
        sql = ("SELECT substr(h.posting_date, 1, 7) AS month, COUNT(DISTINCT h.je_id) AS journals, "
               "SUM(l.debit) AS debit, SUM(l.credit) AS credit FROM je_line l JOIN je_header h "
               "ON h.je_id = l.je_id WHERE l.account_code = ?")
        params = [account_code]
        if start:
            sql += " AND h.posting_date >= ?"
            params.append(start)
        if end:
            sql += " AND h.posting_date <= ?"
            params.append(end)
        rows = self._rows(sql + " GROUP BY month ORDER BY month", params)
        return {"account_code": account_code, "months": rows,
                "total_debit": sum(row["debit"] for row in rows),
                "total_credit": sum(row["credit"] for row in rows)}

    def list_flags(self, type_id=None, min_score=0, limit=50):
        if not self.report:
            raise ValueError("리포트가 지정되지 않았습니다.")
        items = [f for f in self.report["findings"]
                 if (type_id is None or f["type_id"] == type_id) and f.get("score", 1) >= min_score]
        items.sort(key=lambda f: -f.get("score", 1))
        return {"count": len(items), "flags": items[:limit]}


def _unavailable(table):
    return {"status": "미실행(데이터 부족)", "reason": f"{table} 자료가 저장소에 없습니다."}


def _match_tax_invoice(self, je_id):
    if not self._has_table("tax_invoices"):
        return _unavailable("tax_invoices")
    entry = self.get_entry(je_id)
    doc = self._rows("SELECT document_id FROM je_header WHERE je_id = ?", (je_id,))[0]["document_id"]
    linked = self._rows("SELECT * FROM tax_invoices WHERE je_id = ? OR (doc_ref = ? AND doc_ref != '')",
                        (je_id, doc))
    for row in linked:
        row["supply_amount"] = int(row["supply_amount"] or 0)
        row["vat_amount"] = int(row["vat_amount"] or 0)
    return {"je_id": je_id, "document_id": doc, "debit_total": entry["debit_total"],
            "linked_invoices": linked, "linked_count": len(linked),
            "supply_plus_vat": [row["supply_amount"] + row["vat_amount"] for row in linked]}


def _match_bank(self, je_id, window_days=10):
    entry = self.get_entry(je_id)
    result = {"je_id": je_id, "debit_total": entry["debit_total"]}
    doc = self._rows("SELECT document_id, posting_date FROM je_header WHERE je_id = ?", (je_id,))[0]
    if self._has_table("bank_statement"):
        result["by_reference"] = self._rows("SELECT * FROM bank_statement WHERE reference = ?",
                                            (doc["document_id"],))
        result["by_amount"] = self._rows(
            "SELECT * FROM bank_statement WHERE ABS(amount) = ? AND ABS(julianday(tx_date) - julianday(?)) <= ?",
            (entry["debit_total"], doc["posting_date"], window_days))[:5]
    else:
        result["statement"] = _unavailable("bank_statement")
    if self._has_table("bank_tx"):
        result["bank_tx"] = self._rows("SELECT * FROM bank_tx WHERE je_id = ?", (je_id,))
    return result


def _write_report(self, run_dir, assessment, name="investigation_assessment.json"):
    """The only write in this module: a JSON file inside reports/<run>/. Nothing else is writable."""
    target = (Path(run_dir).resolve() / name)
    reports = (ROOT / "reports").resolve()
    if reports not in target.parents or target.suffix != ".json":
        raise PermissionError("리포트는 reports/ 아래 JSON 파일로만 저장할 수 있습니다.")
    guard_path(target)
    target.write_text(json.dumps(assessment, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"saved": str(target)}


Investigator.match_tax_invoice = _match_tax_invoice
Investigator.match_bank = _match_bank
Investigator.write_report = _write_report
