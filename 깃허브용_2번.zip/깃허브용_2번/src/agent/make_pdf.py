"""Turn the markdown report and incident dossier of one run into a single PDF (standard library only).

python -B src/agent/make_pdf.py --report-dir reports/<run>

Engines are tried in order: Chrome/Edge headless, LibreOffice, reportlab (if installed).
If none is available the HTML file is kept and the command says so. Nothing here reads answer keys.
"""

import argparse
import html
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

FONT_STACK = "'Malgun Gothic','Apple SD Gothic Neo','Noto Sans CJK KR','Noto Sans KR','NanumGothic','Noto Sans CJK SC',sans-serif"
CSS = f"""body{{font-family:{FONT_STACK};font-size:10.5pt;line-height:1.5;margin:0 8px;color:#111}}
h1{{font-size:18pt;border-bottom:2px solid #333;padding-bottom:4px}}h2{{font-size:14pt;margin-top:18px;border-bottom:1px solid #aaa}}
h3{{font-size:12pt}}code{{background:#f2f2f2;padding:0 3px;font-size:9pt;word-break:break-all}}
table{{border-collapse:collapse;margin:8px 0}}td,th{{border:1px solid #999;padding:3px 6px;font-size:9.5pt}}th{{background:#eee}}
blockquote{{border-left:4px solid #bbb;margin:8px 0;padding:2px 10px;color:#444}}li{{margin:2px 0}}"""


def inline(text):
    text = html.escape(text)
    text = re.sub(r"`([^`]*)`", r"<code>\1</code>", text)
    return re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)


def cell(text, header):
    tag = "th" if header == 0 else "td"
    nowrap = ' style="white-space:nowrap"' if re.fullmatch(r"[\d,.\-+%원 ]+", text) else ""
    return f"<{tag}{nowrap}>{inline(text)}</{tag}>"


def markdown_to_html(source):
    out, in_list, table = [], 0, []

    def close_lists(level=0):
        nonlocal in_list
        while in_list > level:
            out.append("</ul>")
            in_list -= 1

    def flush_table():
        nonlocal table
        if not table:
            return
        rows = [[cell.strip() for cell in line.strip().strip("|").split("|")] for line in table]
        rows = [row for row in rows if not all(re.fullmatch(r":?-+:?", c) for c in row)]
        out.append("<table>" + "".join(
            "<tr>" + "".join(cell(c, i) for c in row) + "</tr>"
            for i, row in enumerate(rows)) + "</table>")
        table = []

    for line in source.splitlines():
        if line.lstrip().startswith("|"):
            close_lists()
            table.append(line)
            continue
        flush_table()
        stripped = line.strip()
        if not stripped:
            close_lists()
            continue
        heading = re.match(r"(#{1,3})\s+(.*)", stripped)
        bullet = re.match(r"(\s*)[-*]\s+(.*)", line)
        if heading:
            close_lists()
            level = len(heading.group(1))
            out.append(f"<h{level}>{inline(heading.group(2))}</h{level}>")
        elif bullet:
            depth = 1 + len(bullet.group(1)) // 2
            while in_list < depth:
                out.append("<ul>")
                in_list += 1
            close_lists(depth)
            out.append(f"<li>{inline(bullet.group(2))}</li>")
        elif stripped.startswith(">"):
            close_lists()
            out.append(f"<blockquote>{inline(stripped.lstrip('> '))}</blockquote>")
        else:
            close_lists()
            out.append(f"<p>{inline(stripped)}</p>")
    flush_table()
    close_lists()
    return "\n".join(out)


def browser_candidates():
    names = ["msedge", "microsoft-edge", "google-chrome", "chrome", "chromium", "chromium-browser"]
    paths = []
    for var in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(var)
        if base:
            paths += [Path(base) / "Microsoft/Edge/Application/msedge.exe",
                      Path(base) / "Google/Chrome/Application/chrome.exe"]
    paths += [Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
              Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")]
    found = [str(p) for p in paths if p.is_file()]
    return found + [shutil.which(n) for n in names if shutil.which(n)]


def with_browser(html_path, pdf_path):
    for exe in browser_candidates():
        with tempfile.TemporaryDirectory() as profile:
            done = subprocess.run([exe, "--headless", "--disable-gpu", "--no-sandbox", f"--user-data-dir={profile}",
                                   "--no-pdf-header-footer", f"--print-to-pdf={pdf_path}", html_path.as_uri()],
                                  capture_output=True, timeout=120)
        if pdf_path.is_file() and pdf_path.stat().st_size > 0:
            return "browser"
    return None


def with_libreoffice(html_path, pdf_path):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        return None
    with tempfile.TemporaryDirectory() as profile:
        subprocess.run([exe, f"-env:UserInstallation={Path(profile).as_uri()}", "--headless", "--convert-to",
                        "pdf:writer_web_pdf_Export", "--outdir", str(pdf_path.parent), str(html_path)],
                       capture_output=True, timeout=180)
    produced = html_path.with_suffix(".pdf")
    if produced.is_file() and produced != pdf_path:
        produced.replace(pdf_path)
    return "libreoffice" if pdf_path.is_file() and pdf_path.stat().st_size > 0 else None


def with_reportlab(source, pdf_path):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        from reportlab.lib.styles import ParagraphStyle
    except ImportError:
        return None
    candidates = [r"C:\Windows\Fonts\malgun.ttf", "/Library/Fonts/NanumGothic.ttf",
                  "/System/Library/Fonts/AppleSDGothicNeo.ttc", "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
                  "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]
    for path in candidates:
        if Path(path).is_file():
            try:
                pdfmetrics.registerFont(TTFont("KR", path, subfontIndex=0) if path.endswith(".ttc") else TTFont("KR", path))
            except Exception:
                continue
            style = ParagraphStyle("b", fontName="KR", fontSize=9.5, leading=14)
            head = ParagraphStyle("h", fontName="KR", fontSize=13, leading=18, spaceBefore=8)
            story = []
            for line in source.splitlines():
                if not line.strip():
                    story.append(Spacer(1, 4))
                    continue
                text = html.escape(re.sub(r"[`*]", "", line)).replace("|", " | ")
                story.append(Paragraph(text, head if line.startswith("#") else style))
            SimpleDocTemplate(str(pdf_path), pagesize=A4).build(story)
            return "reportlab"
    return None


def build(report_dir):
    report_dir = Path(report_dir).resolve()
    parts = []
    for name in ("report.md", "investigation_dossier.md"):
        path = report_dir / name
        if path.is_file():
            parts.append(path.read_text(encoding="utf-8"))
    if not parts:
        raise FileNotFoundError("report.md가 없는 폴더입니다.")
    source = "\n\n---\n\n".join(parts)
    html_path, pdf_path = report_dir / "report.html", report_dir / "report.pdf"
    html_path.write_text(f"<!doctype html><html><head><meta charset='utf-8'><title>이상거래 검토 보고서</title>"
                         f"<style>{CSS}</style></head><body>{markdown_to_html(source)}</body></html>", encoding="utf-8")
    for engine in (lambda: with_browser(html_path, pdf_path), lambda: with_libreoffice(html_path, pdf_path),
                   lambda: with_reportlab(source, pdf_path)):
        try:
            used = engine()
        except (OSError, subprocess.SubprocessError):
            used = None
        if used:
            return {"status": "completed", "pdf": str(pdf_path), "engine": used, "html": str(html_path)}
    return {"status": "pdf_unavailable", "html": str(html_path),
            "message": "PDF 변환기(Chrome/Edge, LibreOffice, reportlab)를 찾지 못했습니다. HTML 파일을 브라우저로 열어 '인쇄 → PDF로 저장'을 사용하세요."}


def main():
    parser = argparse.ArgumentParser(description="보고서 마크다운을 PDF로 변환")
    parser.add_argument("--report-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = build(args.report_dir)
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
