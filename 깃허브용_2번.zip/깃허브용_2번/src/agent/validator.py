"""Output validator for the investigation layer (docs/agent-design.md section 4).

Drops any assessment item whose je_id is missing from the dossier, that uses a forbidden
verdict phrase, cites a number not present in the dossier, or lacks evidence references.
Dropped items and reasons are returned so the run log can record them.
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src/tools"))
import investigate  # noqa: E402

KINDS = {"error", "fraud_indicator", "legitimate_exception"}
NUMBER = re.compile(r"\d[\d,]{3,}(?:\.\d+)?")


def dossier_numbers(dossier):
    text = json.dumps(dossier, ensure_ascii=False)
    return {item.replace(",", "") for item in NUMBER.findall(text)}


def check_hypothesis(hypothesis, incident_ids, known, forbidden):
    reasons = []
    if hypothesis.get("kind") not in KINDS:
        reasons.append("가설 갈래가 오류/부정 징후/정당한 예외 중 하나가 아님")
    text = " ".join(str(hypothesis.get(key, "")) for key in ("explanation", "how_to_verify"))
    for phrase in forbidden:
        if phrase in text:
            reasons.append(f"단정 표현 '{phrase}'")
    for number in NUMBER.findall(text):
        if number.replace(",", "") not in known:
            reasons.append(f"자료철에 없는 수치 {number}")
    refs = hypothesis.get("evidence_refs") or []
    if not refs or any(ref.get("je_id") not in incident_ids for ref in refs):
        reasons.append("근거 참조(je_id)가 없거나 자료철에 없음")
    return reasons


def validate(assessment, dossier, config=None):
    config = config or investigate.load_config()
    incident_ids = {item["je_id"] for item in dossier["incidents"]}
    known = dossier_numbers(dossier)
    kept, dropped = [], []
    for incident in assessment.get("incidents", []):
        je_id = incident.get("je_id")
        if je_id not in incident_ids:
            dropped.append({"je_id": je_id, "reasons": ["자료철에 없는 전표"]})
            continue
        good = []
        for hypothesis in incident.get("hypotheses", []):
            reasons = check_hypothesis(hypothesis, incident_ids, known, config["forbidden_phrases"])
            (dropped.append({"je_id": je_id, "reasons": reasons}) if reasons else good.append(hypothesis))
        kinds = {item["kind"] for item in good}
        notes = [] if kinds == KINDS else ["세 갈래 중 일부가 검증을 통과하지 못해 비어 있음: "
                                          + ", ".join(sorted(KINDS - kinds))]
        if good:
            kept.append({**incident, "hypotheses": good, "validation_notes": notes})
    return {"kept": kept, "dropped": dropped}
