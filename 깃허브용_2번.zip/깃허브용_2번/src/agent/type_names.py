"""Natural-language names for anomaly type IDs, used only when rendering human-readable reports.

Internal IDs (A1, B5, ...) stay in JSON and code. humanize() rewrites a markdown/text report so that
standalone type IDs and category letters appear as readable Korean names.
"""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
_DATA = json.loads((ROOT / "config/type-names.json").read_text(encoding="utf-8"))
NAMES, CATEGORIES = _DATA["types"], _DATA["categories"]
_CODE = re.compile(r"(?<![A-Za-z0-9_\-/`.])([A-I][1-7])(?![A-Za-z0-9_\-])")
_CATEGORY_LIST = re.compile(r"(범주 )([A-I](?:, [A-I])*)")


def type_name(code):
    return NAMES.get(code, code)


def category_names(letters):
    return ", ".join(CATEGORIES.get(letter, letter) for letter in letters)


def humanize(text):
    text = _CATEGORY_LIST.sub(lambda m: m.group(1) + category_names(m.group(2).split(", ")), text)
    return _CODE.sub(lambda m: type_name(m.group(1)), text)


def reference_table(codes):
    """Appendix mapping names back to internal IDs, so a reader can still cross-reference JSON output."""
    rows = ["", "## 부록: 유형 코드 대조표", "", "| 유형 | 내부 코드 |", "|---|---|"]
    rows += [f"| {type_name(code)} | {code} |" for code in sorted(set(codes)) if code in NAMES]
    return rows
