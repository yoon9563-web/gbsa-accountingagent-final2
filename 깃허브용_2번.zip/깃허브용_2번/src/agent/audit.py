"""Run population reconciliation and the D4 journal balance check."""

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from uuid import uuid4
import type_names


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from detectors.ledger_rules import (
    account_combination_findings, account_direction_findings, benford_summaries,
    closing_findings, journal_amounts, repeated_reversal_findings, round_amount_findings,
)
from detectors.bank_rules import STATEMENT_COLUMNS, bank_reconciliation
from detectors.counterparty_rules import (
    EMPLOYEE_COLUMNS, VENDOR_COLUMNS, master_account_findings, new_vendor_findings,
)
from detectors.receivable_rules import closing_return_findings, turnover_findings
from detectors.trend_rules import account_break_findings, margin_findings, receivable_sync_findings
from detectors.pattern_rules import (
    description_findings, manual_entry_findings, rare_account_findings, repeated_amount_findings,
)
from detectors.tax_rules import INVOICE_COLUMNS, tax_reconciliation
from detectors.subledger_rules import ENTRY_COLUMNS, subledger_reconciliation
from detectors.review_rules import (
    A2_EXCEPTION_COLUMNS, a2_exception_evidence, approval_findings, compile_a2_exceptions,
    duplicates, near_card_limit_findings, out_of_hours, posting_date_findings,
    payroll_amount_findings, posting_order_findings, sequence_gap_findings,
    split_card_payment_findings, unit_price_findings,
)

VERSION = "0.12.0"
IMPLEMENTED = ["D4", "D1", "A2", "A6", "A4", "D2", "B2", "B6", "B3",
               "A1", "B1", "B4", "C1", "C7", "D5", "E1", "E2", "H1", "I4", "F3", "A7", "B5", "C2", "D3", "I1", "I2", "I3", "F1", "F2"]
CATALOG = ["A1", "A2", "A3", "A4", "A5", "A6", "A7", "B1", "B2", "B3", "B4", "B5", "B6",
           "C1", "C2", "C3", "C4", "C5", "C6", "C7", "D1", "D2", "D3", "D4", "D5", "D6",
           "E1", "E2", "E3", "E4", "E5", "E6", "F1", "F2", "F3", "F4", "G1", "G2", "G3", "G4", "G5",
           "H1", "H2", "H3", "I1", "I2", "I3", "I4"]
PENDING = [kind for kind in CATALOG if kind not in IMPLEMENTED]
CONTROL_FIELDS = {
    "journal_count": "전표 수",
    "line_count": "라인 수",
    "debit_total": "차변 합계",
    "credit_total": "대변 합계",
}


def read_csv(path, columns):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, strict=True)
        if not set(columns).issubset(reader.fieldnames or []):
            raise ValueError(f"{path.name} 필수 열 누락")
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError(f"{path.name} 열 개수가 맞지 않는 행 존재")
    return rows


def validate_and_reconcile(files):
    headers = read_csv(files["headers"], ["je_id"])
    lines = read_csv(
        files["lines"], ["je_id", "line_no", "account_code", "debit", "credit"]
    )
    coa = read_csv(files["coa"], ["계정코드"])
    expected = json.loads(files["control"].read_text(encoding="utf-8-sig"))
    if not isinstance(expected, dict) or any(
        type(expected.get(key)) is not int or expected[key] < 0
        for key in CONTROL_FIELDS
    ):
        raise ValueError("통제합계에는 0 이상의 정수로 된 필수 항목 4개가 필요합니다.")

    journal_ids = {row["je_id"] for row in headers}
    if len(journal_ids) != len(headers) or any(not item.strip() for item in journal_ids):
        raise ValueError("전표 헤더에 비어 있거나 중복된 전표 ID가 있습니다.")
    account_codes = {row["계정코드"] for row in coa}
    if len(account_codes) != len(coa) or "" in account_codes:
        raise ValueError("계정과목표에 비어 있거나 중복된 계정코드가 있습니다.")

    actual = dict(journal_count=len(headers), line_count=len(lines),
                  debit_total=0, credit_total=0)
    for line in lines:
        for field in ("debit", "credit"):
            line[field] = int(line[field])
            if line[field] < 0:
                raise ValueError("차변·대변 금액은 0 이상의 원화 정수여야 합니다.")
            actual[f"{field}_total"] += line[field]

    reconciliation = {
        key: {"source": expected[key], "actual": actual[key],
              "difference": actual[key] - expected[key]}
        for key in CONTROL_FIELDS
    }
    if any(row["difference"] for row in reconciliation.values()):
        return reconciliation, headers, None

    line_keys = set()
    covered_journals = set()
    for line in lines:
        je_id = line["je_id"]
        line_no = int(line["line_no"])
        key = (je_id, line_no)
        if je_id not in journal_ids or line_no < 1 or key in line_keys:
            raise ValueError("참조할 전표가 없거나 분개 라인번호가 유효하지 않습니다.")
        if line["account_code"] not in account_codes:
            raise ValueError("계정과목표에 없는 계정코드가 있습니다.")
        line_keys.add(key)
        covered_journals.add(je_id)
    if journal_ids != covered_journals:
        raise ValueError("분개 라인이 없는 전표가 있습니다.")
    return reconciliation, headers, lines


def record_input(inputs, role, path):
    if path.resolve().is_relative_to(ROOT / "evaluator-only/labels"):
        raise ValueError("평가용 정답표는 분석 입력으로 사용할 수 없습니다.")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    inputs[role] = {"path": str(path), "sha256": digest.hexdigest()}


def detect_review_rules(headers, input_dir, run_id, inputs, skipped, exceptions):
    journal_ids = {row["je_id"] for row in headers}
    findings = []
    for filename, party, document, day, amount in (
        ("supplier_invoices.csv", "vendor_id", "invoice_id", "invoice_date", "invoice_amount"),
        ("expense_claims.csv", "employee_id", "receipt_id", "expense_date", "amount"),
    ):
        try:
            path = input_dir / filename
            record_input(inputs, filename, path)
            rows = read_csv(path, ["je_id", party, document, day, amount])
            matches = list(duplicates(rows, party, document, day, amount, journal_ids))
        except (OSError, ValueError, csv.Error) as exc:
            skipped[f"D1 · {filename}"] = str(exc)
            continue
        for je_id, evidence in matches:
            findings.append(make_finding(run_id, "D1", je_id, evidence, "duplicate_document",
                                         "동일 증빙이 반복 기장됐을 가능성",
                                         "원본 증빙, 취소·재처리 이력, 실제 지급 내역을 대조하세요."))

    try:
        path = ROOT / "config/business-hours.json"
        record_input(inputs, "business_hours", path)
        matches = list(out_of_hours(headers, path))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        skipped["A2"] = str(exc)
    else:
        rules = []
        path = input_dir / "a2_exceptions.csv"
        try:
            record_input(inputs, "a2_exceptions", path)
            rules = compile_a2_exceptions(read_csv(path, A2_EXCEPTION_COLUMNS))
        except FileNotFoundError:
            skipped["A2 예외 대조"] = "일정 파일 없음. 비업무시간 입력을 검토 후보로 유지합니다."
        except (OSError, ValueError, TypeError, csv.Error):
            skipped["A2 예외 대조"] = "일정 파일을 확인할 수 없습니다. 비업무시간 입력을 검토 후보로 유지합니다."
        headers_by_id = {row["je_id"]: row for row in headers}
        for je_id, evidence in matches:
            matched = a2_exception_evidence(headers_by_id[je_id], evidence["entered_at"], rules)
            if matched:
                exceptions.append(dict(je_id=je_id, type_id="A2", evidence=evidence,
                                       matched_records=matched))
                continue
            item = make_finding(run_id, "A2", je_id, evidence, "out_of_hours",
                                "승인된 예외 작업 또는 비업무시간 입력 가능성",
                                "근무 일정, 승인 기록, 시스템 입력 이력을 대조하세요.")
            item["score"] = evidence["score"]
            findings.append(item)
    try:
        approval_matches = list(approval_findings(headers))
    except ValueError as exc:
        skipped["A6"] = str(exc)
    else:
        for je_id, evidence in approval_matches:
            findings.append(make_finding(run_id, "A6", je_id, evidence, "approval_control",
                                         "자기승인 또는 승인자 기록 누락 가능성",
                                         "독립 승인 이력과 전표 유형별 승인 요건을 대조하세요."))
    try:
        path = ROOT / "config/business-hours.json"
        record_input(inputs, "business_hours", path)
        posting_matches = list(posting_date_findings(headers, path))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        skipped["A4"] = str(exc)
    else:
        for je_id, evidence in posting_matches:
            item = make_finding(run_id, "A4", je_id, evidence, "posting_date_gap",
                                "정상적인 결산 조정 또는 전기일 입력 오류 가능성",
                                "원천 증빙, 전기 기간, 전표 입력 이력과 조정 승인 근거를 대조하세요.")
            item["score"] = evidence["score"]
            findings.append(item)
    try:
        sequence_matches = list(sequence_gap_findings(headers))
    except ValueError as exc:
        skipped["D2"] = str(exc)
    else:
        for je_id, evidence in sequence_matches:
            findings.append(make_finding(run_id, "D2", je_id, evidence, "sequence_gap",
                                         "취소·예약 전표 또는 데이터 추출 누락 가능성",
                                         "원천 번호대장과 취소·예약 이력, 추출 범위를 대조하세요."))
        try:
            order_matches = list(posting_order_findings(headers))
        except ValueError:
            skipped["D2 · 전기일 역전"] = "전기일이 누락됐거나 날짜 형식이 올바르지 않습니다."
        else:
            for je_id, evidence in order_matches:
                findings.append(make_finding(run_id, "D2", je_id, evidence, "posting_order",
                                             "소급 전기 또는 전표번호 부여 시점의 차이 가능성",
                                             "앞뒤 전표의 증빙일·전기일과 번호 부여 이력을 대조하세요."))
    for filename, columns, detector, detect, checklist in (
        ("payroll.csv", ["base_salary", "approved_bonus", "gross_paid"],
         "payroll_amount", payroll_amount_findings,
         "급여명세, 승인된 상여 및 기타 지급·공제 내역을 대조하세요."),
        ("supplier_invoices.csv", ["product_id", "unit_price"],
         "unit_price", unit_price_findings,
         "동일 상품의 규격, 계약 단가, 수량 조건과 송장 금액을 대조하세요."),
    ):
        try:
            path = input_dir / filename
            record_input(inputs, filename, path)
            rows = read_csv(path, ["je_id", *columns])
            if any(row["je_id"] not in journal_ids for row in rows):
                raise ValueError("보조자료에 원장에 없는 전표 ID가 있습니다.")
            amount_matches = list(detect(rows))
        except (OSError, ValueError, csv.Error) as exc:
            skipped[f"B3 · {filename}"] = str(exc)
            continue
        for je_id, evidence in amount_matches:
            findings.append(make_finding(run_id, "B3", je_id, evidence, detector,
                                         "별도 승인 조건 또는 금액 입력 차이 가능성", checklist))
    try:
        transaction_path = input_dir / "card_transactions.csv"
        limit_path = input_dir / "card_limits.csv"
        for role, path in (("card_transactions", transaction_path), ("card_limits", limit_path)):
            record_input(inputs, role, path)
        transactions = read_csv(transaction_path, ["je_id", "card_id", "amount"])
        limits = read_csv(limit_path, ["card_id", "per_transaction_limit"])
    except (OSError, ValueError, csv.Error) as exc:
        skipped["B2"] = skipped["B6"] = str(exc)
        return finish_findings(findings)
    try:
        policy_path = ROOT / "config/card-review.json"
        record_input(inputs, "card_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
        card_matches = list(near_card_limit_findings(
            transactions, limits, policy["near_limit_basis_points"], journal_ids
        ))
    except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        skipped["B2"] = str(exc)
    else:
        for je_id, evidence in card_matches:
            findings.append(make_finding(run_id, "B2", je_id, evidence, "near_card_limit",
                                         "한도 직하 결제 또는 정상 견적 단가 가능성",
                                         "견적서와 승인 기록을 대조하고 동일 발주에 연결된 결제를 확인하세요."))
    try:
        companies = {row["je_id"]: row.get("company_code", "") for row in headers}
        split_matches = list(split_card_payment_findings(transactions, limits, journal_ids, companies))
    except (ValueError, KeyError) as exc:
        skipped["B6"] = str(exc)
    else:
        for je_id, evidence in split_matches:
            findings.append(make_finding(run_id, "B6", je_id, evidence, "split_card_payment",
                                         "동일 발주 분할 결제 또는 정상 분할 납품 가능성",
                                         "원 발주서, 분할 납품 조건, 통합 승인 내역을 대조하세요."))
    return finish_findings(findings)


def detect_subledger(lines, input_dir, run_id, inputs, result):
    """D4 원장↔보조원장 대사. 파일이 없으면 미실행(데이터 부족)으로 표기한다."""
    skipped = result["skipped"]
    policy_path = ROOT / "config/subledger-review.json"
    try:
        record_input(inputs, "subledger_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        skipped["D4 · 보조원장 대사"] = str(exc)
        return []
    path = input_dir / policy["file"]
    if not path.exists():
        skipped["D4 · 보조원장 대사"] = f"{policy['file']} 없음 — 미실행(데이터 부족)"
        return []
    try:
        record_input(inputs, policy["file"], path)
        entries = read_csv(path, ENTRY_COLUMNS)
        matches, balances, unlinked = subledger_reconciliation(lines, entries, policy)
    except (OSError, ValueError, KeyError, csv.Error) as exc:
        skipped["D4 · 보조원장 대사"] = str(exc)
        return []
    result["subledger"] = dict(entry_count=len(entries), balances=balances, unlinked=unlinked)
    findings = []
    for index, (je_id, evidence) in enumerate(matches, start=1):
        finding = make_finding(
            run_id, "D4", je_id, evidence, "subledger_match",
            "원장 전기와 보조원장 기록의 금액·거래처 불일치 또는 한쪽 누락 가능성",
            "원장 전표와 보조원장 문서·입금 증빙을 같은 거래처 기준으로 대조하세요.")
        finding["flag_id"] = f"D4S-{index}"
        findings.append(finding)
    return findings


def detect_counterparty(headers, lines, input_dir, run_id, inputs, result):
    """E1 신규 거래처 거액 거래, E2 거래처 마스터 이상. 자료가 없으면 미실행(데이터 부족)."""
    skipped = result["skipped"]
    policy_path = ROOT / "config/external-review.json"
    try:
        record_input(inputs, "external_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))["counterparty"]
    except (OSError, ValueError, KeyError) as exc:
        skipped.update({"E1": str(exc), "E2": str(exc)})
        return []
    vendor_path = input_dir / policy["file"]
    try:
        record_input(inputs, policy["file"], vendor_path)
        vendors = read_csv(vendor_path, VENDOR_COLUMNS)
    except (OSError, ValueError, csv.Error) as exc:
        reason = (f"{policy['file']}에 등록일·계좌 열이 없음 — 미실행(데이터 부족)"
                  if isinstance(exc, ValueError) else f"{policy['file']} 없음 — 미실행(데이터 부족)")
        skipped.update({"E1": reason, "E2": reason})
        return []
    findings = []
    try:
        for je_id, evidence in new_vendor_findings(lines, headers, vendors, policy):
            findings.append(make_finding(
                run_id, "E1", je_id, evidence, "new_vendor_large",
                "신규 거래처에 대한 거액 첫 거래 — 정상 신규 계약 또는 실체 없는 거래처 가능성",
                "거래처 등록 요청서, 사업자등록증, 계약서와 승인 기록을 대조하세요."))
    except (ValueError, KeyError) as exc:
        skipped["E1"] = str(exc)
    employee_path = input_dir / policy["employee_file"]
    try:
        record_input(inputs, policy["employee_file"], employee_path)
        employees = read_csv(employee_path, EMPLOYEE_COLUMNS)
    except (OSError, ValueError, csv.Error):
        employees = []
        skipped["E2 · 임직원 계좌 대조"] = f"{policy['employee_file']} 없음 — 미실행(데이터 부족). 거래처 간 계좌 중복만 검사"
    try:
        for je_id, evidence in master_account_findings(lines, headers, vendors, employees, policy):
            findings.append(make_finding(
                run_id, "E2", je_id, evidence, "vendor_master_account",
                "같은 계좌를 쓰는 거래처 또는 임직원 계좌와 일치 — 지점 공유 계좌 또는 부적절한 지급 가능성",
                "거래처 사업자등록증과 통장 사본, 계좌 변경 이력, 임직원 계좌와의 일치 여부를 확인하세요."))
    except (ValueError, KeyError) as exc:
        skipped["E2"] = str(exc)
    for index, finding in enumerate(findings, start=1):
        finding["flag_id"] = f"{finding['type_id']}-{index}"
    return findings


def detect_bank(headers, lines, input_dir, run_id, inputs, result):
    """H1 은행조정 불일치. 자료가 없으면 미실행(데이터 부족)."""
    skipped = result["skipped"]
    try:
        policy_path = ROOT / "config/external-review.json"
        record_input(inputs, "external_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))["bank"]
    except (OSError, ValueError, KeyError) as exc:
        skipped["H1"] = str(exc)
        return []
    statement_path, balance_path = input_dir / policy["file"], input_dir / policy["balance_file"]
    if not statement_path.exists() or not balance_path.exists():
        skipped["H1"] = f"{policy['file']} 또는 {policy['balance_file']} 없음 — 미실행(데이터 부족)"
        return []
    try:
        record_input(inputs, policy["file"], statement_path)
        record_input(inputs, policy["balance_file"], balance_path)
        statement = read_csv(statement_path, STATEMENT_COLUMNS)
        balance = json.loads(balance_path.read_text(encoding="utf-8-sig"))
        matches, summary = bank_reconciliation(lines, headers, statement, balance, policy)
    except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        skipped["H1"] = str(exc)
        return []
    result["bank"] = summary
    findings = []
    for index, (je_id, evidence) in enumerate(matches, start=1):
        finding = make_finding(
            run_id, "H1", je_id, evidence, "bank_match",
            "장부와 은행 거래의 금액 차이 또는 장부에만 있는 거래 — 입력 오류, 미반영 거래, 가공 기장 가능성",
            "은행 거래내역서·통장 사본과 해당 전표의 입출금 증빙, 은행 반영일을 대조하세요.")
        finding["flag_id"] = f"H1-{index}"
        findings.append(finding)
    return findings


def detect_tax(headers, lines, input_dir, run_id, inputs, result):
    """I4 부가세·세금계산서 불일치, F3 세금계산서 없는 매출. 자료가 없으면 미실행(데이터 부족)."""
    skipped = result["skipped"]
    try:
        policy_path = ROOT / "config/external-review.json"
        record_input(inputs, "external_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))["tax"]
    except (OSError, ValueError, KeyError) as exc:
        skipped.update({"I4": str(exc), "F3": str(exc)})
        return []
    path = input_dir / policy["file"]
    if not path.exists():
        reason = f"{policy['file']} 없음 — 미실행(데이터 부족)"
        skipped.update({"I4": reason, "F3": reason})
        return []
    received = None
    try:
        record_input(inputs, policy["file"], path)
        invoices = read_csv(path, INVOICE_COLUMNS)
        receipt_path = input_dir / policy["receipt_file"]
        if receipt_path.exists():
            record_input(inputs, policy["receipt_file"], receipt_path)
            received = {row["invoice_id"] for row in read_csv(receipt_path, ["invoice_id", "direction"])
                        if row["direction"] == "입금"}
        matches, summary = tax_reconciliation(lines, headers, invoices, policy, received)
    except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        skipped.update({"I4": str(exc), "F3": str(exc)})
        return []
    result["tax"] = summary
    findings, counters = [], Counter()
    for kind, je_id, evidence in matches:
        counters[kind] += 1
        if kind == "I4":
            hypothesis = "세금계산서와 장부의 부가세 차이 또는 매입세액 증빙 누락 — 입력 오류·증빙 누락·신고 불일치 가능성"
            checklist = "홈택스 세금계산서 원본과 전표의 공급가액·세액, 신고 반영 여부를 대조하세요."
        else:
            hypothesis = "세금계산서 없는 매출 — 발행 누락 또는 실제 거래가 없는 가공 매출 가능성"
            checklist = "거래명세서·출고 증빙·세금계산서 발행 내역과 입금 내역을 대조하세요."
        finding = make_finding(run_id, kind, je_id, evidence, "tax_invoice_match", hypothesis, checklist)
        finding["flag_id"] = f"{kind}-{counters[kind]}"
        findings.append(finding)
    return findings


def months_covered(headers):
    days = sorted(row["posting_date"] for row in headers if row.get("posting_date"))
    if not days:
        return 0, "", ""
    first, last = days[0], days[-1]
    count = (int(last[:4]) - int(first[:4])) * 12 + int(last[5:7]) - int(first[5:7]) + 1
    return count, first[:7], last[:7]


def load_unchecked_reasons(inputs):
    path = ROOT / "config/unimplemented-reasons.json"
    record_input(inputs, "unimplemented_reasons", path)
    return json.loads(path.read_text(encoding="utf-8-sig"))["types"]


def related_unchecked(findings, reasons):
    """탐지된 유형과 연관되지만 이 도구가 검사하지 못하는 유형을 사유와 함께 모은다."""
    counts = Counter(row["type_id"] for row in findings)
    related = []
    for kind in PENDING:
        info = reasons.get(kind)
        if info is None:
            info = dict(name="", reason="사유 미등록 — 확인 필요", needs="", triggered_by=[])
        hits = [dict(type_id=trigger, count=counts[trigger]) for trigger in info["triggered_by"] if counts[trigger]]
        if hits:
            related.append(dict(type_id=kind, name=info["name"], reason=info["reason"],
                                needs=info["needs"], triggered_by=hits))
    return related


def detect_patterns(headers, lines, run_id, inputs, result):
    """A7 수기전표 과다, B5 동일 금액 반복, C2 희소·휴면 계정. C2는 12개월 기준이라 기간이 짧으면 안내한다."""
    skipped = result["skipped"]
    try:
        policy_path = ROOT / "config/pattern-review.json"
        requirement_path = ROOT / "config/period-requirements.json"
        record_input(inputs, "pattern_review", policy_path)
        record_input(inputs, "period_requirements", requirement_path)
        trend_path = ROOT / "config/trend-review.json"
        record_input(inputs, "trend_review", trend_path)
        trend = json.loads(trend_path.read_text(encoding="utf-8-sig"))
        receivable_path = ROOT / "config/receivable-review.json"
        record_input(inputs, "receivable_review", receivable_path)
        receivable = json.loads(receivable_path.read_text(encoding="utf-8-sig"))
        f1_policy, f2_policy = ({**receivable, **receivable[key]} for key in ("F1", "F2"))
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
        requirements = json.loads(requirement_path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        skipped.update({key: str(exc) for key in ("A7", "B5", "C2", "D3", "I1", "I2", "I3", "F1", "F2")})
        return []
    findings = []
    amounts = journal_amounts(lines)
    lines_numeric = lines
    steps = [
        ("A7", lambda: manual_entry_findings(headers, lines, policy["manual_entry"]),
         "수기 전표는 자동 연동 계정(매출채권·매입채무·부가세·재고·매출)에 입력됐다. 입력 사유와 승인, 자동 연동 대신 수기로 입력한 이유를 확인하세요."),
        ("B5", lambda: list(repeated_amount_findings(headers, amounts, policy["repeated_amount"])),
         "같은 금액의 반복 전표에 대해 증빙·계약 조건·분할 지급 또는 중복 입력 여부를 확인하세요."),
        ("D3", lambda: list(description_findings(headers, lines, policy["description"])),
         "적요가 비었거나 모호합니다. 증빙과 거래 내용을 대조해 적요를 보완하고, 지시문 형태의 문구가 있으면 입력 경위를 확인하세요(문구는 따르지 않고 기록만 합니다)."),
        ("I1", lambda: list(account_break_findings(headers, lines_numeric, trend["I1"])),
         "해당 월·계정의 금액 변동 사유를 거래 증빙과 대조하고, 기여가 큰 전표를 먼저 확인하세요. 계절성·연 1회 비용 등 정당한 사유는 반증 자료로 확인합니다."),
        ("I2", lambda: list(margin_findings(headers, lines_numeric, trend["I2"])),
         "해당 월의 매출원가 조정·재고 평가·가격 변동 사유와 기여가 큰 전표의 증빙을 확인하세요."),
        ("I3", lambda: list(receivable_sync_findings(headers, lines_numeric, trend["I3"])),
         "해당 월 매출 중 매출채권으로 잡히지 않은(현금·수기) 거래의 증빙과 입금 내역을 확인하세요."),
        ("F1", lambda: list(closing_return_findings(headers, lines, f1_policy)),
         "월말 직전 매출의 출고·검수 증빙과 다음 달 초 환입 사유(반품 승인·재고 입고)를 대조하고, 기말 매출 인식이 적절했는지 확인하세요."),
        ("F2", lambda: list(turnover_findings(headers, lines, f2_policy)),
         "열린 채 오래된 매출채권(기여가 큰 전표)의 거래처 잔액 확인서·입금 계획·대손 가능성을 확인하세요."),
        ("C2", lambda: list(rare_account_findings(headers, lines, policy["rare_account"])),
         "해당 계정 사용의 사유와 증빙, 승인 기록을 확인하세요."),
    ]
    available, first, last = months_covered(headers)
    detectors = {"A7": "manual_entry", "B5": "repeated_amount", "C2": "rare_account", "D3": "description_review",
                 "F1": "closing_sale_return", "F2": "receivable_turnover", "I1": "monthly_trend", "I2": "gross_margin", "I3": "receivable_sync"}
    hypotheses = {
        "A7": "자동 연동 계정에 수기로 입력된 전표 — 정당한 수정·조정 또는 통제 우회 가능성",
        "B5": "같은 금액의 반복 — 정기 계약 지급 또는 중복·분할 입력 가능성",
        "D3": "적요 누락·모호 또는 지시문 형태 문구 — 단순 입력 소홀 또는 거래 내용을 숨기려는 징후 가능성",
        "F1": "월말 직전 매출이 다음 달 초 대부분 환입 — 정상 반품 또는 기말 매출 부풀리기 가능성",
        "F2": "매출채권 회전일수가 평소보다 크게 늘어남 — 정상 회수 지연 또는 회수 불가능한 매출·가공매출 가능성",
        "I1": "안정적이던 계정의 월 금액이 평소 흐름에서 벗어남 — 정당한 비경상 거래 또는 특정 전표의 이상 가능성",
        "I2": "월 매출총이익률이 평소에서 벗어남 — 원가 조정·재고 평가 등 정당한 사유 또는 원가·매출 조작 가능성",
        "I3": "매출 대비 매출채권 증가가 평소와 다름 — 현금매출 등 정당한 사유 또는 매출 인식·채권 처리 이상 가능성",
        "C2": "거의 쓰이지 않던 계정의 사용 — 정당한 비경상 거래 또는 부적절한 계정 사용 가능성",
    }
    for kind, run, checklist in steps:
        need = requirements.get(kind)
        if need and available < need["min_months"]:
            skipped[kind] = (f"기간 부족 — {need['min_months']}개월 이상 필요, 현재 {available}개월 "
                             f"({first}~{last}). 아래 안내 참조")
            result["period_requirements"].append(dict(
                type_id=kind, name=need["name"], required_months=need["min_months"],
                available_months=available, first_month=first, last_month=last,
                accounts=[dict(code=code, name=name) for code, name in need["accounts"]],
                reason=need["reason"]))
            continue
        try:
            matches = run()
        except (OSError, ValueError, KeyError, TypeError) as exc:
            skipped[kind] = str(exc)
            continue
        if kind == "A7":
            matches, result["manual_summary"] = matches
        for index, (je_id, evidence) in enumerate(matches, start=1):
            finding = make_finding(run_id, kind, je_id, evidence, detectors[kind],
                                   hypotheses[kind], checklist)
            finding["flag_id"] = f"{kind}-{index}"
            findings.append(finding)
    return findings


def finish_findings(findings):
    for index, finding in enumerate(findings, start=1):
        finding["flag_id"] = f"{finding['type_id']}-{index}"
    return findings


def detect_ledger_rules(headers, lines, files, result, inputs):
    skipped = result["skipped"]
    policy_path = ROOT / "config/ledger-review.json"
    try:
        record_input(inputs, "ledger_review", policy_path)
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        skipped.update(dict.fromkeys(("A1", "B1", "B4", "C1", "C7", "D5"), str(exc)))
        return []
    amounts = journal_amounts(lines)
    by_journal = defaultdict(list)
    for line in lines:
        by_journal[line["je_id"]].append(line)
    findings = []
    for kind, detect, checklist in (
        ("B1", lambda: round_amount_findings(headers, amounts, policy),
         "계약상 정액 조건과 같은 전표 유형의 증빙을 대조하세요."),
        ("C1", lambda: account_combination_findings(headers, by_journal,
                                                    policy["account_combination_minimum"]),
         "차변·대변 계정 선택과 거래 증빙을 대조하세요."),
        ("C7", lambda: account_direction_findings(
            lines, read_csv(files["coa"], ["계정코드", "정상잔액방향"]), policy["direction_accounts"]),
         "환입·취소·정정 승인과 적용 계정의 성격을 확인하세요."),
        ("D5", lambda: repeated_reversal_findings(headers, by_journal),
         "원전표, 취소와 재입력 사유, 작업 및 승인 이력을 대조하세요."),
    ):
        try:
            matches = list(detect())
        except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
            skipped[kind] = str(exc)
            continue
        for je_id, evidence in matches:
            finding = make_finding(result["run_id"], kind, je_id, evidence,
                                   kind.lower(), "거래 증빙과 전기 이력 확인 필요", checklist)
            finding["line_no"] = evidence.get("line_no")
            findings.append(finding)
    for kind, summarize in (
        ("A1", lambda: [evidence for _, evidence in closing_findings(
            headers, amounts, json.loads(files["control"].read_text(encoding="utf-8-sig")), policy
        )]),
        ("B4", lambda: list(benford_summaries(headers, amounts, policy))),
    ):
        try:
            summaries = summarize()
            if kind == "B4" and not summaries:
                skipped[kind] = "최소 표본 또는 금액 자릿수 범위 기준을 충족하지 못했습니다."
            result["population_checks"][kind] = summaries
        except (OSError, ValueError, KeyError, TypeError) as exc:
            skipped[kind] = str(exc)
    return findings


def make_finding(run_id, type_id, je_id, evidence, detector, hypothesis, checklist):
    return dict(run_id=run_id, type_id=type_id, je_id=je_id, evidence=evidence,
                detector=detector, line_no=None, score=1, hypotheses=[hypothesis],
                checklist_items=[checklist])


def detect_d4(lines, run_id):
    debits, credits = Counter(), Counter()
    for line in lines:
        debits[line["je_id"]] += line["debit"]
        credits[line["je_id"]] += line["credit"]
    return [
        {
            "flag_id": f"D4-{index}",
            "run_id": run_id,
            "je_id": je_id,
            "line_no": None,
            "type_id": "D4",
            "score": 1,
            "detector": "journal_balance",
            "evidence": {
                "debit_total": debits[je_id],
                "credit_total": credits[je_id],
                "difference": debits[je_id] - credits[je_id],
            },
            "hypotheses": ["분개 라인 누락 또는 금액 입력 차이 가능성"],
            "checklist_items": ["원천 전표의 분개 라인과 전기 이력을 원장과 대조하세요."],
        }
        for index, je_id in enumerate(
            (key for key in sorted(debits) if debits[key] != credits[key]), start=1
        )
    ]


def stop_guidance(result):
    """중단 사유와 조치 안내(대사 불일치 또는 입력 오류)."""
    rows = ["", "## 중단 사유와 조치 안내", ""]
    if result["status"] == "reconciliation_failed":
        diffs = [CONTROL_FIELDS[k] for k, v in result["reconciliation"].items() if v["difference"]]
        rows += [f"- 불일치 항목: {', '.join(diffs)} (위 표의 차이 열 참고)",
                 "- 가능한 원인(확인 필요): 통제합계 기준 시점·범위가 입력 파일과 다름, 파일 추출 중 누락·중복, 부호·단위 변환 오류, 다른 기간 합계 사용",
                 "- 조치: 원천 시스템의 통제합계를 다시 확인하거나 입력 파일을 다시 추출한 뒤 재실행하세요.",
                 "- 이 보고서는 탐지 결과가 아니며, 불일치 상태에서는 분석을 진행하지 않습니다."]
    else:
        rows += [f"- 입력 오류: {result.get('input_error', '내용 확인 필요')}",
                 "- 조치: `docs/external-input.md`의 형식(정수 금액, 계정과목표에 있는 코드, 시간대 포함 입력시각, 통제합계 파일)을 확인한 뒤 재실행하세요."]
    return rows


def render_markdown(result):
    rows = [
        "# 회계 이상거래 검토",
        "",
        f"- 실행 ID `{result['run_id']}`",
        f"- 실행 결과 **{result['status_message']}**",
    ]
    if result["reconciliation"]:
        rows += ["", "## 모집단 대사", "",
                 "| 항목 | 원천 통제합계 | 입력 집계 | 차이(입력 − 원천) |",
                 "|---|---:|---:|---:|"]
        for key, item in result["reconciliation"].items():
            rows.append(
                f"| {CONTROL_FIELDS[key]} | {item['source']:,} | "
                f"{item['actual']:,} | {item['difference']:,} |"
            )

    rows += ["", "## 탐지 결과", ""]
    if result["status"] != "completed":
        rows.append("미실행. 입력 검증 또는 모집단 대사에서 중단됐습니다.")
        rows += stop_guidance(result)
    elif not result["findings"]:
        rows.append("실행된 검사에서 검토 후보가 발견되지 않았습니다.")
    weekend_only = []
    for finding in result["findings"]:
        evidence = finding["evidence"]
        kind = finding["type_id"]
        if kind == "A2" and evidence["reasons"] == ["주말"]:
            weekend_only.append(finding)
            continue
        rows += [f"### {kind} · `{inline_text(finding['je_id'])}`", ""]
        if kind == "D4" and finding["detector"] == "subledger_match":
            rows += ["| 구분 | 계정 | 거래처 | 원장 금액 | 보조원장 금액 | 차이(원장 − 보조원장) |",
                     "|---|---|---|---:|---:|---:|"]
            for item in evidence["ledger_rows"]:
                rows.append(f"| {item['ledger']} | {inline_text(item['account'])} | "
                            f"{inline_text(item['counterparty'])} | {item['gl_amount']:,} | "
                            f"{item['subledger_amount']:,} | **{item['difference']:,}** |")
            rows.append("")
        elif kind == "D4":
            rows += [
                f"- 차변 {evidence['debit_total']:,}원 / 대변 {evidence['credit_total']:,}원",
                f"- 차이(차변 − 대변) **{evidence['difference']:,}원**",
            ]
        elif kind == "A7":
            rows.append(f"- 유형 `{inline_text(evidence['je_type'])}` · 입력자 `{inline_text(evidence['entered_by'])}` "
                        f"· 전기일 {evidence['posting_date']} · 수기 입력이 건드린 자동 연동 계정 "
                        f"{', '.join(f'`{inline_text(code)}`' for code in evidence['accounts'])}")
        elif kind == "F1":
            rows.append(f"- 거래처 `{inline_text(evidence['customer'])}` · 매출 `{inline_text(evidence['sale_journal'])}` "
                        f"{evidence['sale_date']} {evidence['sale_gross']:,}원 → 환입 `{inline_text(evidence['return_journal'])}` "
                        f"{evidence['return_date']} {evidence['return_gross']:,}원 (매출의 {evidence['return_ratio']:.0%}, 월말 {evidence['month_end']}) · 이 전표는 {evidence['role']} 쪽")
        elif kind == "F2":
            rows.append(f"- {evidence['month']} · 매출채권 회전일수 **{evidence['turnover_days']}일** "
                        f"(이전 달 중앙값 {evidence['baseline_days']}일, 허용 +{evidence['limit_days']}일) "
                        f"· 월말 잔액 {evidence['ending_balance']:,}원 · 그 달 발생 {evidence['issued']:,}원")
            rows.append("- 열린 매출 상위: " + ", ".join(f"`{inline_text(item['je_id'])}` {item['open_amount']:,}원" for item in evidence["top_open_journals"]))
        elif kind == "I1":
            rows.append(f"- {evidence['month']} · 계정 `{inline_text(evidence['account'])}` · 월 금액 **{evidence['value']:,}원** "
                        f"(나머지 달 중앙값 {evidence['baseline']:,}원, 허용 편차 {evidence['limit']:,}원, 편차 {evidence['deviation']:,}원)")
            rows.append("- 기여 큰 전표: " + ", ".join(f"`{inline_text(item['je_id'])}` {item['amount']:,}원" for item in evidence["top_journals"]))
        elif kind == "I2":
            rows.append(f"- 지적 사유: {inline_text(evidence['reason'])} (매출 없이 잡힌 원가 비중 {evidence['one_sided_cost_ratio']:.1%})")
            rows.append(f"- {evidence['month']} · 매출총이익률 **{evidence['margin_percent']}%** "
                        f"(나머지 달 중앙값 {evidence['baseline_percent']}%, 허용 {evidence['limit_points']}%p, 편차 {evidence['deviation_points']}%p) "
                        f"· 매출 {evidence['revenue']:,}원 · 매출원가 {evidence['cost']:,}원 (기대 {evidence['expected_cost']:,}원)")
            rows.append("- 기대 원가율에서 벗어난 전표: " + ", ".join(f"`{inline_text(item['je_id'])}` {round(item['amount']):,}원" for item in evidence["top_journals"]))
        elif kind == "I3":
            rows.append(f"- {evidence['month']} · 매출채권 증가/매출(부가세 포함) **{evidence['receivable_ratio']}** "
                        f"(나머지 달 중앙값 {evidence['baseline_ratio']}, 허용 ±{evidence['limit']}) "
                        f"· 매출 {evidence['sales_with_vat']:,}원 · 매출채권 차변 {evidence['receivable_debit']:,}원")
            rows.append("- 매출 대비 채권이 덜 잡힌 전표: " + ", ".join(f"`{inline_text(item['je_id'])}` {item['amount']:,}원" for item in evidence["top_journals"]))
        elif kind == "D3":
            for item in evidence["flagged"]:
                where = item["scope"] if item["line_no"] is None else f"라인 {item['line_no']}"
                rows.append(f"- {where} · {item['kind']} · 적요 `{inline_text(item['text'])}`")
            if evidence["flagged_count"] > len(evidence["flagged"]):
                rows.append(f"- 그 밖에 적요 문제 {evidence['flagged_count'] - len(evidence['flagged'])}곳")
        elif kind == "B5":
            members = ", ".join(f"`{inline_text(key)}`" for key in evidence["journal_ids"])
            rows.append(f"- 전표 유형 `{inline_text(evidence['je_type'])}` · 금액 **{evidence['amount']:,}원** "
                        f"· {evidence['window_days']}일 이내 {evidence['repeat_count']}건 반복 "
                        f"({evidence['first_date']}~{evidence['last_date']}) · {members}")
        elif kind == "C2":
            for item in evidence["accounts"]:
                detail = (f"{item['gap_days']}일 휴면 후 재사용(직전 {item['previous_date']})"
                          if "gap_days" in item else f"기간 내 사용 {item['usage_count']}건")
                rows.append(f"- 계정 `{inline_text(item['account'])}` · {item['reason']} · {detail}")
        elif kind == "I4":
            if "invoice_vat" in evidence:
                rows.append(f"- **{evidence['reason']}** · {evidence['direction']} 증빙 "
                            f"`{inline_text(evidence['document_id'])}` · 세액 장부 {evidence['book_vat']:,}원 / "
                            f"세금계산서 {evidence['invoice_vat']:,}원 (차이 **{evidence['vat_difference']:,}원**) "
                            f"· 공급가액 장부 {evidence['book_supply']:,}원 / 세금계산서 {evidence['invoice_supply']:,}원")
            else:
                rows.append(f"- **{evidence['reason']}** · {evidence['direction']} 증빙 "
                            f"`{inline_text(evidence['document_id'])}` · 장부 세액 **{evidence['book_vat']:,}원** "
                            f"(공급가액 {evidence['book_supply']:,}원)")
        elif kind == "F3":
            receipt = {True: "입금 확인됨", False: "입금 내역 없음", None: "입금 자료 없음"}[evidence["receipt_found"]]
            rows.append(f"- 증빙 `{inline_text(evidence['document_id'])}` · 전기일 {evidence['posting_date']} "
                        f"· 장부 공급가액 {evidence['book_supply']:,}원 / 세액 {evidence['book_vat']:,}원 "
                        f"· **세금계산서 없음** · {receipt}")
        elif kind == "H1":
            rows.append(f"- **{evidence['reason']}** · 증빙 `{inline_text(evidence['reference'])}` "
                        f"· 전기일 {evidence['posting_date']} · 장부 {evidence['book_amount']:,}원 / "
                        f"은행 {evidence['bank_amount']:,}원 · 차이 **{evidence['difference']:,}원**")
        elif kind == "E1":
            rows.append(f"- 거래처 `{inline_text(evidence['vendor_id'])}` · {', '.join(evidence['reasons'])} "
                        f"· 등록 {evidence['registered_date']} → 첫 거래 {evidence['first_transaction_date']} "
                        f"({evidence['days_after_registration']}일 후) · 금액 **{evidence['amount']:,}원** "
                        f"(기준 {evidence['window_days']}일 이내, {evidence['amount_threshold']:,}원 이상)")
        elif kind == "E2":
            rows.append(f"- 거래처 `{inline_text(evidence['vendor_id'])}` · 전기일 {evidence['posting_date']} "
                        f"· 대변 {evidence['credit_amount']:,}원 / 차변 {evidence['debit_amount']:,}원")
            for match in evidence["matches"]:
                extra = (f" · 같은 계좌 거래처 {', '.join(map(inline_text, match['other_vendors']))}"
                         if match.get("other_vendors") else "")
                rows.append(f"  - {match['reason']} · 계좌 `{inline_text(match['account'])}`{extra}")
        elif kind == "D1":
            document = "송장" if evidence["document_type"] == "invoice_id" else "영수증"
            rows += [
                f"- 일치한 {document} 번호 `{inline_text(evidence['document_id'])}`",
                "",
                "| 전표 ID | 증빙 일자 | 금액 |",
                "|---|---|---:|",
            ]
            for journal in evidence["journals"]:
                rows.append(f"| `{inline_text(journal['je_id'])}` | "
                            f"{journal['date']} | {journal['amount']:,}원 |")
            rows.append("")
        elif kind == "A6":
            rows.append(f"- 근거 **{evidence['reason']}**")
        elif kind == "A4":
            rows.append(f"- **{evidence['reason']}** · 전기일 {evidence['posting_date']} / "
                        f"현지 입력일 {evidence['entry_date']}")
            rows.append(f"- 차이(입력일 − 전기일) **{evidence['difference_days']:+d}일** "
                        f"(기준 {evidence['threshold_days']}일 초과)")
        elif kind == "D2":
            if finding["detector"] == "posting_order":
                rows.append(f"- **전기일 역전 {evidence['days_earlier']}일** · "
                            f"{evidence['previous_posting_date']} → {evidence['posting_date']}")
            else:
                rows.append(f"- 결번 범위 **{evidence['missing_from']}~{evidence['missing_to']}** "
                            f"({evidence['missing_count']}개)")
            rows.append(f"- 회사 `{inline_text(evidence['company_code'])}` · "
                        f"직전 `{inline_text(evidence['previous_je_id'])}` "
                        f"(번호 {evidence['previous_sequence']}) → "
                        f"현재 `{inline_text(finding['je_id'])}` (번호 {evidence['next_sequence']})")
        elif kind == "B2":
            rows.append(f"- 거래액 {evidence['amount']:,}원 / 건별 카드 한도 "
                        f"{evidence['per_transaction_limit']:,}원 / 한도까지 **{evidence['gap']:,}원**")
            rows.append(f"- 적용 범위 한도 미만, 한도와의 차이 "
                        f"{evidence['near_limit_basis_points'] / 100:g}% 이내")
        elif kind == "B3":
            if finding["detector"] == "payroll_amount":
                reference_label = "기본급 + 승인 상여"
            else:
                reference_label = f"동일 상품 다른 송장 {evidence['peer_count']}건 단가 중앙값"
            rows.append(f"- 실제 금액 {evidence['actual_amount']:,}원 / "
                        f"{reference_label} {evidence['reference_amount']:,}원 / "
                        f"차이 **{evidence['difference']:+,}원**")
        elif kind == "B6":
            rows.append(f"- 발주 `{inline_text(evidence['order_ref'])}` · "
                        f"{evidence['payment_count']}건 합계 **{evidence['total_amount']:,}원**, "
                        f"건별 한도 {evidence['per_transaction_limit']:,}원 대비 "
                        f"**{evidence['excess']:,}원 초과**")
            for payment in evidence["payments"]:
                rows.append(f"- `{inline_text(payment['je_id'])}` · "
                            f"거래 `{inline_text(payment['transaction_id'])}` · {payment['amount']:,}원")
        elif kind == "B1":
            rows.append(f"- 전표 차변 합계 **{evidence['amount']:,}원** "
                        f"· {evidence['unit']:,}원 단위 "
                        f"· 동일 유형 정액 {evidence['rounded_count']}/{evidence['sample_count']}건")
        elif kind == "C1":
            debit = ", ".join(map(inline_text, evidence["debit_accounts"]))
            credit = ", ".join(map(inline_text, evidence["credit_accounts"]))
            rows.append(f"- 차변 계정 `{debit}` / 대변 계정 `{credit}` "
                        f"· 동일 조합 {evidence['occurrences']}건")
        elif kind == "C7":
            rows.append(f"- 라인 {evidence['line_no']} · 계정 `{inline_text(evidence['account_code'])}` "
                        f"· 정상 방향 {evidence['expected_side']} / 실제 {evidence['actual_side']} "
                        f"**{evidence['amount']:,}원**")
        elif kind == "D5":
            journals = " → ".join(inline_text(key) for key in evidence["journal_ids"])
            rows.append(f"- 증빙 `{inline_text(evidence['document_id'])}` · 역분개·재입력 후보 `{journals}`")
        elif kind == "A2":
            reasons = ", ".join(evidence["reasons"])
            rows.append(f"- 입력 `{evidence['entered_at']}` · {reasons} "
                        f"(설정 시간 {evidence['start']}~{evidence['end']})")
        rows += [
            f"- 가능성은 {finding['hypotheses'][0]}입니다.",
            f"- {finding['checklist_items'][0]}",
            "",
        ]
    if weekend_only:
        rows += [
            "", f"### A2 · 주말 입력만 해당 · {len(weekend_only)}건", "",
            "정기 자동 전기나 승인된 작업 여부는 별도 일정과 승인 기록을 대조하세요.",
            "", "<details>", "<summary>주말 전표 목록 펼치기</summary>", "",
            "| 전표 ID | 입력일시 |", "|---|---|",
        ]
        for finding in weekend_only:
            rows.append(f"| `{inline_text(finding['je_id'])}` | "
                        f"{finding['evidence']['entered_at']} |")
        rows += ["", "</details>", ""]
    if result["exceptions"]:
        rows += [
            "", f"## A2 · 승인·예정된 예외 · {len(result['exceptions'])}건", "",
            "| 전표 ID | 입력일시 | 일치한 승인·배치 기록 |", "|---|---|---|",
        ]
        for item in result["exceptions"]:
            records = ", ".join(inline_text(record["evidence_id"])
                                for record in item["matched_records"])
            rows.append(f"| `{inline_text(item['je_id'])}` | {item['evidence']['entered_at']} | {records} |")
    if result.get("period_requirements"):
        rows += ["", "## 기간 기준 검사 — 추가 데이터 필요", "",
                 "아래 유형은 오류가 없어서가 아니라 입력된 원장 기간이 짧아 **검사하지 않았습니다.** "
                 "각 유형에 필요한 기간(12개월 기준 계정은 12개월) 이상의 원장이 입력되면 같은 절차로 자동 수행됩니다."]
        for item in result["period_requirements"]:
            names = ", ".join(f"{a['code']} {inline_text(a['name'])}" for a in item["accounts"])
            rows += ["", f"### {inline_text(item['name'])}", "",
                     f"- 입력 기간 {item['first_month']}~{item['last_month']} ({item['available_months']}개월) / "
                     f"필요 기간 {item['required_months']}개월 이상",
                     f"- {item['required_months']}개월 기준으로 판단하는 것이 적절한 계정과목: {names}",
                     f"- 사유: {inline_text(item['reason'])}"]
    if "manual_summary" in result:
        manual = result["manual_summary"]
        rows += ["", "## A7 · 수기 전표 현황", "",
                 f"수기 입력 전표 {manual['manual_count']:,}건 / 전체 {manual['journal_count']:,}건 "
                 f"({manual['manual_count'] / max(manual['journal_count'], 1):.1%})"]
    if "tax" in result:
        tax = result["tax"]
        rows += ["", "## I4 · 부가세 대사 (분기별)", "",
                 f"세금계산서 {tax['invoice_count']:,}건 · 전표와 연결되지 않은 세금계산서 {len(tax['unlinked'])}건",
                 "", "| 분기 | 매출세액 장부 | 매출세액 세금계산서 | 매입세액 장부 | 매입세액 세금계산서 |",
                 "|---|---:|---:|---:|---:|"]
        for item in tax["periods"]:
            rows.append(f"| {item['period']} | {item['sales_book']:,} | {item['sales_invoice']:,} | "
                        f"{item['purchase_book']:,} | {item['purchase_invoice']:,} |")
        for item in tax["unlinked"]:
            rows.append("")
            rows.append(f"- 장부와 연결되지 않은 세금계산서 `{inline_text(item['tax_invoice_id'])}` · "
                        f"{item['direction']} · {item['issue_date']} · 세액 {item['vat']:,}원")
    if "bank" in result:
        bank = result["bank"]
        rows += ["", "## H1 · 장부↔은행 대사", "",
                 "| 항목 | 금액 |", "|---|---:|",
                 f"| 장부 현금(1010) 기말 잔액 | {bank['book_closing']:,} |",
                 f"| 은행 기말 잔액 | {bank['bank_closing']:,} |",
                 f"| 차이(장부 − 은행) | **{bank['difference']:,}** |",
                 f"| 은행에 없는 기말 시차 항목 합계 | {bank['timing_total']:,} |",
                 f"| 장부에 없는 은행 거래 합계 | {bank['bank_only_total']:,} |",
                 f"| 전표 단위 후보의 차이 합계 | {bank['finding_difference_total']:,} |",
                 f"| 기초 잔액 차이(장부 − 은행) | {bank['opening_book'] - bank['opening_bank']:,} |",
                 f"| 위 항목으로 설명되지 않는 차이 | **{bank['unexplained_difference']:,}** |",
                 f"| 은행 자료 내부 차이(기말 − 기초 − 거래 합) | {bank['bank_internal_difference']:,} |"]
        if bank["timing_items"]:
            rows += ["", "기말 시차 항목(후보에서 제외, 다음 영업일 은행 반영 확인): " +
                     ", ".join(f"`{inline_text(item['je_id'])}`({item['amount']:,}원)" for item in bank["timing_items"])]
        if bank["bank_only"]:
            rows += ["", f"장부에 없는 은행 거래 {len(bank['bank_only'])}건:"]
            for item in bank["bank_only"]:
                rows.append(f"- `{inline_text(item['bank_tx_id'])}` · {item['tx_date']} · "
                            f"증빙 `{inline_text(item['reference'])}` · {item['amount']:,}원")
    if "subledger" in result:
        sub = result["subledger"]
        flagged = [item for item in sub["balances"] if item["flagged"]]
        rows += ["", "## D4 · 원장↔보조원장 잔액 대사", "",
                 f"보조원장 {sub['entry_count']:,}행 · 거래처 {len(sub['balances'])}곳 · "
                 f"잔액 차이 {len(flagged)}곳"]
        if flagged:
            rows += ["", "| 구분 | 거래처 | 원장 잔액 | 보조원장 잔액 | 차이 |", "|---|---|---:|---:|---:|"]
            for item in flagged:
                rows.append(f"| {item['ledger']} | {inline_text(item['counterparty'])} | "
                            f"{item['gl_balance']:,} | {item['subledger_balance']:,} | "
                            f"**{item['difference']:,}** |")
        if sub["unlinked"]:
            rows += ["", f"원장 전표와 연결되지 않은 보조원장 행 {len(sub['unlinked'])}건: " +
                     ", ".join(f"`{inline_text(item['entry_id'])}`" for item in sub["unlinked"])]
    for kind, summaries in result["population_checks"].items():
        if kind in result["skipped"]:
            continue
        rows += ["", f"## {kind} · {'마감 집중' if kind == 'A1' else '벤포드 분포'}", ""]
        if kind == "A1" and not summaries:
            rows.append("설정한 마감 집중 기준을 넘은 기간이 없습니다.")
        for item in summaries:
            if kind == "A1":
                rows.append(f"- {item['window_start']}~마감일 {item['close_date']} "
                            f"(이후 관측 {item['observed_after_days']}일) · 전표 {item['window_count']}건 "
                            f"· 일평균 {item['daily_count']}건 / 기준 기간 {item['baseline_daily_count']}건 "
                            f"· 일평균 차변 {item['daily_debit']:,}원 / 기준 기간 {item['baseline_daily_debit']:,}원")
            else:
                status = "검토 기준 초과" if item["flagged"] else "기준 이내"
                rows.append(f"- 회사 `{inline_text(item['company_code'])}` · {item['position']}번째 자리 "
                            f"· 표본 {item['sample_count']}건 · MAD {item['mad']:.4f} "
                            f"(적용 기준 {item['threshold']:.4f}, 표본 크기만큼의 기대 MAD "
                            f"{item['expected_mad']:.4f}) · {status}")
    if result.get("related_unchecked"):
        rows += ["", "## 추가로 확인이 필요한 미검사 유형", "",
                 "아래 유형은 이번에 탐지된 이상거래와 연관되지만 이 도구가 **검사하지 못하는** 유형입니다. "
                 "검사하지 않았으므로 이상이 없다는 뜻이 아니며, 사유를 보고 회계사가 직접 확인해야 합니다."]
        for item in result["related_unchecked"]:
            hits = ", ".join(f"{hit['type_id']} {hit['count']}건" for hit in item["triggered_by"])
            rows += ["", f"- **{inline_text(item['name'])}** · 연관 탐지: {hits}",
                     f"  - 검사하지 못한 사유: {inline_text(item['reason'])}",
                     f"  - 필요한 자료: {inline_text(item['needs'])}"]
    rows += ["", f"## 카탈로그 미구현 유형 · {len(result['not_implemented'])}개", "",
             "이 보고서는 아래 유형을 검사하지 않았다. 미검사이므로 해당 유형의 이상이 없다는 뜻이 아니다. "
             "각 유형의 필요 자료와 구현 가능성은 `docs/coverage.md`를 본다.", ""]
    if result.get("unchecked_reasons"):
        rows += ["| 유형 | 검사하지 못한 사유 |", "|---|---|"]
        for kind in result["not_implemented"]:
            info = result["unchecked_reasons"].get(kind, dict(name="", reason="사유 미등록 — 확인 필요"))
            rows.append(f"| {inline_text(info['name'] or type_names.type_name(kind))} | {inline_text(info['reason'])} |")
    else:
        rows.append(", ".join(type_names.type_name(kind) for kind in result["not_implemented"]) or "없음")
    rows += ["", "## 미실행 유형", ""]
    if not result["skipped"]:
        rows.append("없음" if result["status"] == "completed" else "대사 또는 입력 검증에서 중단")
    for rule, error in result["skipped"].items():
        rows.append(f"- {rule} · `{inline_text(error)}`")
    rows += [
             "", "이 결과는 검토 보조 자료이며 감사 증거가 아니다. 반드시 회계사 검토를 거친다."]
    codes = {row["type_id"] for row in result["findings"]} | set(result["not_implemented"]) \
        | {row["type_id"] for row in result.get("exceptions", [])}
    text = type_names.humanize("\n".join(rows))
    return text + "\n".join(type_names.reference_table(codes)) + "\n"


def inline_text(value):
    return " ".join(value.splitlines()).replace("`", "'").replace("|", "／")


def main():
    parser = argparse.ArgumentParser(description="모집단 대사와 " + "·".join(IMPLEMENTED) + " 검사")
    parser.add_argument("--input", type=Path, default=ROOT / "data/synthetic/2026Q1")
    args = parser.parse_args()
    started = datetime.now(timezone.utc)
    run_id = f"{started:%Y%m%dT%H%M%S}Z-{uuid4().hex[:8]}"
    input_dir = args.input.resolve()
    files = {
        "headers": input_dir / "je_header.csv",
        "lines": input_dir / "je_line.csv",
        "control": input_dir / "source_control_totals.json",
        "coa": ROOT / "data/coa/korean_coa.csv",
    }
    result = dict(run_id=run_id, version=VERSION, reconciliation={},
                  findings=[], exceptions=[], implemented=IMPLEMENTED, period_requirements=[],
                  not_implemented=PENDING, skipped={}, population_checks={})
    inputs = {}
    try:
        for role, path in files.items():
            record_input(inputs, role, path)
        result["reconciliation"], headers, lines = validate_and_reconcile(files)
        if lines is None:
            result.update(status="reconciliation_failed",
                          status_message="모집단 대사 불일치로 분석 중단")
            exit_code = 2
        else:
            findings = detect_d4(lines, run_id)
            findings.extend(detect_review_rules(
                headers, input_dir, run_id, inputs, result["skipped"], result["exceptions"]
            ))
            findings.extend(detect_subledger(lines, input_dir, run_id, inputs, result))
            findings.extend(detect_counterparty(headers, lines, input_dir, run_id, inputs, result))
            findings.extend(detect_bank(headers, lines, input_dir, run_id, inputs, result))
            findings.extend(detect_tax(headers, lines, input_dir, run_id, inputs, result))
            findings.extend(detect_patterns(headers, lines, run_id, inputs, result))
            findings.extend(finish_findings(detect_ledger_rules(headers, lines, files, result, inputs)))
            result.update(status="completed", status_message="모집단 대사 통과 및 탐지 실행 완료",
                          findings=findings)
            reasons = load_unchecked_reasons(inputs)
            result["unchecked_reasons"] = {kind: reasons.get(kind, dict(name="", reason="사유 미등록 — 확인 필요", needs=""))
                                           for kind in PENDING}
            result["related_unchecked"] = related_unchecked(findings, reasons)
            exit_code = 0
    except (OSError, ValueError, csv.Error) as exc:
        result.update(status="input_error", status_message="입력 오류로 분석 중단")
        result["input_error"] = str(exc)
        exit_code = 1

    report_dir = ROOT / "reports" / run_id
    report_dir.mkdir(parents=True)
    log_dir = ROOT / "runs"
    log_dir.mkdir(exist_ok=True)
    (report_dir / "report.md").write_text(render_markdown(result), encoding="utf-8")
    (report_dir / "report.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    log = dict(run_id=run_id, started_at=started.isoformat(), script="src/agent/audit.py",
               version=VERSION, inputs=inputs, status=result["status"],
               finding_count=len(result["findings"]), exception_count=len(result["exceptions"]),
               report_dir=str(report_dir))
    (log_dir / f"{run_id}.json").write_text(
        json.dumps(log, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    counts = Counter(row["type_id"] for row in result["findings"])
    print(json.dumps({"status": result["status"], "d4_count": counts["D4"],
                      "finding_counts": {kind: counts[kind] for kind in IMPLEMENTED},
                      "a2_exception_count": len(result["exceptions"]),
                      "report_dir": str(report_dir)}, ensure_ascii=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
