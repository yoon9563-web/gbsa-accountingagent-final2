"""One-command demo: audit -> read-only store -> incident dossier.

python -B src/agent/demo.py                      # 지정된 시범데이터(s10)로 실행, PDF 보고서까지 생성
python -B src/agent/demo.py --input <원장 폴더>  # 다른 원장으로 실행

Runs the existing scripts in order and prints where the human-readable outputs are.
Answer keys are never read. Intermediate store goes to data/db/.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
SAMPLE = ROOT / "data/synthetic/202601-202612-s10"  # 지정된 시범데이터 (비교용 정상 짝: 202601-202612-s10-clean)


def run(command):
    done = subprocess.run([sys.executable, "-B", *command], cwd=ROOT, capture_output=True, text=True)
    lines = done.stdout.strip().splitlines()
    return done.returncode, (json.loads(lines[-1]) if lines else {}), done.stderr


def main():
    parser = argparse.ArgumentParser(description="감사 → 저장소 → 사건 자료철 한 번에 실행")
    parser.add_argument("--input", type=Path, default=SAMPLE)
    parser.add_argument("--no-pdf", action="store_true")
    parser.add_argument("--k", type=int)
    args = parser.parse_args()
    code, audit, err = run(["src/agent/audit.py", "--input", str(args.input)])
    if code != 0:
        stopped = {"status": "audit_stopped", "detail": audit.get("status"), "stderr": err[-300:],
                   "report_dir": audit.get("report_dir")}
        if audit.get("report_dir"):
            rdir = Path(audit["report_dir"])
            try:
                info = json.loads((rdir / "report.json").read_text(encoding="utf-8"))
                stopped["reconciliation_differences"] = {
                    k: {"source": v["source"], "actual": v["actual"], "difference": v["difference"]}
                    for k, v in info.get("reconciliation", {}).items() if v["difference"]}
                if info.get("input_error"):
                    stopped["input_error"] = info["input_error"]
            except (OSError, ValueError, KeyError):
                pass
            if not args.no_pdf:
                _, pdf, _ = run(["src/agent/make_pdf.py", "--report-dir", str(rdir)])
                stopped["pdf"] = pdf.get("pdf") or pdf.get("message")
        print(json.dumps(stopped, ensure_ascii=False))
        return code
    report_dir = Path(audit["report_dir"])
    db = ROOT / "data/db" / f"{args.input.resolve().name}.sqlite"
    code, store, err = run(["src/tools/ledger_store.py", "build", "--input", str(args.input),
                            "--db", str(db), "--replace"])
    if code != 0:
        print(json.dumps({"status": "store_failed", "stderr": err[-300:]}, ensure_ascii=False))
        return code
    command = ["src/agent/dossier.py", "--report", str(report_dir / "report.json"), "--db", str(db)]
    if args.k:
        command += ["--k", str(args.k)]
    code, dossier, err = run(command)
    pdf = {}
    if code == 0 and not args.no_pdf:
        _, pdf, _ = run(["src/agent/make_pdf.py", "--report-dir", str(report_dir)])
    print(json.dumps({"status": "completed" if code == 0 else "dossier_failed",
                      "finding_counts_nonzero": {k: v for k, v in audit.get("finding_counts", {}).items() if v},
                      "report": str(report_dir / "report.md"),
                      "dossier": str(report_dir / "investigation_dossier.md"),
                      "pdf": pdf.get("pdf") or pdf.get("message"),
                      "incidents": dossier.get("incidents")}, ensure_ascii=False))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
