"""시험 채점: 시험자가 낸 report.json을 비공개 정답표와 비교한다.

기본은 건수만 보여 준다(전표 ID는 정답 유출이 되므로). 출제자 점검용으로만 --reveal을 쓴다.
평균 점수 하나로 뭉뚱그리지 않고 유형별로 낸다.
"""

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "evaluation"))
import score_audit  # noqa: E402


def fidelity(report, header_path):
    with header_path.open(encoding="utf-8-sig", newline="") as handle:
        known = {row["je_id"] for row in csv.DictReader(handle)}
    findings = report["findings"]
    bad = [row for row in findings if row.get("je_id") not in known or not row.get("evidence")]
    return dict(total=len(findings), unverifiable=len(bad),
                rate=1.0 if not findings else round(1 - len(bad) / len(findings), 4))


def main():
    parser = argparse.ArgumentParser(description="시험 채점")
    parser.add_argument("report", type=Path, help="시험자의 report.json 또는 보고서 폴더")
    parser.add_argument("--exam", required=True, help="exam_id (예: 20261125-ab12cd)")
    parser.add_argument("--reveal", action="store_true", help="전표 ID까지 표시 (출제자 전용)")
    args = parser.parse_args()
    name = f"exam-{args.exam}"
    label_dir, data_dir = ROOT / "evaluator-only/labels" / name, ROOT / "evaluator-only/synthetic" / name
    try:
        report = score_audit.read_report(args.report)
        anomalies = score_audit.read_labels(label_dir / "anomaly_labels.csv")
        normals = score_audit.read_labels(label_dir / "normal_exceptions.csv")
        results = score_audit.score(report, anomalies, normals)
        fid = fidelity(report, data_dir / "je_header.csv")
    except (OSError, ValueError, KeyError) as exc:
        print(f"채점 실패 · {exc}")
        return 1
    rows = [f"# 시험 채점 — {args.exam}", "",
            f"- 보고서 실행 {report['run_id']} · 도구 버전 {report.get('version', '?')}",
            f"- 근거 충실도: 지적 {fid['total']}건 중 전표 ID·근거를 확인할 수 없는 지적 {fid['unverifiable']}건 ({fid['rate']:.1%}, 목표 100%)",
            "", "## 유형별 결과", "",
            "| 유형 | 상태 | 주입 | 탐지 | 미탐 | 정당 예외 오탐 | 정답표에 없는 후보 |", "|---|---|---:|---:|---:|---:|---:|"]
    summary = {}
    for kind, item in sorted(results.items()):
        if item["status"] == "not_run":
            rows.append(f"| {kind} | 미실행·미구현 | {item['labeled_anomalies']} | - | - | - | - |")
            continue
        if item["status"] == "population_check":
            rows.append(f"| {kind} | 모집단 경보 {item['alert_count']}건 | - | - | - | - | - |")
            continue
        injected = len(item["detected"]) + len(item["missed"]) + len(item["unevaluated"])
        rows.append(f"| {kind} | {'부분' if item['status'] == 'partial' else '채점'} | {injected} | "
                    f"{len(item['detected'])} | {len(item['missed'])} | {len(item['flagged_normal'])} | "
                    f"{len(item['pending_candidates'])} |")
        summary[kind] = dict(injected=injected, detected=len(item["detected"]), missed=len(item["missed"]),
                             flagged_normal=len(item["flagged_normal"]), extra=len(item["pending_candidates"]))
        if args.reveal and (item["missed"] or item["pending_candidates"]):
            rows.append(f"|  | 미탐 {item['missed']} · 후보 {item['pending_candidates']} |  |  |  |  |  |")
    missing_types = [kind for kind, item in results.items() if item["status"] == "not_run" and item["labeled_anomalies"]]
    rows += ["", "## 읽는 법", "",
             "- 주입=정답표의 이상 전표 수, 탐지=그중 지적된 수, 미탐=놓친 수.",
             "- 정당 예외 오탐=일부러 섞은 정상 거래를 이상으로 지적한 수, 정답표에 없는 후보=정답표에도 정상 예외표에도 없는 지적(회계사 판정 대기).",
             "- 미실행·미구현 유형은 재현율 계산에서 제외했고, 그 사실을 표시했다.",
             f"- 정답표에는 있으나 도구가 검사하지 못한 유형: {', '.join(sorted(missing_types)) or '없음'}"]
    out_dir = ROOT / "evaluator-only/exams" / args.exam / "grades"
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = out_dir / report["run_id"]
    text = "\n".join(rows) + "\n"
    stem.with_suffix(".md").write_text(text, encoding="utf-8")
    stem.with_suffix(".json").write_text(json.dumps(dict(exam_id=args.exam, run_id=report["run_id"], fidelity=fid,
                                                         types=summary), ensure_ascii=False, indent=2), encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
