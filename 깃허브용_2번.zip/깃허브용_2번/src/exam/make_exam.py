"""시험용 패키지 생성: 모르는 시드·다른 프로파일로 만든 새 원장을 시험자에게 줄 수 있게 포장한다.

- 정답표는 evaluator-only/labels/exam-<id>/ 에 남고 패키지에는 들어가지 않는다 (탐지·에이전트 단계 열람 금지 폴더).
- 시험자에게는 evaluator-only/exams/<id>/ 의 압축 원장, 안내서, 루브릭만 준다.
- 시드는 무작위로 정해 정답표 폴더에만 기록한다. 생성기 코드는 공개돼 있으므로 시드가 새어도 같은 원장이 재현되는 점은 알려야 한다.
"""

import argparse
import copy
import hashlib
import json
import secrets
import subprocess
import sys
import tempfile
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

VARIANTS = {
    "standard": {},
    "high-volume": {"volume": {"sales_per_business_day": 4.8, "purchases_per_business_day": 1.8,
                               "expenses_per_business_day": 1.8, "cards_per_business_day": 1.8}},
    "small-business": {"volume": {"sales_per_business_day": 1.9, "purchases_per_business_day": 0.8,
                                  "expenses_per_business_day": 0.8, "cards_per_business_day": 0.8},
                       "opening": {"cash": 200000000, "inventory": 60000000,
                                   "equipment": 20000000, "accumulated_depreciation": 4000000}},
    "three-products": {"products": {"SKU1": {"cost": 12000, "markup": 1.35, "share": 0.5},
                                    "SKU2": {"cost": 31000, "markup": 1.18, "share": 0.3},
                                    "SKU3": {"cost": 75000, "markup": 1.12, "share": 0.2}}},
}

GUIDE = """# 시험 안내서 — {exam_id}

가상 회사의 장부(전표 원장)입니다. 이 에이전트가 이상거래를 제대로 찾는지 시험합니다.

## 받은 것
- `{zip_name}`: 원장과 보조자료(압축 파일). 풀면 `je_header.csv`, `je_line.csv`, 거래처·은행·세금계산서 등이 있습니다.
- `RUBRIC.md`: 회계사가 보고서를 평가하는 루브릭.
- 정답표는 의도적으로 들어 있지 않습니다. 정답을 알려고 하지 마세요.

## 하는 일
1. 압축을 풀고 `python src/agent/audit.py --input <풀린 폴더>` 를 실행합니다 (Claude에서는 `/audit`).
2. 생성된 `reports/<run_id>/report.md`를 읽고 RUBRIC.md에 따라 1~5점을 매깁니다.
3. `reports/<run_id>/report.json`을 출제자에게 보내면 채점 결과(유형별 재현율·오탐·근거 충실도)를 돌려받습니다.

## 알아둘 것
- 이 도구는 **검토 보조 도구**입니다. 지적은 오류·부정 징후·정당한 예외의 가능성일 뿐 판정이 아닙니다.
- 일부 유형은 자료가 부족해 검사하지 못합니다. 보고서의 "미검사 유형" 사유와 "기간 기준 검사 — 추가 데이터 필요" 안내를 함께 읽으세요.
- 정상이지만 이상해 보이는 거래(정당한 예외)가 일부러 섞여 있습니다.
- 원장은 가상 데이터이며 생성기와 탐지기를 같은 팀이 설계했으므로, 실제 회사 원장에서도 같은 성능이 나온다는 뜻은 아닙니다.
"""

RUBRIC = """# 회계사 평가 루브릭 — 체크리스트 유용성 (1~5점)

보고서의 상위 지적 5건을 골라 아래 기준으로 점수를 매기고 의견을 적습니다.

| 점수 | 기준 |
|---|---|
| 5 | 무엇을·어디서·무엇과 대조할지 구체적이고, 바로 실행할 수 있으며, 반증 방법까지 있다 |
| 4 | 구체적이고 실행 가능하나 반증 방법이나 우선순위가 부족하다 |
| 3 | 방향은 맞지만 일반적이어서 추가로 추측해야 한다 |
| 2 | 일부만 맞거나 불필요한 항목이 섞여 있다 |
| 1 | 근거가 불충분하거나 틀려서 쓸 수 없다 |

항목별 의견: ① 구체성 ② 실행 가능성 ③ 누락된 확인 사항 ④ 오탐으로 보이는 지적과 이유 ⑤ 놓친 것 같은 거래(있다면)
"""


def merge(base, override):
    out = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = merge(out[key], value)
        else:
            out[key] = value
    return out


def main():
    parser = argparse.ArgumentParser(description="시험용 패키지 생성")
    parser.add_argument("--variant", choices=sorted(VARIANTS), default="standard")
    parser.add_argument("--months", type=int, choices=(6, 12), default=6)
    parser.add_argument("--seed", type=int, help="지정하지 않으면 무작위")
    args = parser.parse_args()
    seed = args.seed if args.seed is not None else secrets.randbelow(900000) + 1000
    start, end = ("2026-04-01", "2026-09-30") if args.months == 6 else ("2026-01-01", "2026-12-31")
    exam_id = f"{date.today():%Y%m%d}-{secrets.token_hex(3)}"
    name = f"exam-{exam_id}"
    base = json.loads((ROOT / "config/generator-profile.json").read_text(encoding="utf-8"))
    profile = merge(base, VARIANTS[args.variant])
    with tempfile.TemporaryDirectory() as scratch:
        temp = Path(scratch) / "profile.json"
        temp.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
        done = subprocess.run([sys.executable, "-B", str(ROOT / "src/generator/generate.py"), "--name", name,
                               "--seed", str(seed), "--start", start, "--end", end, "--profile", str(temp),
                               "--out-root", str(ROOT / "evaluator-only")],
                              capture_output=True, text=True)
    if done.returncode != 0:
        print(json.dumps({"status": "error", "message": done.stdout.strip() or done.stderr.strip()}, ensure_ascii=False))
        return 1
    data_dir, label_dir = ROOT / "evaluator-only/synthetic" / name, ROOT / "evaluator-only/labels" / name
    (label_dir / "exam_private.json").write_text(json.dumps(
        dict(exam_id=exam_id, seed=seed, variant=args.variant, months=args.months, profile=profile),
        ensure_ascii=False, indent=2), encoding="utf-8")
    out = ROOT / "evaluator-only/exams" / exam_id
    out.mkdir(parents=True)
    zip_name = f"{name}-ledger.zip"
    with zipfile.ZipFile(out / zip_name, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(data_dir.iterdir()):
            if path.is_file():
                archive.write(path, f"{name}/{path.name}")
    digest = hashlib.sha256((out / zip_name).read_bytes()).hexdigest()
    (out / "TESTER_GUIDE.md").write_text(GUIDE.format(exam_id=exam_id, zip_name=zip_name), encoding="utf-8")
    (out / "RUBRIC.md").write_text(RUBRIC, encoding="utf-8")
    (out / "exam.json").write_text(json.dumps(
        dict(exam_id=exam_id, period=[start, end], months=args.months, ledger_zip=zip_name, sha256=digest,
             tool_note="시드·프로파일 변형·정답표는 비공개 (evaluator-only/labels/%s)" % name),
        ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(status="completed", exam_id=exam_id, input_dir=str(data_dir), package=str(out),
                          months=args.months, variant=args.variant), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
