"""D4 원장↔보조원장 대사. 통제계정(매출채권·매입채무) 원장 금액을 보조원장과 비교한다.

전표 단위로 (원장 금액 − 보조원장 금액)을 거래처별로 대사하고, 거래처 잔액 차이도 함께 낸다.
읽기 전용 계산만 하며 원장·보조원장을 수정하지 않는다.
"""

from collections import defaultdict

ENTRY_COLUMNS = ["entry_id", "ledger", "counterparty_id", "doc_type", "doc_ref", "doc_date",
                 "je_id", "amount"]


def _int(value, label):
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} 값이 정수가 아닙니다: {value!r}") from None


def subledger_reconciliation(lines, entries, policy):
    """lines: 원장 라인(dict, debit/credit 정수), entries: 보조원장 행(dict).

    반환: (journal_findings, balances, unlinked)
      journal_findings: [(je_id, evidence)], balances: 거래처별 잔액 대사, unlinked: je_id 없는 보조원장 행.
    """
    controls = policy["control_accounts"]
    by_account = {item["account"]: (ledger, item) for ledger, item in controls.items()}
    blank = policy["unassigned_counterparty"]
    tolerance = policy["tolerance"]

    gl = defaultdict(int)
    gl_journals = set()
    for row in lines:
        found = by_account.get(row["account_code"])
        if not found:
            continue
        ledger, item = found
        amount = row["debit"] - row["credit"]
        if item["normal_side"] == "credit":
            amount = -amount
        party = row.get("vendor_id") or blank
        gl[(ledger, row["je_id"], party)] += amount
        gl_journals.add(row["je_id"])

    sub = defaultdict(int)
    sub_balance = defaultdict(int)
    unlinked = []
    for row in entries:
        ledger = row["ledger"]
        if ledger not in controls:
            raise ValueError(f"알 수 없는 보조원장 구분: {ledger!r}")
        amount = _int(row["amount"], "amount")
        party = row["counterparty_id"] or blank
        sub_balance[(ledger, party)] += amount
        if not row["je_id"]:
            unlinked.append(dict(entry_id=row["entry_id"], ledger=ledger, counterparty=party,
                                 doc_ref=row["doc_ref"], amount=amount))
            continue
        sub[(ledger, row["je_id"], party)] += amount

    gl_balance = defaultdict(int)
    for (ledger, _, party), amount in gl.items():
        gl_balance[(ledger, party)] += amount

    per_journal = defaultdict(list)
    for key in sorted(set(gl) | set(sub), key=lambda item: (item[1], item[0], item[2])):
        ledger, je_id, party = key
        difference = gl.get(key, 0) - sub.get(key, 0)
        if abs(difference) > tolerance:
            per_journal[je_id].append(dict(
                ledger=ledger, account=controls[ledger]["account"], counterparty=party,
                gl_amount=gl.get(key, 0), subledger_amount=sub.get(key, 0),
                difference=difference))
    findings = [(je_id, dict(ledger_rows=rows,
                             total_abs_difference=sum(abs(r["difference"]) for r in rows),
                             in_ledger=je_id in gl_journals))
                for je_id, rows in sorted(per_journal.items())]

    balances = []
    for key in sorted(set(gl_balance) | set(sub_balance)):
        ledger, party = key
        difference = gl_balance.get(key, 0) - sub_balance.get(key, 0)
        balances.append(dict(ledger=ledger, account=controls[ledger]["account"],
                             counterparty=party, gl_balance=gl_balance.get(key, 0),
                             subledger_balance=sub_balance.get(key, 0), difference=difference,
                             flagged=abs(difference) > tolerance))
    return findings, balances, unlinked
