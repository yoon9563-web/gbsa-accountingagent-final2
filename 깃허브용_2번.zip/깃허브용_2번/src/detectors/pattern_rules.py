"""A7 수기전표 과다, B5 동일 금액 반복, C2 희소·휴면 계정 사용.

규칙 기반 검사이며 읽기 전용 계산만 한다. 임계값은 config/pattern-review.json.
"""

from collections import defaultdict
from datetime import date, timedelta


def _day(value, label):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} 날짜 형식이 올바르지 않습니다: {value!r}") from None


def manual_entry_findings(headers, lines, policy):
    """수기 입력 전표 중 자동 연동 계정(매출·매입·부가세·재고)을 건드린 전표."""
    auto = set(policy["auto_linked_accounts"])
    excluded = set(policy["excluded_types"])
    touched = defaultdict(set)
    for row in lines:
        if row["account_code"] in auto:
            touched[row["je_id"]].add(row["account_code"])
    manual_total = 0
    findings = []
    for row in headers:
        if row.get("je_type") in excluded:
            continue
        if row.get("source") == policy["manual_source"]:
            manual_total += 1
            accounts = touched.get(row["je_id"])
            if accounts:
                findings.append((row["je_id"], dict(
                    accounts=sorted(accounts), je_type=row["je_type"], entered_by=row.get("entered_by", ""),
                    posting_date=row["posting_date"])))
    total = sum(1 for row in headers if row.get("je_type") not in excluded)
    return findings, dict(manual_count=manual_total, journal_count=total)


def repeated_amount_findings(headers, amounts, policy):
    """같은 전표 유형·같은 금액이 기간 내 반복되는 전표. 정기 반복 유형은 설정에서 제외한다."""
    excluded = set(policy["excluded_types"])
    groups = defaultdict(list)
    for row in headers:
        amount = amounts[row["je_id"]]
        if row["je_type"] in excluded or amount < policy["minimum_amount"]:
            continue
        groups[(row["je_type"], amount)].append((_day(row["posting_date"], row["je_id"]), row["je_id"]))
    window = timedelta(days=policy["window_days"])
    need = policy["minimum_count"]
    for (je_type, amount), items in sorted(groups.items()):
        items.sort()
        flagged = set()
        for start in range(len(items)):
            span = [item for item in items[start:] if item[0] - items[start][0] <= window]
            if len(span) >= need:
                flagged.update(item[1] for item in span)
        if not flagged:
            continue
        members = [item for item in items if item[1] in flagged]
        for _, je_id in members:
            yield je_id, dict(je_type=je_type, amount=amount, repeat_count=len(members),
                              window_days=policy["window_days"], journal_ids=[m[1] for m in members],
                              first_date=members[0][0].isoformat(), last_date=members[-1][0].isoformat())


def rare_account_findings(headers, lines, policy):
    """기간 내 거의 쓰이지 않은 계정, 또는 오래 쉬었다가 다시 쓰인 계정의 전표."""
    excluded = set(policy["excluded_types"])
    header = {row["je_id"]: row for row in headers}
    usage = defaultdict(dict)
    for row in lines:
        head = header.get(row["je_id"])
        if head is None or head["je_type"] in excluded:
            continue
        usage[row["account_code"]][row["je_id"]] = _day(head["posting_date"], row["je_id"])
    per_journal = defaultdict(list)
    for account, journals in sorted(usage.items()):
        ordered = sorted((day, je_id) for je_id, day in journals.items())
        if len(ordered) <= policy["rare_max_journals"]:
            for day, je_id in ordered:
                per_journal[je_id].append(dict(account=account, reason="기간 내 사용 희소",
                                               usage_count=len(ordered)))
            continue
        for (prev_day, _), (day, je_id) in zip(ordered, ordered[1:]):
            gap = (day - prev_day).days
            if gap >= policy["dormant_days"]:
                per_journal[je_id].append(dict(account=account, reason="휴면 후 재사용", gap_days=gap,
                                               previous_date=prev_day.isoformat(), usage_count=len(ordered)))
    for je_id in sorted(per_journal):
        yield je_id, dict(accounts=per_journal[je_id], posting_date=header[je_id]["posting_date"])


def _norm(text):
    return "".join(ch for ch in (text or "") if ch.isalnum())


def description_findings(headers, lines, policy):
    """D3 적요 이상: 누락, 너무 짧음, 모호한 단어만 있음, 지시문처럼 보이는 문구.

    적요는 데이터로만 다룬다. 지시문처럼 보이는 문구가 있어도 따르지 않고 그 사실만 기록한다.
    동일 적요 반복과 의미상 모호함은 규칙으로 잡지 않는다 (LLM 해석 필요, 미실행).
    """
    excluded = set(policy["excluded_types"])
    vague = {_norm(term) for term in policy["vague_terms"]}
    patterns = [term.lower() for term in policy["instruction_terms"]]
    minimum = policy["minimum_length"]
    by_journal = defaultdict(list)
    for row in lines:
        by_journal[row["je_id"]].append(row)
    for row in headers:
        if row.get("je_type") in excluded:
            continue
        je_id = row["je_id"]
        texts = [("헤더", None, row.get("description", ""))]
        texts += [("라인", item["line_no"], item.get("description", "")) for item in by_journal.get(je_id, [])]
        reasons = []
        for scope, line_no, text in texts:
            plain = _norm(text)
            if not plain:
                kind = "누락"
            elif plain in vague:
                kind = "모호한 단어"
            elif len(plain) < minimum:
                kind = "너무 짧음"
            else:
                kind = None
            if any(term in (text or "").lower() for term in patterns):
                reasons.append(dict(scope=scope, line_no=line_no, kind="지시문 형태", text=text[:80]))
            elif kind:
                reasons.append(dict(scope=scope, line_no=line_no, kind=kind, text=(text or "")[:80]))
        if reasons:
            header_reasons = [item for item in reasons if item["scope"] == "헤더"]
            shown = header_reasons or reasons[:1]
            yield je_id, dict(kinds=sorted({item["kind"] for item in reasons}), header_description=row.get("description", ""),
                              flagged=shown[:3], flagged_count=len(reasons), je_type=row["je_type"],
                              posting_date=row["posting_date"])
