"""Journal and population checks for the MVP."""

from collections import Counter, defaultdict
from datetime import date, timedelta
from math import log10, pi, sqrt

from .review_rules import ordered_company_sequences


def journal_amounts(lines):
    amounts = Counter()
    for row in lines:
        amounts[row["je_id"]] += row["debit"]
    return amounts


def closing_findings(headers, amounts, control, policy):
    start = date.fromisoformat(control["period_start"])
    close = date.fromisoformat(control["period_end"])
    before = policy["closing_days_before"]
    after = policy["closing_days_after"]
    multiple = policy["closing_rate_multiple"]
    minimum = policy["closing_minimum_journals"]
    if min(before, after) < 0 or multiple <= 1 or minimum < 1:
        raise ValueError("마감 창 또는 집중 기준이 올바르지 않습니다.")
    window_start = close - timedelta(days=before)
    baseline_days = (window_start - start).days
    if baseline_days < 1:
        raise ValueError("마감 전 비교 기간이 부족합니다.")
    baseline, window = [], []
    for row in headers:
        day = date.fromisoformat(row["posting_date"])
        if row["je_type"] == "기초":
            continue
        if start <= day < window_start:
            baseline.append(row["je_id"])
        elif window_start <= day <= close + timedelta(days=after):
            window.append((day, row["je_id"]))
    if not baseline:
        raise ValueError("마감 창 비교 대상 전표가 없습니다.")
    observed_after = max(((day - close).days for day, _ in window), default=0)
    window_days = before + 1 + max(0, observed_after)
    baseline_rate = len(baseline) / baseline_days
    current_rate = len(window) / window_days
    baseline_value = sum(amounts[key] for key in baseline) / baseline_days
    current_value = sum(amounts[key] for _, key in window) / window_days
    if len(window) >= minimum and (
        current_rate >= baseline_rate * multiple or current_value >= baseline_value * multiple
    ):
        yield None, {
            "window_start": window_start.isoformat(), "close_date": close.isoformat(),
            "observed_after_days": max(0, observed_after), "window_count": len(window),
            "daily_count": round(current_rate, 2), "baseline_daily_count": round(baseline_rate, 2),
            "daily_debit": round(current_value), "baseline_daily_debit": round(baseline_value),
            "rate_multiple_threshold": multiple,
            "journal_ids": sorted(key for _, key in window),
        }


def round_amount_findings(headers, amounts, policy):
    unit = policy["round_unit"]
    minimum = policy["round_minimum_journals"]
    share = policy["round_share_percent"]
    if unit < 2 or minimum < 2 or not 0 < share <= 100:
        raise ValueError("정액 검사 단위 또는 비중 기준이 올바르지 않습니다.")
    excluded = set(policy["round_excluded_types"])
    groups = defaultdict(list)
    for row in headers:
        key = row["je_id"]
        if row["je_type"] not in excluded and amounts[key] > 0:
            groups[row["company_code"], row["je_type"]].append(key)
    for (_, kind), ids in groups.items():
        rounded = [key for key in ids if amounts[key] % unit == 0]
        if len(ids) >= minimum and len(rounded) * 100 >= share * len(ids):
            for key in rounded:
                yield key, {
                    "journal_type": kind, "amount": amounts[key], "unit": unit,
                    "rounded_count": len(rounded), "sample_count": len(ids),
                    "threshold_percent": share,
                }


def expected_benford_mad(sample_count, position):
    """벤포드를 완전히 따르는 표본의 기대 MAD (이항 근사). 표본이 작을수록 커진다."""
    digits = range(1, 10) if position == 1 else range(10)
    total = 0.0
    for digit in digits:
        p = sum(log10(1 + 1 / prefix) for prefix in
                ([digit] if position == 1 else range(10 + digit, 100, 10)))
        total += sqrt(2 / pi * p * (1 - p) / sample_count)
    return total / len(digits)


def benford_summaries(headers, amounts, policy):
    minimum = policy["benford_minimum_journals"]
    thresholds = policy["benford_mad_thresholds"]
    if minimum < 1 or any(not 0 < thresholds[str(p)] < 1 for p in (1, 2)):
        raise ValueError("벤포드 최소 표본 또는 MAD 기준이 올바르지 않습니다.")
    groups = defaultdict(list)
    for row in headers:
        amount = amounts[row["je_id"]]
        if amount >= 10 and row["je_type"] not in policy["round_excluded_types"]:
            groups[row["company_code"]].append(str(amount))
    for company, values in groups.items():
        for position in (1, 2):
            if len(values) < minimum or max(map(len, values)) == min(map(len, values)):
                continue
            digits = range(1, 10) if position == 1 else range(10)
            observed = Counter(int(value[position - 1]) for value in values)
            distribution = []
            for digit in digits:
                prefixes = [digit] if position == 1 else range(10 + digit, 100, 10)
                expected = sum(log10(1 + 1 / prefix) for prefix in prefixes)
                distribution.append({"digit": digit, "observed": observed[digit] / len(values),
                                     "expected": expected})
            mad = sum(abs(item["observed"] - item["expected"])
                      for item in distribution) / len(distribution)
            expected_mad = expected_benford_mad(len(values), position)
            threshold = max(thresholds[str(position)],
                            policy.get("benford_null_multiple", 0) * expected_mad)
            yield {
                "company_code": company, "position": position, "sample_count": len(values),
                "mad": mad, "threshold": threshold, "expected_mad": expected_mad,
                "base_threshold": thresholds[str(position)], "flagged": mad > threshold,
                "distribution": distribution,
            }


def account_combination_findings(headers, by_journal, minimum):
    if minimum < 2:
        raise ValueError("계정 출현 최소 기준은 2 이상이어야 합니다.")
    signatures = {}
    frequencies = Counter()
    account_counts = Counter()
    for row in headers:
        key, company = row["je_id"], row["company_code"]
        if row["je_type"] == "기초":
            continue
        lines = by_journal[key]
        debit = tuple(sorted({line["account_code"] for line in lines if line["debit"]}))
        credit = tuple(sorted({line["account_code"] for line in lines if line["credit"]}))
        if debit and credit:
            signatures[key] = company, debit, credit
            frequencies[company, debit, credit] += 1
            account_counts.update((company, code) for code in set(debit + credit))
    for key, (company, debit, credit) in signatures.items():
        count = frequencies[company, debit, credit]
        if count == 1 and all(account_counts[company, code] >= minimum for code in debit + credit):
            yield key, {"debit_accounts": debit, "credit_accounts": credit, "occurrences": count}


def account_direction_findings(lines, coa, accounts):
    directions = {row["계정코드"]: row["정상잔액방향"] for row in coa}
    if any(directions.get(code) not in {"차변", "대변"} for code in accounts):
        raise ValueError("방향 검사 계정의 정상잔액방향이 누락됐습니다.")
    for line in lines:
        code = line["account_code"]
        if code not in accounts:
            continue
        expected = directions[code]
        other = line["credit"] if expected == "차변" else line["debit"]
        if other:
            yield line["je_id"], {
                "line_no": int(line["line_no"]), "account_code": code,
                "expected_side": expected, "actual_side": "대변" if expected == "차변" else "차변",
                "amount": other,
            }


def repeated_reversal_findings(headers, by_journal):
    documents = {row["je_id"]: row["document_id"].strip() for row in headers}
    for company, ordered in ordered_company_sequences(headers).items():
        groups = defaultdict(list)
        for _, key in ordered:
            if documents[key]:
                lines = by_journal[key]
                signature = tuple(sorted((r["account_code"], r["debit"], r["credit"]) for r in lines))
                reverse = tuple(sorted((account, credit, debit) for account, debit, credit in signature))
                if signature != reverse and sum(item[1] for item in signature) == sum(item[2] for item in signature):
                    groups[documents[key], min(signature, reverse)].append((key, signature))
        for (document, _), entries in groups.items():
            for first, middle, last in zip(entries, entries[1:], entries[2:]):
                if first[1] == last[1] and first[1] != middle[1]:
                    yield last[0], {
                        "company_code": company, "document_id": document,
                        "journal_ids": [first[0], middle[0], last[0]],
                    }
