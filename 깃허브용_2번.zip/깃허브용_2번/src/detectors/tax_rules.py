"""I4 세금(부가세) 불일치와 F3 세금계산서 없는 매출.

전표의 부가세 라인(2100 매출세액, 1200 매입세액)을 세금계산서와 전표 단위로 대사한다.
- 세금계산서 금액이 장부와 다름 → I4
- 매입 전표에 세금계산서가 없음(매입세액 증빙 없음) → I4
- 매출 전표에 세금계산서가 없음 → F3 (대응 입금 여부를 함께 표시)
- 전표와 연결되지 않은 세금계산서는 요약 목록에 둔다.
발행일은 비교하지 않는다(월합계 발행 관행). 읽기 전용 계산만 한다.
"""

from collections import defaultdict
from datetime import date

INVOICE_COLUMNS = ["tax_invoice_id", "direction", "issue_date", "counterparty_id", "doc_ref",
                   "je_id", "supply_amount", "vat_amount"]


def _int(value, label):
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} 값이 정수가 아닙니다: {value!r}") from None


def _quarter(day):
    value = date.fromisoformat(day)
    return f"{value.year}-Q{(value.month - 1) // 3 + 1}"


def tax_reconciliation(lines, headers, invoices, policy, received_docs=None):
    header = {row["je_id"]: row for row in headers}
    accounts = {policy["sales_vat_account"], policy["sales_supply_account"],
                policy["purchase_vat_account"], policy["purchase_supply_account"]}
    sums = defaultdict(lambda: defaultdict(int))
    for row in lines:
        if row["account_code"] in accounts:
            sums[row["je_id"]][row["account_code"]] += row["debit"] - row["credit"]

    book = {}
    for je_id, values in sums.items():
        out_vat = -values.get(policy["sales_vat_account"], 0)
        in_vat = values.get(policy["purchase_vat_account"], 0)
        if out_vat != 0:
            book[je_id] = ("매출", -values.get(policy["sales_supply_account"], 0), out_vat)
        elif in_vat != 0:
            book[je_id] = ("매입", values.get(policy["purchase_supply_account"], 0), in_vat)

    linked = defaultdict(list)
    unlinked = []
    for row in invoices:
        supply, vat = _int(row["supply_amount"], "supply_amount"), _int(row["vat_amount"], "vat_amount")
        item = dict(tax_invoice_id=row["tax_invoice_id"], direction=row["direction"],
                    issue_date=row["issue_date"], supply=supply, vat=vat, doc_ref=row["doc_ref"])
        if row["je_id"] and row["je_id"] in header:
            linked[row["je_id"]].append(item)
        else:
            unlinked.append(item)

    tolerance = policy["tolerance"]
    findings = []
    for je_id in sorted(book):
        direction, supply, vat = book[je_id]
        document = header[je_id]["document_id"]
        rows = [item for item in linked.get(je_id, []) if item["direction"] == direction]
        if not rows:
            evidence = dict(direction=direction, document_id=document,
                            posting_date=header[je_id]["posting_date"], book_supply=supply, book_vat=vat)
            if direction == "매출":
                evidence["receipt_found"] = None if received_docs is None else document in received_docs
                findings.append(("F3", je_id, evidence))
            else:
                evidence["reason"] = "매입세액 공제 증빙(세금계산서) 없음"
                findings.append(("I4", je_id, evidence))
            continue
        inv_supply, inv_vat = sum(i["supply"] for i in rows), sum(i["vat"] for i in rows)
        if abs(vat - inv_vat) > tolerance or abs(supply - inv_supply) > tolerance:
            findings.append(("I4", je_id, dict(
                direction=direction, document_id=document, posting_date=header[je_id]["posting_date"],
                reason="세액 차이" if abs(vat - inv_vat) > tolerance else "공급가액 차이",
                book_supply=supply, invoice_supply=inv_supply, book_vat=vat, invoice_vat=inv_vat,
                vat_difference=vat - inv_vat, supply_difference=supply - inv_supply,
                tax_invoice_ids=[i["tax_invoice_id"] for i in rows])))

    periods = defaultdict(lambda: defaultdict(int))
    for je_id, (direction, _, vat) in book.items():
        periods[_quarter(header[je_id]["posting_date"])][f"book_{direction}"] += vat
    for rows in linked.values():
        for item in rows:
            periods[_quarter(item["issue_date"])][f"invoice_{item['direction']}"] += item["vat"]
    for item in unlinked:
        periods[_quarter(item["issue_date"])][f"invoice_{item['direction']}"] += item["vat"]
    summary = dict(
        invoice_count=len(invoices), unlinked=unlinked,
        periods=[dict(period=key, sales_book=v["book_매출"], sales_invoice=v["invoice_매출"],
                      purchase_book=v["book_매입"], purchase_invoice=v["invoice_매입"])
                 for key, v in sorted(periods.items())])
    return findings, summary
