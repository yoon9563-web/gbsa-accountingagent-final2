"""Evidence for duplicate documents and out-of-hours journal entry."""

from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
import json
from statistics import median


def payroll_amount_findings(rows):
    for row in rows:
        base = int(row["base_salary"])
        bonus = int(row["approved_bonus"])
        paid = int(row["gross_paid"])
        difference = paid - (base + bonus)
        if difference:
            yield row["je_id"], {
                "actual_amount": paid,
                "reference_amount": base + bonus,
                "difference": difference,
                "base_salary": base,
                "approved_bonus": bonus,
            }


def unit_price_findings(rows):
    products = defaultdict(list)
    for row in rows:
        price = int(row["unit_price"])
        if price <= 0 or not row["product_id"].strip():
            raise ValueError("상품 코드와 양수 단가가 필요합니다.")
        products[row["product_id"]].append((row["je_id"], price))
    for product, entries in products.items():
        if len(entries) < 6:
            continue
        for index, (je_id, price) in enumerate(entries):
            peers = [amount for _, amount in entries[:index] + entries[index + 1:]]
            reference = median(peers)
            difference = price - reference
            if abs(difference) * 10 > reference * 3:
                yield je_id, {
                    "product_id": product,
                    "actual_amount": price,
                    "reference_amount": reference,
                    "difference": difference,
                    "peer_count": len(peers),
                }


def near_card_limit_findings(transactions, limits, near_basis_points, journal_ids):
    if type(near_basis_points) is not int or not 1 <= near_basis_points < 10_000:
        raise ValueError("한도 직하 기준은 1~9,999bp 사이의 정수여야 합니다.")
    for row, amount, limit in card_payments(transactions, limits, journal_ids):
        gap = limit - amount
        if amount > 0 and 0 < gap * 10_000 <= limit * near_basis_points:
            yield row["je_id"], {
                "amount": amount,
                "per_transaction_limit": limit,
                "gap": gap,
                "near_limit_basis_points": near_basis_points,
            }


def card_payments(transactions, limits, journal_ids):
    by_card = {}
    for row in limits:
        card = row["card_id"]
        limit = int(row["per_transaction_limit"])
        if not card.strip() or card in by_card or limit <= 0:
            raise ValueError("카드 한도표에서 비어 있거나 중복된 카드 또는 유효하지 않은 한도가 발견됐습니다.")
        by_card[card] = limit
    for row in transactions:
        je_id = row["je_id"]
        if je_id not in journal_ids or row["card_id"] not in by_card:
            raise ValueError("카드 거래와 연결되는 전표 또는 카드 한도가 없습니다.")
        yield row, int(row["amount"]), by_card[row["card_id"]]


def split_card_payment_findings(transactions, limits, journal_ids, companies):
    groups = defaultdict(dict)
    for row, amount, limit in card_payments(transactions, limits, journal_ids):
        transaction_id = row["transaction_id"].strip()
        order_ref = row["order_ref"].strip()
        vendor = row["vendor_id"].strip()
        company = companies.get(row["je_id"], "").strip()
        if not order_ref or not vendor or not company or not transaction_id:
            raise ValueError("B6에 회사, 발주, 공급업체, 거래 ID가 필요합니다.")
        group = groups[company, vendor, row["card_id"], order_ref, limit]
        payment = {"transaction_id": transaction_id, "je_id": row["je_id"], "amount": amount}
        if transaction_id in group and group[transaction_id] != payment:
            raise ValueError("동일 카드 거래 ID에 서로 다른 전표나 금액이 연결돼 있습니다.")
        group[transaction_id] = payment
    for (_, _, _, order_ref, limit), group in groups.items():
        payments = [item for item in group.values() if item["amount"] > 0]
        total = sum(item["amount"] for item in payments)
        if len(payments) < 2 or total <= limit or any(item["amount"] > limit for item in payments):
            continue
        for je_id in sorted({item["je_id"] for item in payments}):
            yield je_id, {
                "order_ref": order_ref, "payment_count": len(payments),
                "total_amount": total, "per_transaction_limit": limit,
                "excess": total - limit, "payments": payments,
            }

A2_EXCEPTION_COLUMNS = (
    "evidence_id", "kind", "company_code", "je_id", "source", "je_type",
    "from_date", "to_date", "start_time", "end_time", "weekdays",
)


def compile_a2_exceptions(rows):
    rules = []
    ids = set()
    for row in rows:
        for field in ("evidence_id", "company_code", "source", "je_type"):
            if not row[field].strip():
                raise ValueError(f"A2 예외 일정에 {field} 값이 필요합니다.")
        kind = row["kind"]
        if not (
            (kind == "approval" and row["je_id"].strip())
            or (kind == "batch" and not row["je_id"] and row["source"] == "자동")
        ):
            raise ValueError("승인 예외는 전표 ID가, 배치 일정은 자동 입력 조건이 필요합니다.")
        first = date.fromisoformat(row["from_date"])
        last = date.fromisoformat(row["to_date"])
        start = time.fromisoformat(row["start_time"])
        end = time.fromisoformat(row["end_time"])
        days = {int(day) for day in row["weekdays"].split("|")}
        if first > last or not time.min <= start < end <= time.max or not days <= set(range(7)):
            raise ValueError("A2 예외 일정의 날짜·시간·요일 범위가 잘못됐습니다.")
        if row["evidence_id"] in ids:
            raise ValueError("A2 예외 근거 ID가 중복됐습니다.")
        ids.add(row["evidence_id"])
        rules.append((row, first, last, start, end, days))
    return rules


def a2_exception_evidence(header, entered_at, rules):
    stamp = datetime.fromisoformat(entered_at)
    return [
        rule for rule, first, last, start, end, days in rules
        if all(header.get(field) == rule[field] for field in ("company_code", "source", "je_type"))
        and (rule["kind"] == "batch" or header["je_id"] == rule["je_id"])
        and first <= stamp.date() <= last
        and stamp.weekday() in days
        and start <= stamp.time() < end
    ]


def duplicates(rows, party_field, document_field, date_field, amount_field, journal_ids):
    groups = defaultdict(dict)
    for row in rows:
        je_id = row["je_id"]
        if je_id not in journal_ids:
            raise ValueError("보조자료에 원장에 없는 전표 ID가 있습니다.")
        party, document = row[party_field].strip(), row[document_field].strip()
        if party and document:
            transaction_date = date.fromisoformat(row[date_field]).isoformat()
            groups[party, document][je_id] = {
                "je_id": je_id, "date": transaction_date, "amount": int(row[amount_field])
            }
    for (_, document), entries in groups.items():
        if len(entries) > 1:
            journals = sorted(entries.values(), key=lambda row: (row["date"], row["je_id"]))
            yield journals[-1]["je_id"], {
                "document_id": document, "document_type": document_field, "journals": journals
            }


def out_of_hours(headers, policy_path):
    policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
    local_tz = timezone(timedelta(minutes=policy["utc_offset_minutes"]))
    start, end = (time.fromisoformat(policy[key]) for key in ("start", "end"))
    if not time.min <= start < end <= time.max:
        raise ValueError("업무시간 시작과 종료를 같은 날짜 안에서 설정하세요.")
    holidays = {date.fromisoformat(day) for day in policy["holidays"]}
    if headers and any(not row.get("entered_at") for row in headers):
        raise ValueError("입력일시가 누락된 전표가 있습니다.")
    user_hours = defaultdict(lambda: defaultdict(int))
    user_total = defaultdict(int)
    for row in headers:
        stamp = datetime.fromisoformat(row["entered_at"])
        if stamp.utcoffset() is None:
            raise ValueError("입력일시에 원천 시간대 오프셋이 필요합니다.")
        who = row.get("entered_by", "")
        user_hours[who][stamp.astimezone(local_tz).hour] += 1
        user_total[who] += 1
    for row in headers:
        stamp = datetime.fromisoformat(row["entered_at"])
        local = stamp.astimezone(local_tz)
        reasons = []
        if local.weekday() >= 5:
            reasons.append("주말")
        if local.date() in holidays:
            reasons.append("설정된 휴무일")
        if not start <= local.time() < end:
            reasons.append("업무시간 밖")
        if reasons:
            minutes = local.hour * 60 + local.minute
            gap = max(start.hour * 60 + start.minute - minutes,
                      minutes - (end.hour * 60 + end.minute) + 1, 0)
            weekend_part = 0.25 if ("주말" in reasons or "설정된 휴무일" in reasons) else 0
            who = row.get("entered_by", "")
            share = user_hours[who][local.hour] / user_total[who] if user_total[who] else 1.0
            user_part = 0.15 * (1 - min(share / 0.05, 1)) if user_total[who] >= 20 else 0.0
            score = min(1.0, 0.3 + weekend_part + 0.3 * min(gap / 240, 1) + user_part)
            yield row["je_id"], {
                "entered_at": local.isoformat(), "start": start.isoformat(timespec="minutes"),
                "end": end.isoformat(timespec="minutes"), "reasons": reasons,
                "minutes_outside_window": gap, "user_hour_share": round(share, 4), "score": round(score, 3)
            }


def approval_findings(headers):
    required = {"entered_by", "approved_by"}
    if any(not required.issubset(row) for row in headers):
        raise ValueError("입력자 또는 승인자 열이 없어 A6을 실행할 수 없습니다.")
    if headers and all(not row["approved_by"].strip() for row in headers):
        raise ValueError("승인자가 모든 전표에서 비어 있어 A6을 실행할 수 없습니다(승인 자료 없음).")

    for row in headers:
        entered_by = row["entered_by"].strip()
        approved_by = row["approved_by"].strip()
        if not approved_by:
            reason = "승인자 미기록"
        elif entered_by and entered_by == approved_by:
            reason = "입력자와 승인자가 동일"
        else:
            continue
        yield row["je_id"], {"reason": reason}


def posting_date_findings(headers, policy_path):
    policy = json.loads(policy_path.read_text(encoding="utf-8-sig"))
    limit = policy["max_days_between_entry_and_posting"]
    if type(limit) is not int or limit < 0:
        raise ValueError("A4 기준은 0 이상의 정수 일수여야 합니다.")
    local_tz = timezone(timedelta(minutes=policy["utc_offset_minutes"]))

    for row in headers:
        if not row.get("entered_at") or not row.get("posting_date"):
            raise ValueError("입력일시 또는 전기일이 누락된 전표가 있습니다.")
        stamp = datetime.fromisoformat(row["entered_at"])
        if stamp.utcoffset() is None:
            raise ValueError("입력일시에 원천 시간대 오프셋이 필요합니다.")
        entered = stamp.astimezone(local_tz).date()
        posted = date.fromisoformat(row["posting_date"])
        days = (entered - posted).days
        if abs(days) > limit:
            yield row["je_id"], {
                "posting_date": posted.isoformat(),
                "entry_date": entered.isoformat(),
                "difference_days": days,
                "threshold_days": limit,
                "reason": "소급 입력" if days > 0 else "후일자 전기",
                "score": 1.0 if limit == 0 else round(min(1.0, 0.2 + 0.8 * (abs(days) / limit - 1) / 3), 3),
            }


def ordered_company_sequences(headers):
    companies = defaultdict(list)
    for row in headers:
        company = row.get("company_code", "").strip()
        sequence = row.get("sequence_no", "").strip()
        if not company or not sequence.isascii() or not sequence.isdecimal():
            raise ValueError("회사코드와 양의 정수 전표번호가 필요합니다.")
        number = int(sequence)
        if number < 1:
            raise ValueError("전표번호는 1 이상이어야 합니다.")
        companies[company].append((number, row["je_id"]))

    return {company: sorted(entries) for company, entries in sorted(companies.items())}


def sequence_gap_findings(headers):
    for company, ordered in ordered_company_sequences(headers).items():
        for (previous, previous_id), (current, current_id) in zip(ordered, ordered[1:]):
            if current - previous <= 1:
                continue
            yield current_id, {
                "company_code": company,
                "previous_je_id": previous_id,
                "previous_sequence": previous,
                "next_sequence": current,
                "missing_from": previous + 1,
                "missing_to": current - 1,
                "missing_count": current - previous - 1,
            }


def posting_order_findings(headers):
    posting_dates = {
        row["je_id"]: date.fromisoformat(row.get("posting_date", "")) for row in headers
    }
    for company, ordered in ordered_company_sequences(headers).items():
        for (previous, previous_id), (current, current_id) in zip(ordered, ordered[1:]):
            previous_date = posting_dates[previous_id]
            current_date = posting_dates[current_id]
            if previous == current or current_date >= previous_date:
                continue
            yield current_id, {
                "company_code": company,
                "previous_je_id": previous_id,
                "previous_sequence": previous,
                "next_sequence": current,
                "previous_posting_date": previous_date.isoformat(),
                "posting_date": current_date.isoformat(),
                "days_earlier": (previous_date - current_date).days,
            }
