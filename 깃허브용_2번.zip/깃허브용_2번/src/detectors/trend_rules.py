"""I1 월별 추이 급변, I2 비율 이상(매출총이익률), I3 연관 계정 비동조(매출 대비 매출채권).

월 단위 집계 위에서 '나머지 달'의 중앙값·MAD(중앙값 절대편차)와 비교하는 결정적 규칙이다.
모든 지적은 그 달의 편차에 가장 크게 기여한 전표를 je_id로 내세워 역추적할 수 있게 한다.
임계값은 config/trend-review.json. 읽기 전용 계산만 한다.
"""

from collections import defaultdict
from statistics import median

MAD_SCALE = 1.4826


def _month(row):
    return row["posting_date"][:7]


def _robust(values):
    center = median(values)
    return center, MAD_SCALE * median(abs(value - center) for value in values)


def _monthly(headers, lines, excluded):
    """계정·월별 순액(차변-대변)과 전표별 기여액을 모은다."""
    header = {row["je_id"]: row for row in headers if row.get("je_type") not in excluded}
    net = defaultdict(lambda: defaultdict(int))
    debit = defaultdict(lambda: defaultdict(int))
    credit = defaultdict(lambda: defaultdict(int))
    parts = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for row in lines:
        head = header.get(row["je_id"])
        if head is None:
            continue
        month, account = _month(head), row["account_code"]
        amount = row["debit"] - row["credit"]
        net[account][month] += amount
        debit[account][month] += row["debit"]
        credit[account][month] += row["credit"]
        parts[account][month][row["je_id"]] += amount
    months = sorted({_month(head) for head in header.values()})
    return months, net, debit, credit, parts


def _top(contributions, count, key=lambda value: abs(value)):
    ranked = sorted(contributions.items(), key=lambda item: (-key(item[1]), item[0]))
    return [dict(je_id=je_id, amount=amount) for je_id, amount in ranked[:count]]


def account_break_findings(headers, lines, policy):
    """I1: 안정적인 계정의 월 순액이 나머지 달의 흐름에서 벗어난 달."""
    months, net, *_, parts = _monthly(headers, lines, set(policy["excluded_types"]))
    for account in policy["accounts"]:
        series = {month: abs(net[account].get(month, 0)) for month in months}
        for month in months:
            others = [value for key, value in series.items() if key != month]
            if len(others) < 3:
                continue
            center, spread = _robust(others)
            if center < policy["minimum_median"]:
                continue
            floor = policy.get("account_overrides", {}).get(account, {}).get("relative_floor", policy["relative_floor"])
            limit = max(policy["mad_multiple"] * spread, floor * center)
            deviation = series[month] - center
            if abs(deviation) > limit:
                top = _top(parts[account][month], 3, key=lambda value: abs(value))
                yield top[0]["je_id"], dict(
                    month=month, account=account, value=series[month], baseline=round(center),
                    limit=round(limit), deviation=round(deviation), top_journals=top)


def margin_findings(headers, lines, policy):
    """I2: 월 매출총이익률 이탈, 또는 매출 없이 원가만 단독으로 잡힌 전표가 큰 달.

    상품 구성이 달라지면 이익률이 정당하게 흔들려 이탈만으로는 놓칠 수 있으므로,
    매출과 연결되지 않은 원가 전표(재고 평가 조정 등)는 따로 비중으로 본다.
    """
    revenue_account, cost_account = policy["revenue_account"], policy["cost_account"]
    months, net, debit, credit, parts = _monthly(headers, lines, set(policy["excluded_types"]))
    margin = {}
    for month in months:
        revenue = -net[revenue_account].get(month, 0)
        cost = net[cost_account].get(month, 0)
        if revenue >= policy["minimum_revenue"]:
            margin[month] = (100.0 * (revenue - cost) / revenue, revenue, cost)
    for month, (value, revenue, cost) in margin.items():
        others = [item[0] for key, item in margin.items() if key != month]
        if len(others) < 3:
            continue
        center, spread = _robust(others)
        limit = max(policy["mad_multiple"] * spread, policy["floor_points"])
        revenue_part, cost_part = parts[revenue_account][month], parts[cost_account][month]
        one_sided = {je_id: amount for je_id, amount in cost_part.items() if je_id not in revenue_part}
        one_sided_ratio = sum(one_sided.values()) / revenue
        by_margin = abs(value - center) > limit
        by_cost_only = one_sided_ratio >= policy["one_sided_cost_ratio"]
        if not by_margin and not by_cost_only:
            continue
        expected_cost = revenue * (1 - center / 100.0)
        if by_cost_only:
            top = _top(one_sided, 3)
        else:
            by_journal = defaultdict(float)
            for je_id, amount in cost_part.items():
                by_journal[je_id] += amount
            for je_id, amount in revenue_part.items():
                by_journal[je_id] += amount * (1 - center / 100.0)
            top = _top(by_journal, 3)
        evidence = dict(
            month=month, margin_percent=round(value, 2), baseline_percent=round(center, 2),
            limit_points=round(limit, 2), deviation_points=round(value - center, 2),
            revenue=revenue, cost=cost, expected_cost=round(expected_cost),
            reason="매출 없이 원가만 잡힌 전표" if by_cost_only else "이익률 이탈",
            one_sided_cost_ratio=round(one_sided_ratio, 4), top_journals=top)
        # 최상위의 40% 이상 기여한 전표는 모두 지적한다. 매출 구성 차이와 원가 조정이 섞일 수 있어
        # 회계사가 기여 크기로 가려낸다.
        for item in top:
            if abs(item["amount"]) >= 0.4 * abs(top[0]["amount"]):
                yield item["je_id"], dict(evidence, this_journal_amount=round(item["amount"]))


def receivable_sync_findings(headers, lines, policy):
    """I3: 매출(공급가액+부가세) 대비 매출채권 증가 비율이 나머지 달과 다른 달."""
    months, net, debit, credit, parts = _monthly(headers, lines, set(policy["excluded_types"]))
    sales, vat, receivable = policy["sales_account"], policy["vat_account"], policy["receivable_account"]
    ratio = {}
    for month in months:
        gross = credit[sales].get(month, 0) + credit[vat].get(month, 0)
        if gross >= policy["minimum_sales"]:
            ratio[month] = (debit[receivable].get(month, 0) / gross, gross)
    for month, (value, gross) in ratio.items():
        others = [item[0] for key, item in ratio.items() if key != month]
        if len(others) < 3:
            continue
        center, spread = _robust(others)
        limit = max(policy["mad_multiple"] * spread, policy["floor_ratio"])
        if abs(value - center) <= limit:
            continue
        sales_part, receivable_part = defaultdict(int), defaultdict(int)
        for je_id, amount in parts[sales][month].items():
            sales_part[je_id] -= amount
        for je_id, amount in parts[receivable][month].items():
            receivable_part[je_id] += amount
        gap = {je_id: sales_part.get(je_id, 0) - receivable_part.get(je_id, 0)
               for je_id in set(sales_part) | set(receivable_part)}
        top = _top(gap, 3)
        yield top[0]["je_id"], dict(
            month=month, receivable_ratio=round(value, 3), baseline_ratio=round(center, 3),
            limit=round(limit, 3), sales_with_vat=gross, receivable_debit=debit[receivable].get(month, 0),
            top_journals=top)
