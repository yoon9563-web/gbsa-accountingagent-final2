"""F1 기말 매출 후 기초 반품, F2 채권 회전 악화.

F1: 월말 직전에 잡은 매출이 다음 달 초에 같은 거래처로 대부분 환입된 쌍.
F2: 월별 매출채권 회전일수(월말 잔액 ÷ 그 달 매출채권 발생액 × 일수)가 이전 달들보다 크게 늘어난 달.
임계값은 config/receivable-review.json. 읽기 전용 계산만 한다.
"""

from calendar import monthrange
from collections import defaultdict, deque
from datetime import date, timedelta
from statistics import median

MAD_SCALE = 1.4826


def _day(value):
    return date.fromisoformat(value)


def _customer_journals(headers, lines, policy):
    header = {row["je_id"]: row for row in headers if row.get("je_type") not in policy["excluded_types"]}
    sales, returns = {}, {}
    revenue = defaultdict(int)
    for row in lines:
        if row["je_id"] in header and row["account_code"] == policy["sales_account"]:
            revenue[row["je_id"]] += row["credit"] - row["debit"]
    for row in lines:
        head = header.get(row["je_id"])
        if head is None or row["account_code"] != policy["receivable_account"]:
            continue
        item = dict(je_id=row["je_id"], date=_day(head["posting_date"]), customer=row.get("vendor_id", ""))
        if row["debit"] > 0 and revenue[row["je_id"]] > 0:
            sales[row["je_id"]] = dict(item, gross=row["debit"])
        elif row["credit"] > 0 and revenue[row["je_id"]] < 0:
            returns[row["je_id"]] = dict(item, gross=row["credit"])
    return sales, returns


def closing_return_findings(headers, lines, policy):
    """F1: 월말 직전 매출 → 다음 달 초 같은 거래처 대량 환입."""
    sales, returns = _customer_journals(headers, lines, policy)
    for sale in sorted(sales.values(), key=lambda item: (item["date"], item["je_id"])):
        end = date(sale["date"].year, sale["date"].month, monthrange(sale["date"].year, sale["date"].month)[1])
        if (end - sale["date"]).days >= policy["closing_days"]:
            continue
        if sale["gross"] < policy["minimum_gross"]:
            continue
        for ret in sorted(returns.values(), key=lambda item: (item["date"], item["je_id"])):
            if ret["customer"] != sale["customer"] or not sale["customer"]:
                continue
            if not end < ret["date"] <= end + timedelta(days=policy["return_days"]):
                continue
            if not policy["return_ratio"] * sale["gross"] <= ret["gross"] <= sale["gross"]:
                continue
            evidence = dict(customer=sale["customer"], sale_journal=sale["je_id"], sale_date=sale["date"].isoformat(),
                            sale_gross=sale["gross"], return_journal=ret["je_id"], return_date=ret["date"].isoformat(),
                            return_gross=ret["gross"], return_ratio=round(ret["gross"] / sale["gross"], 3),
                            month_end=end.isoformat())
            yield sale["je_id"], dict(evidence, role="매출")
            yield ret["je_id"], dict(evidence, role="환입")


def turnover_findings(headers, lines, policy):
    """F2: 월 매출채권 회전일수가 이전 달들의 중앙값보다 기준 이상 커진 달. 열린 매출 전표를 FIFO로 추정해 기여 전표를 찾는다."""
    header = {row["je_id"]: row for row in headers}
    receivable = policy["receivable_account"]
    events = []
    for row in lines:
        head = header.get(row["je_id"])
        if head is None or row["account_code"] != receivable:
            continue
        events.append((head["posting_date"], row["je_id"], row.get("vendor_id", ""), row["debit"], row["credit"],
                       head["je_type"] in policy["excluded_types"]))
    events.sort()
    months = sorted({item[0][:7] for item in events if not item[5]})
    balance = 0
    month_balance, issued = {}, defaultdict(int)
    queues = defaultdict(deque)
    snapshots = {}
    index = 0
    for month in months:
        while index < len(events) and events[index][0][:7] <= month:
            posting, je_id, customer, debit, credit, opening = events[index]
            balance += debit - credit
            if debit and not opening:
                if posting[:7] == month:
                    issued[month] += debit
                queues[customer].append([je_id, debit, posting])
            elif debit and opening:
                queues[customer].append([je_id, debit, posting])
            if credit:
                left = credit
                queue = queues[customer]
                while left > 0 and queue:
                    take = min(left, queue[0][1])
                    queue[0][1] -= take
                    left -= take
                    if queue[0][1] == 0:
                        queue.popleft()
            index += 1
        month_balance[month] = balance
        snapshots[month] = sorted(([item[0], item[1]] for queue in queues.values() for item in queue if item[1] > 0),
                                  key=lambda pair: (-pair[1], pair[0]))[:3]
    days = {month: monthrange(int(month[:4]), int(month[5:7]))[1] for month in months}
    turnover = {month: month_balance[month] / issued[month] * days[month]
                for month in months if issued[month] >= policy["minimum_issued"]}
    ordered = sorted(turnover)
    for position, month in enumerate(ordered):
        value = turnover[month]
        # 한 번 늘어난 채권은 이후 몇 달간 남아 있으므로, 나머지 모든 달이 아니라 그 이전 달들과 비교한다.
        others = [turnover[key] for key in ordered[:position]]
        if len(others) < policy["minimum_prior_months"]:
            continue
        center = median(others)
        spread = MAD_SCALE * median(abs(item - center) for item in others)
        limit = max(policy["mad_multiple"] * spread, policy["floor_days"])
        if value - center <= limit or not snapshots[month]:
            continue
        top = [dict(je_id=je_id, open_amount=amount) for je_id, amount in snapshots[month]]
        yield top[0]["je_id"], dict(
            month=month, turnover_days=round(value, 1), baseline_days=round(center, 1), limit_days=round(limit, 1),
            ending_balance=month_balance[month], issued=issued[month], top_open_journals=top)
