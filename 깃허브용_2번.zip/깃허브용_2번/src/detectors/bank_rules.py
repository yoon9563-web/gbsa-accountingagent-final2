"""H1 은행조정 불일치. 장부 현금(1010) 전표와 은행 거래내역을 증빙번호·금액으로 대사한다.

- 금액 차이: 같은 증빙번호의 장부 금액과 은행 금액이 다름 → 전표 단위 후보
- 장부에만 있음: 은행에 반영되지 않은 장부 거래 → 전표 단위 후보. 기말 직전 거래는 시차 항목으로 분리한다.
- 은행에만 있음: 장부에 없는 은행 거래 → 전표가 없으므로 요약 목록에 둔다.
읽기 전용 계산만 한다.
"""

from collections import defaultdict
from datetime import date, timedelta

STATEMENT_COLUMNS = ["bank_tx_id", "tx_date", "description", "reference", "counterparty_id", "amount"]
BALANCE_KEYS = ["period_start", "period_end", "opening_balance", "closing_balance"]


def _int(value, label):
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} 값이 정수가 아닙니다: {value!r}") from None


def bank_reconciliation(lines, headers, statement, balance, policy):
    for key in BALANCE_KEYS:
        if key not in balance:
            raise ValueError(f"은행 잔액 파일에 {key}가 없습니다.")
    period_end = date.fromisoformat(balance["period_end"])
    timing_from = period_end - timedelta(days=policy["timing_days"])
    skip_types = set(policy["opening_je_types"])
    header = {row["je_id"]: row for row in headers}

    net = defaultdict(int)
    for row in lines:
        if row["account_code"] == policy["cash_account"]:
            net[row["je_id"]] += row["debit"] - row["credit"]
    book_closing = sum(net.values())

    book = defaultdict(list)
    opening_book = 0
    for je_id, amount in sorted(net.items()):
        row = header.get(je_id)
        if row is None:
            raise ValueError(f"헤더에 없는 전표입니다: {je_id}")
        if row.get("je_type") in skip_types:
            opening_book += amount
            continue
        if amount != 0:
            book[row["document_id"]].append((je_id, amount, row["posting_date"]))

    bank = defaultdict(list)
    statement_sum = 0
    for row in statement:
        amount = _int(row["amount"], "amount")
        statement_sum += amount
        bank[row["reference"]].append((row["bank_tx_id"], amount, row["tx_date"]))

    findings, timing, bank_only = [], [], []
    for reference in sorted(set(book) | set(bank)):
        left, right = list(book.get(reference, [])), list(bank.get(reference, []))
        for item in list(left):
            match = next((other for other in right if other[1] == item[1]), None)
            if match:
                left.remove(item)
                right.remove(match)
        while left and right:
            je_id, amount, day = left.pop(0)
            bank_id, bank_amount, bank_day = right.pop(0)
            findings.append((je_id, dict(
                reason="금액 차이", reference=reference, posting_date=day, book_amount=amount,
                bank_amount=bank_amount, difference=amount - bank_amount, bank_tx_id=bank_id,
                bank_date=bank_day)))
        for je_id, amount, day in left:
            if date.fromisoformat(day) >= timing_from:
                timing.append(dict(je_id=je_id, reference=reference, posting_date=day, amount=amount))
            else:
                findings.append((je_id, dict(
                    reason="은행 거래 없음", reference=reference, posting_date=day, book_amount=amount,
                    bank_amount=0, difference=amount)))
        for bank_id, amount, day in right:
            bank_only.append(dict(bank_tx_id=bank_id, reference=reference, tx_date=day, amount=amount))

    opening_bank = _int(balance["opening_balance"], "opening_balance")
    closing_bank = _int(balance["closing_balance"], "closing_balance")
    summary = dict(
        statement_count=len(statement), book_closing=book_closing, bank_closing=closing_bank,
        difference=book_closing - closing_bank, opening_book=opening_book, opening_bank=opening_bank,
        bank_internal_difference=closing_bank - (opening_bank + statement_sum),
        timing_items=timing, bank_only=bank_only,
        timing_total=sum(item["amount"] for item in timing),
        bank_only_total=sum(item["amount"] for item in bank_only),
        finding_difference_total=sum(evidence["difference"] for _, evidence in findings))
    summary["unexplained_difference"] = (
        summary["difference"] - summary["timing_total"] - summary["finding_difference_total"]
        + summary["bank_only_total"] - (opening_book - opening_bank))
    return sorted(findings, key=lambda item: item[0]), summary
