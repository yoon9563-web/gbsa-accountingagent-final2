"""E1 신규 거래처 거액 거래, E2 거래처 마스터 이상(계좌 중복·임직원 계좌 일치).

계좌번호는 증거에 마스크(끝 4자리)만 남긴다. 읽기 전용 계산만 한다.
"""

from collections import defaultdict
from datetime import date

VENDOR_COLUMNS = ["vendor_id", "registered_date", "bank_account"]
EMPLOYEE_COLUMNS = ["employee_id", "bank_account"]


def mask(value):
    value = (value or "").strip()
    return "***" + value[-4:] if value else ""


def _day(value, label):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} 날짜 형식이 올바르지 않습니다: {value!r}") from None


def _payable_journals(lines, headers, account):
    """거래처별 매입채무 계정 전표 {vendor: [(je_id, posting_date, credit_amount)]}."""
    posting = {row["je_id"]: row.get("posting_date", "") for row in headers}
    per = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    for row in lines:
        if row["account_code"] == account and row.get("vendor_id"):
            item = per[row["vendor_id"]][row["je_id"]]
            item[0] += row["credit"]
            item[1] += row["debit"]
    out = defaultdict(list)
    for vendor, journals in per.items():
        for je_id, (credit, debit) in journals.items():
            out[vendor].append((je_id, posting.get(je_id, ""), credit, debit))
    return out


def new_vendor_findings(lines, headers, vendors, policy):
    window, threshold = policy["new_vendor_window_days"], policy["new_vendor_amount_threshold"]
    registered = {row["vendor_id"]: _day(row["registered_date"], row["vendor_id"]) for row in vendors}
    for vendor, journals in sorted(_payable_journals(lines, headers, policy["payable_account"]).items()):
        if vendor not in registered:
            continue
        invoices = sorted((posting, je_id, credit) for je_id, posting, credit, _ in journals if credit > 0)
        if not invoices:
            continue
        posting, je_id, amount = invoices[0]
        first = _day(posting, je_id)
        gap = (first - registered[vendor]).days
        reasons = []
        if gap < 0:
            reasons.append("등록일 이전 거래")
        elif gap <= window and amount >= threshold:
            reasons.append("등록 직후 거액 첫 거래")
        if reasons:
            yield je_id, dict(vendor_id=vendor, reasons=reasons, registered_date=registered[vendor].isoformat(),
                              first_transaction_date=posting, days_after_registration=gap,
                              amount=amount, window_days=window, amount_threshold=threshold)


def master_account_findings(lines, headers, vendors, employees, policy):
    by_account = defaultdict(set)
    for row in vendors:
        if row["bank_account"].strip():
            by_account[row["bank_account"].strip()].add(row["vendor_id"])
    employee_accounts = defaultdict(set)
    for row in employees:
        if row["bank_account"].strip():
            employee_accounts[row["bank_account"].strip()].add(row["employee_id"])
    flagged = {}
    for account, members in by_account.items():
        if len(members) > 1:
            for vendor in members:
                flagged.setdefault(vendor, []).append(dict(
                    reason="거래처 간 계좌 중복", account=mask(account), other_vendors=sorted(members - {vendor})))
        if account in employee_accounts:
            for vendor in members:
                flagged.setdefault(vendor, []).append(dict(
                    reason="임직원 계좌와 일치", account=mask(account),
                    employee_count=len(employee_accounts[account])))
    journals = _payable_journals(lines, headers, policy["payable_account"])
    for vendor in sorted(flagged):
        for je_id, posting, credit, debit in sorted(journals.get(vendor, []), key=lambda item: item[0]):
            yield je_id, dict(vendor_id=vendor, matches=flagged[vendor], posting_date=posting,
                              credit_amount=credit, debit_amount=debit)
