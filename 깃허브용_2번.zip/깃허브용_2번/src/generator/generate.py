"""Generate a reproducible synthetic ledger folder plus a separate answer-key folder.

python -B src/generator/generate.py --name 2026Q2-s1 --seed 1 --start 2026-04-01 --end 2026-06-30
Outputs data/synthetic/<name>/ (analysis input) and evaluator-only/labels/<name>/ (evaluation only).
Existing folders are never overwritten.
"""

import argparse
from collections import Counter
from datetime import date
import json
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inject
import normal
import pattern
import bank
import counterparty
import subledger
import tax
from common import (AUX_FILES, GENERATOR_VERSION, Book, Plan, Rng, sha256_file, write_csv)

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_POLICY = {"closing_days_before": 2, "closing_days_after": 2, "closing_rate_multiple": 3}
HEADER_COLUMNS = ["je_id", "company_code", "posting_date", "entered_at", "entered_by",
                  "approved_by", "approved_at", "source", "je_type", "description",
                  "document_id", "sequence_no"]
LINE_COLUMNS = ["je_id", "line_no", "account_code", "debit", "credit", "vendor_id",
                "department", "description", "currency"]
A2_COLUMNS = ["evidence_id", "kind", "company_code", "je_id", "source", "je_type", "from_date",
              "to_date", "start_time", "end_time", "weekdays"]


def assign_sequence(book):
    for seq, je in enumerate(sorted(book.journals, key=lambda j: (j.entered_at, j.order)), start=1):
        je.seq, je.id = seq, f"JE-{seq:05d}"


def build(args, prof, policy):
    start, end = date.fromisoformat(args.start), date.fromisoformat(args.end)
    if end <= start or (end - start).days < 60:
        raise ValueError("기간은 최소 60일 이상이어야 합니다.")
    ctx = normal.Ctx(Rng(args.seed), prof, policy, start, end, args.volume_scale)
    book, plan = Book(), Plan()
    normal.build_normal(ctx, book, plan)

    counts, scale = prof["anomalies"], args.anomaly_scale
    n = lambda key, minimum=0: inject.scaled(counts[key], scale, minimum)
    inject.inject_d1(ctx, book, plan, n("D1"))
    inject.inject_d4(ctx, book, plan, n("D4"))
    inject.inject_a6(ctx, book, plan, n("A6"))
    inject.inject_b3(ctx, book, plan, n("B3_payroll"), n("B3_price"))
    inject.inject_a2(ctx, book, plan, n("A2"))
    inject.inject_b2(ctx, book, plan, n("B2"))
    inject.inject_b6(ctx, book, plan, n("B6_groups"))
    inject.inject_b1(ctx, book, plan, n("B1_cluster", 8))
    b4_size = 0
    if scale > 0:
        b4_size = max(n("B4_cluster", 45), math.ceil(counts["B4_cluster_share"] * len(book.journals) * scale))
    inject.inject_b4(ctx, book, plan, b4_size)
    inject.inject_c1(ctx, book, plan, n("C1"))
    inject.inject_c7(ctx, book, plan, n("C7", 2))
    inject.inject_d5(ctx, book, plan, n("D5", 2))
    inject.inject_a1(ctx, book, plan, n("A1_burst", 5))
    d4_counts = {key: inject.scaled(value, scale) for key, value in counts["D4_subledger"].items()}
    sub_rng = subledger.sub_rng(args.seed)
    subledger.inject_gl_without_subledger(ctx, book, plan, d4_counts["gl_without_subledger"], sub_rng)

    months = pattern.months_covered(start, end)
    pat_rng = pattern.pattern_rng(args.seed)
    if months >= 12:
        pattern.inject_c2(ctx, book, plan, inject.scaled(counts["C2_rare_account"], scale), pat_rng)
    recv_flags = {key: counts.get(f"{key}_receivable", 0) > 0 and scale > 0 for key in ("F1", "F2")}
    pattern.inject_receivable(ctx, book, plan, pat_rng, months, recv_flags)
    trend_flags = {key: counts[f"{key}_trend"] > 0 for key in ("I1", "I2", "I3")} if "I1_trend" in counts else {}
    pattern.inject_trend(ctx, book, plan, pat_rng, months, {k: v and scale > 0 for k, v in trend_flags.items()})

    assign_sequence(book)
    if n("A4"):
        inject.apply_backdating(ctx, book, plan, n("A4"))
    inject.apply_gaps(ctx, book, plan, n("D2"), prof["legit_exceptions"]["D2_reserved_number"])
    ext_rng = counterparty.ext_rng(args.seed)
    counterparty.build_master(ctx, book, ext_rng)
    e_counts = {key: inject.scaled(value, scale) for key, value in counts["E_counterparty"].items()}
    counterparty.inject(ctx, book, plan, e_counts, prof["legit_exceptions"], ext_rng)
    book.subledger = subledger.derive_entries(book, plan)
    subledger.perturb(ctx, book, plan, book.subledger, d4_counts,
                      prof["legit_exceptions"]["D4_split_receipt"], sub_rng)
    h_counts = {key: inject.scaled(value, scale) for key, value in counts["H_bank"].items()}
    bank_rng = bank.bank_rng(args.seed)
    book.bank_statement = bank.derive_statement(book)
    bank.perturb(ctx, book, plan, book.bank_statement, h_counts,
                 prof["legit_exceptions"]["H1_year_end_timing"], bank_rng)
    pattern.inject_a7(ctx, book, plan, inject.scaled(counts["A7_manual_normal_entry"], scale), pat_rng)
    pattern.inject_d3(book, plan, inject.scaled(counts["D3_description"], scale, 1) * 3 if counts["D3_description"] else 0)
    if months >= 12:
        pattern.label_capex_exception(book, plan)
    auto_accounts = set(json.loads((ROOT / "config/pattern-review.json").read_text(
        encoding="utf-8-sig"))["manual_entry"]["auto_linked_accounts"])
    pattern.label_manual_overlaps(book, plan, auto_accounts)
    pattern.label_break_overlaps(book, plan, json.loads((ROOT / "config/trend-review.json").read_text(
        encoding="utf-8-sig"))["I1"], months)
    pattern.label_repeat_overlaps(book, plan, json.loads((ROOT / "config/pattern-review.json").read_text(
        encoding="utf-8-sig"))["repeated_amount"])
    book.bank_opening = bank.opening_balance(book)
    t_counts = {key: inject.scaled(value, scale) for key, value in counts["I4_F3_tax"].items()}
    book.tax_invoices = tax.derive_invoices(book)
    tax.perturb(ctx, book, plan, book.tax_invoices, t_counts,
                prof["legit_exceptions"]["I4_issue_date_lag"], tax.tax_rng(args.seed))
    validate(book, plan)
    return ctx, book, plan, start, end


def validate(book, plan):
    journals = set(book.journals)
    ids = [je.id for je in book.journals]
    if len(ids) != len(set(ids)) or any(not je.lines for je in book.journals):
        raise ValueError("전표 ID 중복 또는 라인 없는 전표가 있습니다.")
    unbalanced = {je for je in book.journals if je.debit_total() != je.credit_total()}
    expected = {item["journal"] for item in plan.anomalies
                if item["type_id"] == "D4" and not item["method"].startswith("subledger_")}
    if unbalanced != expected:
        raise ValueError("차대 불일치 전표가 D4 주입 계획과 다릅니다.")
    if any(row["_je"] not in journals for row in book.tax_invoices):
        raise ValueError("세금계산서가 삭제된 전표를 참조합니다.")
    if any(row["_je"] not in journals for row in book.bank_statement):
        raise ValueError("은행 거래가 삭제된 전표를 참조합니다.")
    if any(row["_je"] not in journals for row in book.subledger):
        raise ValueError("보조원장이 삭제된 전표를 참조합니다.")
    for name in AUX_FILES:
        if any(row["_je"] not in journals for row in book.aux[name]):
            raise ValueError(f"{name}에 삭제된 전표를 참조하는 행이 있습니다.")
    for item in plan.anomalies + plan.exceptions:
        if item["journal"] not in journals:
            raise ValueError("정답표가 삭제된 전표를 가리킵니다.")


def rows_for(book, name, builder):
    ordered = sorted(book.aux[name], key=lambda row: row["_je"].seq)
    return [builder(row, row["_je"]) for row in ordered]


def write_outputs(args, prof, ctx, book, plan, start, end, profile_hash):
    data_dir = Path(args.out_root) / "synthetic" / args.name
    label_dir = ROOT / "evaluator-only" / "labels" / args.name if args.label_root is None else args.label_root / args.name
    for path in (data_dir, label_dir):
        if path.exists():
            raise ValueError(f"이미 존재하는 폴더입니다. 덮어쓰지 않습니다: {path}")
    data_dir.mkdir(parents=True)
    label_dir.mkdir(parents=True)
    journals = sorted(book.journals, key=lambda je: je.seq)

    write_csv(data_dir / "je_header.csv", HEADER_COLUMNS, [
        [je.id, prof["company_code"], je.posting_date.isoformat(), je.entered_at.isoformat(),
         je.entered_by, je.approved_by,
         je.approved_at.isoformat() if je.approved_at else "", je.source, je.je_type,
         je.description, je.document_id, je.seq] for je in journals])
    lines = [[je.id, number, item["account"], item["debit"], item["credit"], item["vendor"],
              item["department"], item["description"], prof["currency"]]
             for je in journals for number, item in enumerate(je.lines, start=1)]
    write_csv(data_dir / "je_line.csv", LINE_COLUMNS, lines)

    control = dict(company_code=prof["company_code"], period_start=start.isoformat(),
                   period_end=end.isoformat(), currency=prof["currency"],
                   journal_count=len(journals), line_count=len(lines),
                   debit_total=sum(je.debit_total() for je in journals),
                   credit_total=sum(je.credit_total() for je in journals))
    (data_dir / "source_control_totals.json").write_text(
        json.dumps(control, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    write_csv(data_dir / "supplier_invoices.csv",
              ["invoice_id", "je_id", "vendor_id", "invoice_date", "invoice_amount", "product_id",
               "quantity", "unit_price", "delivery_ref"],
              rows_for(book, "supplier_invoices", lambda r, je: [
                  r["invoice_id"], je.id, r["vendor_id"], r["invoice_date"].isoformat(),
                  r["invoice_amount"], r["product_id"], r["quantity"], r["unit_price"],
                  r["delivery_ref"]]))
    write_csv(data_dir / "expense_claims.csv",
              ["je_id", "claim_id", "employee_id", "receipt_id", "expense_date", "amount"],
              rows_for(book, "expense_claims", lambda r, je: [
                  je.id, f"CL-{je.id}", r["employee_id"], r["receipt_id"],
                  r["expense_date"].isoformat(), r["amount"]]))
    write_csv(data_dir / "payroll.csv",
              ["je_id", "employee_id", "pay_month", "hours", "base_salary", "approved_bonus",
               "gross_paid"],
              rows_for(book, "payroll", lambda r, je: [
                  je.id, r["employee_id"], r["pay_month"], r["hours"], r["base_salary"],
                  r["approved_bonus"], r["gross_paid"]]))
    write_csv(data_dir / "card_transactions.csv",
              ["je_id", "transaction_id", "card_id", "transaction_date", "vendor_id",
               "merchant_category", "order_ref", "amount"],
              rows_for(book, "card_transactions", lambda r, je: [
                  je.id, r["transaction_id"], r["card_id"], r["transaction_date"].isoformat(),
                  r["vendor_id"], r["merchant_category"], r["order_ref"], r["amount"]]))
    write_csv(data_dir / "bank_tx.csv",
              ["bank_id", "je_id", "invoice_id", "transaction_date", "vendor_id", "direction",
               "amount"],
              rows_for(book, "bank_tx", lambda r, je: [
                  f"BANK-{je.id}", je.id, r["invoice_id"], r["transaction_date"].isoformat(),
                  r["vendor_id"], r["direction"], r["amount"]]))
    write_csv(data_dir / "subledger_entries.csv",
              ["entry_id", "ledger", "counterparty_id", "doc_type", "doc_ref", "doc_date",
               "je_id", "amount"],
              [[f"SUB-{r['ledger']}-{number:05d}", r["ledger"], r["counterparty"], r["doc_type"],
                r["doc_ref"], r["doc_date"].isoformat(), r["_je"].id, r["amount"]]
               for number, r in enumerate(book.subledger, start=1)])
    write_csv(data_dir / "tax_invoices.csv",
              ["tax_invoice_id", "direction", "issue_date", "counterparty_id", "doc_ref", "je_id",
               "supply_amount", "vat_amount"],
              [[f"TI-{number:05d}", r["direction"], r["issue_date"].isoformat(), r["counterparty"],
                r["doc_ref"], r["_je"].id, r["supply"], r["vat"]]
               for number, r in enumerate(book.tax_invoices, start=1)])
    write_csv(data_dir / "bank_statement.csv",
              ["bank_tx_id", "tx_date", "description", "reference", "counterparty_id", "amount"],
              [[f"BS-{number:05d}", r["date"].isoformat(), r["description"], r["reference"],
                r["counterparty"], r["amount"]]
               for number, r in enumerate(book.bank_statement, start=1)])
    balance = dict(account_label="가상은행 보통예금", period_start=start.isoformat(),
                   period_end=end.isoformat(), opening_balance=book.bank_opening,
                   closing_balance=book.bank_opening + sum(r["amount"] for r in book.bank_statement))
    (data_dir / "bank_balance.json").write_text(
        json.dumps(balance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    policy = prof["card_policy"]
    write_csv(data_dir / "card_limits.csv",
              ["card_id", "employee_id", "per_transaction_limit", "monthly_limit", "allowed_category"],
              [[card, emp, policy["per_transaction_limit"], policy["monthly_limit"], "5311|5943"]
               for card, emp in ctx.cards])
    write_csv(data_dir / "vendor_master.csv",
              ["vendor_id", "name", "business_type", "registered_date", "bank_account"],
              [[v, m["name"], m["kind"], m["registered"].isoformat(), m["account"]]
               for v, m in sorted(book.vendor_master.items(),
                                  key=lambda item: (item[0][0], int(item[0][1:])))])
    write_csv(data_dir / "employee_master.csv", ["employee_id", "bank_account"],
              [[emp, m["account"]] for emp, m in book.employee_master.items()])
    write_csv(data_dir / "a2_exceptions.csv", A2_COLUMNS, [
        [r["evidence_id"], r["kind"], prof["company_code"], r["_je"].id if r["_je"] else "",
         r["source"], r["je_type"], r["from_date"], r["to_date"], r["start_time"],
         r["end_time"], r["weekdays"]] for r in book.a2_rules])

    month_rows = Counter(je.posting_date.strftime("%Y-%m") for je in journals)
    (data_dir / "README.md").write_text(render_readme(args, prof, control, month_rows),
                                        encoding="utf-8")
    files = {path.name: {"sha256": sha256_file(path)}
             for path in sorted(data_dir.iterdir()) if path.name != "manifest.json"}
    manifest = dict(generator_version=GENERATOR_VERSION, name=args.name, seed=args.seed,
                    period_start=start.isoformat(), period_end=end.isoformat(),
                    volume_scale=args.volume_scale, profile_sha256=profile_hash, files=files)
    (data_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    anomaly_rows = sorted(
        [[a["journal"].id, a["line_no"], a["type_id"], a["method"], a["severity"], a["concealment"]]
         for a in plan.anomalies], key=lambda row: (row[0], row[2]))
    write_csv(label_dir / "anomaly_labels.csv",
              ["je_id", "line_no", "type_id", "injection_method", "severity", "concealment"],
              anomaly_rows)
    write_csv(label_dir / "normal_exceptions.csv", ["je_id", "type_id", "reason"],
              sorted([[e["journal"].id, e["type_id"], e["reason"]] for e in plan.exceptions]))
    per_type = Counter(a["type_id"] for a in plan.anomalies)
    cluster_types = {"A1", "B4"}
    cluster_journals = {a["journal"] for a in plan.anomalies if a["type_id"] in cluster_types}
    individual = {a["journal"] for a in plan.anomalies} - cluster_journals
    label_manifest = dict(
        name=args.name, anomaly_scale=args.anomaly_scale,
        labeled_by_type=dict(sorted(per_type.items())),
        exceptions_by_type=dict(sorted(Counter(e["type_id"] for e in plan.exceptions).items())),
        journal_count=len(journals), individually_injected_journals=len(individual),
        individual_injection_rate=round(len(individual) / len(journals), 4),
        population_cluster_journals=len(cluster_journals),
        note="A1·B4는 모집단 단위 검사이며 군집 전표를 정답표에 기록한다. A4 주입은 전기일 역전 부수효과로 D2에도 기록한다.")
    (label_dir / "manifest.json").write_text(
        json.dumps(label_manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (label_dir / "README.md").write_text(
        f"# {args.name} 정답표\n\n평가 단계(`evaluation/`)에서만 사용한다. 탐지·에이전트 단계에서는 열지 않는다.\n",
        encoding="utf-8")
    return data_dir, label_dir, control


def render_readme(args, prof, control, month_rows):
    rows = "\n".join(f"| {month} | {count} |" for month, count in sorted(month_rows.items()))
    return (
        f"# {args.name} 가상 유통회사 원장\n\n"
        f"가상의 상품 유통회사 {prof['company_code']}의 {control['period_start']} ~ "
        f"{control['period_end']} 원장이다. 원화 정수, 한국시간, 시드 {args.seed}로 "
        f"`src/generator/generate.py`가 생성했다. 부가세와 급여 공제는 훈련용 가정이다.\n\n"
        f"| 전기월 | 전표 수 |\n|---|---:|\n{rows}\n\n"
        f"전표 {control['journal_count']:,}건, 라인 {control['line_count']:,}개, "
        f"차변 {control['debit_total']:,}원, 대변 {control['credit_total']:,}원이다.\n\n"
        f"## 사용 방법\n\n"
        f"- 검사: `python -B src/agent/audit.py --input \"data/synthetic/{args.name}\"`\n"
        f"- `source_control_totals.json`은 CSV 내보내기 전 합성 원천 레코드의 집계다.\n"
        f"- 이 폴더에는 정답이 없다. 평가용 정답표는 `evaluator-only/labels/{args.name}/`에 따로 있고 "
        f"평가 단계에서만 연다.\n"
        f"- `manifest.json`에 생성기 버전, 시드, 파일별 SHA-256을 기록했다.\n")


def parse_args():
    parser = argparse.ArgumentParser(description="재현 가능한 가상 회계 원장과 정답표 생성")
    parser.add_argument("--name", help="출력 폴더 이름 (기본: <연도>Q<분기>-s<시드>)")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--start", default="2026-04-01")
    parser.add_argument("--end", default="2026-09-30")
    parser.add_argument("--profile", type=Path, default=ROOT / "config/generator-profile.json")
    parser.add_argument("--volume-scale", type=float, default=1.0, help="정상 거래량 배율")
    parser.add_argument("--anomaly-scale", type=float, default=1.0, help="이상 주입 배율")
    parser.add_argument("--clean", action="store_true", help="이상 주입 없이 정상·예외만 생성")
    parser.add_argument("--out-root", type=Path, default=ROOT / "data")
    parser.add_argument("--label-root", type=Path, default=None)
    args = parser.parse_args()
    if args.clean:
        args.anomaly_scale = 0.0
    if not args.name:
        first, last = date.fromisoformat(args.start), date.fromisoformat(args.end)
        args.name = f"{first:%Y%m}-{last:%Y%m}-s{args.seed}"
    return args


def main():
    args = parse_args()
    try:
        prof = json.loads(args.profile.read_text(encoding="utf-8"))
        policy_path = ROOT / "config/ledger-review.json"
        policy = json.loads(policy_path.read_text(encoding="utf-8-sig")) if policy_path.exists() else DEFAULT_POLICY
        ctx, book, plan, start, end = build(args, prof, policy)
        data_dir, label_dir, control = write_outputs(
            args, prof, ctx, book, plan, start, end, sha256_file(args.profile))
    except (OSError, ValueError, KeyError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False))
        return 1
    print(json.dumps({"status": "completed", "name": args.name, "seed": args.seed,
                      "input_dir": str(data_dir), "labels_dir": str(label_dir),
                      "journal_count": control["journal_count"],
                      "line_count": control["line_count"],
                      "debit_total": control["debit_total"],
                      "credit_total": control["credit_total"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
