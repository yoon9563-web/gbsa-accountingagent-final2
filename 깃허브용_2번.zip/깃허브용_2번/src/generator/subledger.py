"""Subledger (AR/AP) derivation and D4 subledger-mismatch injection.

The subledger is derived from the final GL lines on the control accounts, then perturbed on
purpose. It therefore tests whether the detector finds differences; it is not an independent
simulation of a subledger system. Uses its own Rng so earlier random streams are unchanged.
"""

from datetime import timedelta

from common import Rng, line, stamp
import normal

CONTROL = {"1100": ("AR", "debit"), "2010": ("AP", "credit")}
DOC_TYPES = {"외상매출": "청구", "상품매입": "청구", "설비": "청구", "매출입금": "수금",
             "매입지급": "지급", "매출환입": "환입"}


def sub_rng(seed):
    return Rng(seed + 7919)


def inject_gl_without_subledger(ctx, book, plan, count, rng):
    """수기 매출채권 직접 기표: 정상 외상매출과 같은 계정 조합이지만 보조원장 청구 문서가 없다."""
    prof = ctx.prof
    for _ in range(count):
        sku = rng.choice(list(prof["products"]))
        product = prof["products"][sku]
        gross = int(rng.loguniform(*prof["amounts"]["sale_debit_total"]))
        if gross % 1000 == 0:
            gross += 173
        net = gross * 10 // 11
        vat = gross - net
        cost = round(net / product["markup"] / 1000) * 1000 + 417
        customer = rng.choice(ctx.customers)
        day = ctx.days[int(len(ctx.days) * rng.uniform(0.2, 0.75))]
        minutes = rng.randint(9 * 60 + 10, 16 * 60 + 40)
        lines = [line("1100", gross, vendor=customer, description="매출채권 수기 기표"),
                 line("5100", cost, description="매출채권 수기 기표"),
                 line("1300", credit=cost, description="매출채권 수기 기표"),
                 line("2100", credit=vat, description="매출채권 수기 기표"),
                 line("4100", credit=net, description="매출채권 수기 기표")]
        entered = stamp(day, minutes // 60, minutes % 60)
        je = normal.post(ctx, book, "외상매출", day, lines, "매출채권 수기 기표",
                         f"MAN-SAL-{len(book.journals)}", source="수기", entered_at=entered,
                         entered_by="U03", approved_by="U02", approved_at=stamp(day, 17, 20))
        plan.anomaly(je, "D4", "subledger_gl_without_document", "높음", "보통")


def derive_entries(book, plan):
    """최종 원장 전표의 통제계정 라인에서 보조원장 행을 만든다. (전표 번호 순)"""
    skip = {item["journal"] for item in plan.anomalies
            if item["method"] == "subledger_gl_without_document"}
    rows = []
    for je in sorted(book.journals, key=lambda j: j.seq):
        if je in skip:
            continue
        for item in je.lines:
            kind = CONTROL.get(item["account"])
            if not kind:
                continue
            ledger, side = kind
            amount = item["debit"] - item["credit"]
            if side == "credit":
                amount = -amount
            rows.append(dict(_je=je, ledger=ledger, counterparty=item["vendor"],
                             doc_type=DOC_TYPES.get(je.je_type, "조정"), doc_ref=je.document_id,
                             doc_date=je.posting_date, amount=amount))
    return rows


def transpose(amount):
    sign = -1 if amount < 0 else 1
    digits = list(str(abs(amount)))
    for index in range(len(digits) - 3, 0, -1):
        if digits[index] != digits[index + 1]:
            digits[index], digits[index + 1] = digits[index + 1], digits[index]
            break
    else:
        raise ValueError("자릿수 전치가 가능한 금액이 아닙니다.")
    return sign * int("".join(digits))


def pool(book, plan, je_type, rows):
    have = {id(row["_je"]) for row in rows}
    return [je for je in sorted(book.journals, key=lambda j: j.seq)
            if je.je_type == je_type and je not in plan.used and id(je) in have]


def perturb(ctx, book, plan, rows, counts, legit_split, rng):
    by_je = {}
    for row in rows:
        by_je.setdefault(id(row["_je"]), []).append(row)

    def take(je_type, count):
        candidates = pool(book, plan, je_type, rows)
        if len(candidates) < count:
            raise ValueError(f"{je_type} 전표가 부족해 보조원장 주입 {count}건을 만들 수 없습니다.")
        chosen = rng.sample(candidates, count)
        plan.used.update(chosen)
        return chosen

    for index, je in enumerate(take("매출입금", counts["amount_mismatch"] - counts["amount_mismatch"] // 2)
                               + take("상품매입", counts["amount_mismatch"] // 2)):
        entry = by_je[id(je)][0]
        entry["amount"] = transpose(entry["amount"])
        plan.anomaly(je, "D4", "subledger_amount_transposed", "중간", "어려움")
    for je in take("매입지급", counts["missing_in_subledger"]):
        rows.remove(by_je[id(je)][0])
        plan.anomaly(je, "D4", "subledger_entry_missing", "높음", "보통")
    for je in take("매출입금", counts["wrong_counterparty"]):
        entry = by_je[id(je)][0]
        entry["counterparty"] = rng.choice([c for c in ctx.customers if c != entry["counterparty"]])
        plan.anomaly(je, "D4", "subledger_wrong_counterparty", "높음", "어려움")
    for je in take("매출입금", legit_split):
        entry = by_je[id(je)][0]
        first = entry["amount"] // 2 + rng.randint(1, 9)
        rest = dict(entry, amount=entry["amount"] - first)
        entry["amount"] = first
        rows.insert(rows.index(entry) + 1, rest)
        plan.exception(je, "D4", "수금 1건을 보조원장에 2개 문서로 나눠 기록 (합계 일치)")
