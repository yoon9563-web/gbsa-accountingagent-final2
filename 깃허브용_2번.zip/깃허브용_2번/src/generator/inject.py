"""Anomaly injection. Every function records its answer-key rows in the Plan."""

from datetime import timedelta

from common import is_business, line, next_business, pick, stamp
import normal
from normal import ADMIN


def scaled(count, scale, minimum=0):
    if scale <= 0 or count <= 0:
        return 0
    return max(minimum, round(count * scale))


def inject_d4(ctx, book, plan, count):
    rng = ctx.rng
    pool = pick(book, rng, plan, "카드", count - count // 2) + pick(book, rng, plan, "경비", count // 2)
    for je in pool:
        delta = rng.randint(3, 30) * 1000
        je.lines[1]["credit"] -= delta
        plan.anomaly(je, "D4", "credit_line_amount_altered", "중간", "쉬움", line_no=2)


def inject_d1(ctx, book, plan, count):
    rng = ctx.rng
    for number in range(count):
        if number % 2 == 0:
            original = pick(book, rng, plan, "상품매입", 1, after=ctx.days[10],
                            before=ctx.days[int(len(ctx.days) * 0.7)])[0]
            row = next(item for item in book.aux["supplier_invoices"] if item["_je"] is original)
            posting = next_business(original.posting_date + timedelta(days=rng.randint(2, 6)))
            dup = normal.purchase(ctx, book, posting, sku=row["product_id"], vendor=row["vendor_id"],
                                  qty=row["quantity"], unit=row["unit_price"],
                                  invoice_id=row["invoice_id"], invoice_date=row["invoice_date"],
                                  payable=False)
            plan.anomaly(dup, "D1", "duplicate_supplier_invoice", "높음", "보통")
        else:
            original = pick(book, rng, plan, "경비", 1, after=ctx.days[10],
                            before=ctx.days[int(len(ctx.days) * 0.7)])[0]
            row = next(item for item in book.aux["expense_claims"] if item["_je"] is original)
            posting = next_business(original.posting_date + timedelta(days=rng.randint(1, 4)))
            dup = normal.expense(ctx, book, posting, amount=row["amount"],
                                 employee=row["employee_id"], receipt_id=row["receipt_id"],
                                 expense_date=row["expense_date"])
            plan.anomaly(dup, "D1", "duplicate_expense_receipt", "중간", "보통")


def inject_a2(ctx, book, plan, count):
    rng = ctx.rng
    kinds = ["night", "saturday", "sunday"]
    for number in range(count):
        kind = kinds[number % 3]
        day = ctx.pick_day(0.15, 0.8)
        if kind == "night":
            when, method, hidden = stamp(day, 23, 49), "late_night_entry", "쉬움"
        else:
            weekend = day + timedelta(days=(5 if kind == "saturday" else 6) - day.weekday())
            hour = 2 if kind == "saturday" else 14
            when, method, hidden = stamp(weekend, hour, rng.randint(5, 55)), "weekend_entry", "보통"
            day = weekend - timedelta(days=weekend.weekday() - 4)
        je = normal.expense(ctx, book, day, entered_at=when)
        plan.anomaly(je, "A2", method, "중간", hidden)


def inject_a6(ctx, book, plan, count):
    rng = ctx.rng
    for number, je in enumerate(pick(book, rng, plan, "카드", count)):
        if number % 2 == 0:
            je.approved_by = je.entered_by
            plan.anomaly(je, "A6", "self_approval", "높음", "쉬움")
        else:
            je.approved_by, je.approved_at = "", ""
            plan.anomaly(je, "A6", "approver_missing", "중간", "쉬움")


def inject_b2(ctx, book, plan, count):
    rng = ctx.rng
    limit = ctx.prof["card_policy"]["per_transaction_limit"]
    for _ in range(count):
        amount = rng.randint(limit - 10000, limit - 100)
        if amount % 1000 == 0:
            amount -= 7
        je = normal.card(ctx, book, ctx.pick_day(0.1, 0.8), amount=amount)
        plan.anomaly(je, "B2", "just_below_card_limit", "중간", "어려움" if limit - amount < 3000 else "보통")


def inject_b6(ctx, book, plan, groups):
    rng = ctx.rng
    for _ in range(groups):
        day, pair, vendor = ctx.pick_day(0.1, 0.75), rng.choice(ctx.cards), rng.choice(ctx.suppliers)
        order = ctx.doc("PO", day)
        for part in range(2):
            when = next_business(day + timedelta(days=part))
            je = normal.card(ctx, book, when, amount=rng.randint(300000, 350000), card_pair=pair,
                             vendor=vendor, order_ref=order)
            plan.anomaly(je, "B6", "split_card_payment", "높음", "보통")


def inject_b3(ctx, book, plan, payroll_count, price_count):
    rng = ctx.rng
    for je in pick(book, rng, plan, "급여", payroll_count):
        delta = rng.randint(6, 34) * 100000 + rng.randint(1, 9) * 1000
        je.lines[0]["debit"] += delta
        je.lines[1]["credit"] += delta
        row = next(item for item in book.aux["payroll"] if item["_je"] is je)
        row["gross_paid"] += delta
        plan.anomaly(je, "B3", "payroll_overpayment", "높음", "보통")
    for _ in range(price_count):
        je = normal.purchase(ctx, book, ctx.pick_day(0.2, 0.8), sku="SKU1",
                             unit_factor=rng.uniform(1.55, 1.8))
        plan.anomaly(je, "B3", "unit_price_outlier", "중간", "쉬움")


def inject_b1(ctx, book, plan, count):
    """정액 군집. 앞의 3건은 같은 금액·같은 거래처로 30일 안에 반복해 B5에도 이중 라벨한다."""
    rng = ctx.rng
    repeat = min(3, count)
    if repeat >= 3:
        day = ctx.pick_day(0.1, 0.7)
        amount = rng.randint(3, 30) * 100000
        vendor = rng.choice(ctx.suppliers)
        when = day
        for _ in range(repeat):
            je = normal.misc_payment(ctx, book, when, amount=amount, vendor=vendor)
            plan.anomaly(je, "B1", "round_amount_cluster", "중간", "보통")
            plan.anomaly(je, "B5", "overlap_of_B1:same_amount_repeated", "중간", "보통")
            when = next_business(when + timedelta(days=3))
    for _ in range(count - repeat):
        day = ctx.pick_day(0.1, 0.85)
        amount = rng.randint(3, 30) * 100000
        je = normal.misc_payment(ctx, book, day, amount=amount)
        plan.anomaly(je, "B1", "round_amount_cluster", "중간", "보통")


def inject_b4(ctx, book, plan, count):
    rng = ctx.rng
    vendors = rng.sample(ctx.suppliers, 3)
    for _ in range(count):
        gross = rng.randint(4900000, 4990000)
        je = normal.purchase(ctx, book, ctx.pick_day(0.05, 0.9), gross=gross, unit_factor=1.0,
                             vendor=rng.choice(vendors), payable=False)
        plan.anomaly(je, "B4", "approval_threshold_clustering", "중간", "어려움")


def manual_entry(ctx, book, je_type, day, debit, credit, amount, description, doc):
    return normal.manual(ctx, book, je_type, day,
                         [line(debit, amount, department=ADMIN, description=description),
                          line(credit, credit=amount, department=ADMIN, description=description)],
                         description, doc, approved_by="U02")


def inject_c1(ctx, book, plan, count):
    rng = ctx.rng
    combos = [("1100", "2010", "매출채권·매입채무 상계"), ("1300", "2300", "재고·미지급비용 대체")]
    for number in range(count):
        debit, credit, text = combos[number % len(combos)]
        day = ctx.pick_day(0.2, 0.85)
        je = manual_entry(ctx, book, "수기수정", day, debit, credit,
                          rng.randint(300000, 2000000) + 17, text, ctx.doc("ADJ", day))
        plan.anomaly(je, "C1", "unusual_account_pair", "중간", "보통")


def inject_c7(ctx, book, plan, count):
    rng = ctx.rng
    for _ in range(count):
        day = ctx.pick_day(0.2, 0.85)
        je = manual_entry(ctx, book, "수기수정", day, "1010", "6200",
                          rng.randint(200000, 1500000) + 23, "경비 환입 처리", ctx.doc("ADJ", day))
        plan.anomaly(je, "C7", "expense_credit_to_cash", "중간", "보통", line_no=2)


def inject_d5(ctx, book, plan, count):
    rng = ctx.rng
    for number in range(1, count + 1):
        day = ctx.pick_day(0.15, 0.8)
        net = rng.randint(800000, 2500000) + 31
        vat, vendor = normal.vat_of(net), rng.choice(ctx.suppliers)
        document = f"ADJ-D5-{number}"
        forward = [line("1200", vat), line("1300", net), line("2010", credit=net + vat, vendor=vendor)]
        backward = [line("2010", net + vat, vendor=vendor), line("1200", credit=vat),
                    line("1300", credit=net)]
        journals = []
        when = day
        for step, lines in enumerate((forward, backward, forward)):
            copied = [dict(item) for item in lines]
            je = normal.manual(ctx, book, "수기수정", when, copied, "매입 정정 입력", document,
                               approved_by="U02")
            journals.append(je)
            plan.lock(je)
            when = next_business(when + timedelta(days=1))
        plan.anomaly(journals[-1], "D5", "reverse_and_reenter", "중간", "어려움")
        for je in journals:
            plan.anomaly(je, "B5", "overlap_of_D5:same_amount_repeated", "낮음", "보통")


def inject_a1(ctx, book, plan, count):
    policy, rng = ctx.policy, ctx.rng
    before, after, multiple = (policy["closing_days_before"], policy["closing_days_after"],
                               policy["closing_rate_multiple"])
    close = ctx.end
    window_start = close - timedelta(days=before)
    baseline_days = (window_start - ctx.start).days
    baseline = sum(je.debit_total() for je in book.journals
                   if je.je_type != "기초" and ctx.start <= je.posting_date < window_start)
    window = sum(je.debit_total() for je in book.journals
                 if je.je_type != "기초"
                 and window_start <= je.posting_date <= close + timedelta(days=after))
    needed = multiple * (baseline / baseline_days) * (before + 1) * 1.2
    remaining = max(0.0, needed - window)
    if remaining <= 0 or count <= 0:
        return
    days = [window_start + timedelta(days=offset) for offset in range(before + 1)]
    days = [day for day in days if is_business(day)]
    weights = [rng.uniform(0.7, 1.3) for _ in range(count)]
    for weight in weights:
        total = remaining * weight / sum(weights)
        je = normal.sale(ctx, book, rng.choice(days), total=total, collect=False)
        plan.anomaly(je, "A1", "quarter_end_sales_burst", "높음", "보통")


def apply_backdating(ctx, book, plan, count):
    rng = ctx.rng
    ordered = sorted(book.journals, key=lambda je: je.seq)
    candidates = [je for je in ordered if je.je_type == "경비" and je not in plan.used
                  and (je.entered_at.date() - ctx.start).days >= 35]
    for je in rng.sample(candidates, count):
        entered = je.entered_at.date()
        shift = rng.randint(20, min(60, (entered - ctx.start).days - 1))
        je.posting_date = entered - timedelta(days=shift)
        plan.anomaly(je, "A4", "backdated_posting", "중간", "보통")
        plan.anomaly(je, "D2", "posting_order_inversion_by_backdating", "낮음", "보통")


def apply_gaps(ctx, book, plan, anomalous, legit):
    rng = ctx.rng
    ordered = sorted(book.journals, key=lambda je: je.seq)
    by_seq = {je.seq: je for je in ordered}
    candidates = [je for je in ordered if je.je_type == "경비" and je not in plan.used
                  and 20 < je.seq < len(ordered) - 20]
    taken, chosen = set(), []
    for je in rng.shuffled(candidates):
        successor = by_seq.get(je.seq + 1)
        near = {je.seq - 1, je.seq, je.seq + 1}
        if successor is None or successor in plan.used or near & taken:
            continue
        taken.update({je.seq - 2, je.seq - 1, je.seq, je.seq + 1, je.seq + 2})
        chosen.append((je, successor))
        plan.lock(successor)
        if len(chosen) == anomalous + legit:
            break
    if len(chosen) < anomalous + legit:
        raise ValueError("결번을 만들 전표 후보가 부족합니다.")
    for number, (je, successor) in enumerate(chosen):
        book.remove(je)
        if number < anomalous:
            plan.anomaly(successor, "D2", "deleted_journal_sequence_gap", "중간", "보통")
        else:
            plan.exception(successor, "D2", "취소된 임시전표 번호 (예약 번호 결번)")
