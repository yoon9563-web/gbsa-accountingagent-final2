"""Normal-activity templates and legitimate exceptions for the synthetic ledger."""

from collections import defaultdict
from datetime import timedelta

from common import (business_days, default_approval, line, month_end, next_business,
                    office_stamp, stamp, vat_of)

OPS, ADMIN = "영업물류", "관리"


class Ctx:
    def __init__(self, rng, prof, policy, start, end, volume_scale):
        self.rng, self.prof, self.policy = rng, prof, policy
        self.start, self.end, self.volume_scale = start, end, volume_scale
        self.days = business_days(start, end)
        self.company = prof["company_code"]
        counts = prof["counterparties"]
        self.suppliers = [f"V{i}" for i in range(1, counts["suppliers"] + 1)]
        self.customers = [f"C{i}" for i in range(1, counts["customers"] + 1)]
        self.cards = [(f"CARD{i}", f"EMP{i}") for i in range(1, counts["cards"] + 1)]
        self.employees = [f"EMP{i}" for i in range(1, prof["fixed"]["employees"] + 1)]
        low, high = prof["fixed"]["salary_range"]
        self.salaries = {emp: rng.randint(low // 10000, high // 10000) * 10000
                         for emp in self.employees}
        self.counters = defaultdict(int)
        self.receivables, self.payables = [], []

    def month_index(self, day):
        return (day.year - self.start.year) * 12 + day.month - self.start.month + 1

    def doc(self, prefix, day):
        key = (prefix, self.month_index(day))
        self.counters[key] += 1
        return f"{prefix}-{key[1]}-{self.counters[key]}"

    def pick_day(self, low=0.1, high=0.85):
        index = int(len(self.days) * self.rng.uniform(low, high))
        return self.days[min(index, len(self.days) - 1)]


def post(ctx, book, je_type, posting, lines, description, document_id, *, source="자동",
         entered_at=None, entered_by=None, approved_by=None, approved_at=None):
    users, rng = ctx.prof["users"], ctx.rng
    entered_at = entered_at or office_stamp(rng, posting)
    if entered_by is None:
        entered_by = rng.choice(users["manual"] if source == "수기" else users["entry"])
    if approved_by is None:
        approved_by = rng.choice(users["approvers"])
    if approved_at is None:
        approved_at = default_approval(entered_at) if approved_by else ""
    return book.add(je_type=je_type, source=source, posting_date=posting, entered_at=entered_at,
                    entered_by=entered_by, approved_by=approved_by, approved_at=approved_at,
                    description=description, document_id=document_id, lines=lines)


def opening(ctx, book):
    op = ctx.prof["opening"]
    capital = op["cash"] + op["inventory"] + op["equipment"] - op["accumulated_depreciation"]
    day = next_business(ctx.start)
    lines = [line("1010", op["cash"], description="기초 잔액"),
             line("1300", op["inventory"], description="기초 잔액"),
             line("1500", op["equipment"], description="기초 잔액"),
             line("1590", credit=op["accumulated_depreciation"], description="기초 잔액"),
             line("3100", credit=capital, department=ADMIN, description="기초 잔액")]
    post(ctx, book, "기초", ctx.start, lines, "기초 잔액", "OPEN", entered_at=stamp(day, 9, 5),
         entered_by="U01", approved_by="U02")


def sale(ctx, book, posting, total=None, customer=None, sku=None, entered_at=None,
         collect=True):
    rng, prof = ctx.rng, ctx.prof
    sku = sku or rng.weighted([(key, item["share"]) for key, item in prof["products"].items()])
    product = prof["products"][sku]
    total = total or rng.loguniform(*prof["amounts"]["sale_debit_total"])
    sell = round(product["cost"] * product["markup"])
    net_target = total / (1.1 + 1 / product["markup"])
    qty = max(1, round(net_target / sell))
    unit = max(1, round(net_target / qty))
    net = qty * unit
    vat, cost = vat_of(net), qty * product["cost"]
    customer = customer or rng.choice(ctx.customers)
    doc = ctx.doc("SAL", posting)
    lines = [line("1100", net + vat, vendor=customer, description="상품 출고 및 외상매출"),
             line("5100", cost, description="상품 출고 및 외상매출"),
             line("1300", credit=cost, description="상품 출고 및 외상매출"),
             line("2100", credit=vat, description="상품 출고 및 외상매출"),
             line("4100", credit=net, description="상품 출고 및 외상매출")]
    je = post(ctx, book, "외상매출", posting, lines, "상품 출고 및 외상매출", doc,
              entered_at=entered_at)
    ctx.receivables.append(dict(je=je, doc=doc, customer=customer, gross=net + vat, net=net,
                                vat=vat, cost=cost, date=posting, returned=0, collect=collect))
    return je


def purchase(ctx, book, posting, gross=None, sku=None, vendor=None, unit_factor=None,
             invoice_id=None, invoice_date=None, qty=None, unit=None, entered_at=None,
             payable=True):
    rng, prof = ctx.rng, ctx.prof
    sku = sku or rng.weighted([(key, item["share"]) for key, item in prof["products"].items()])
    base = prof["products"][sku]["cost"]
    if qty is None:
        gross = gross or rng.loguniform(*prof["amounts"]["purchase_gross"])
        factor = unit_factor if unit_factor is not None else rng.uniform(0.93, 1.07)
        qty = max(1, round(gross / (1.1 * base * factor)))
        unit = max(1, round(gross / (1.1 * qty)))
    net = qty * unit
    vat = vat_of(net)
    vendor = vendor or rng.choice(ctx.suppliers)
    invoice_id = invoice_id or ctx.doc("PUR", posting)
    lines = [line("1200", vat, description="상품 외상매입"),
             line("1300", net, description="상품 외상매입"),
             line("2010", credit=net + vat, vendor=vendor, description="상품 외상매입")]
    je = post(ctx, book, "상품매입", posting, lines, "상품 외상매입", invoice_id,
              entered_at=entered_at)
    book.attach("supplier_invoices", je, invoice_id=invoice_id, vendor_id=vendor,
                invoice_date=invoice_date or posting, invoice_amount=net + vat,
                product_id=sku, quantity=qty, unit_price=unit, delivery_ref=invoice_id)
    if payable:
        ctx.payables.append(dict(je=je, invoice_id=invoice_id, vendor=vendor,
                                 amount=net + vat, date=posting))
    return je


def receipt(ctx, book, rec, posting, entered_at=None):
    amount = rec["gross"] - rec["returned"]
    lines = [line("1010", amount, description="매출채권 회수"),
             line("1100", credit=amount, vendor=rec["customer"], description="매출채권 회수")]
    je = post(ctx, book, "매출입금", posting, lines, "매출채권 회수",
              ctx.doc("RCP", posting), entered_at=entered_at)
    book.attach("bank_tx", je, invoice_id=rec["doc"], transaction_date=posting,
                vendor_id=rec["customer"], direction="입금", amount=amount)
    return je


def payment(ctx, book, rec, posting):
    lines = [line("2010", rec["amount"], vendor=rec["vendor"], description="매입채무 지급"),
             line("1010", credit=rec["amount"], description="매입채무 지급")]
    je = post(ctx, book, "매입지급", posting, lines, "매입채무 지급", ctx.doc("PMT", posting))
    book.attach("bank_tx", je, invoice_id=rec["invoice_id"], transaction_date=posting,
                vendor_id=rec["vendor"], direction="출금", amount=rec["amount"])
    return je


def expense(ctx, book, posting, amount=None, entered_at=None, employee=None, receipt_id=None,
            expense_date=None, **post_fields):
    rng = ctx.rng
    amount = amount or int(rng.loguniform(*ctx.prof["amounts"]["expense"]))
    employee = employee or rng.choice(ctx.employees)
    doc = receipt_id or ctx.doc("R", posting)
    lines = [line("6200", amount, department=ADMIN, description="업무 출장비 정산"),
             line("1010", credit=amount, department=ADMIN, description="업무 출장비 정산")]
    je = post(ctx, book, "경비", posting, lines, "업무 출장비 정산", doc,
              entered_at=entered_at, **post_fields)
    book.attach("expense_claims", je, employee_id=employee, receipt_id=doc,
                expense_date=expense_date or posting - timedelta(days=rng.randint(0, 3)),
                amount=amount)
    return je


def card(ctx, book, posting, amount=None, card_pair=None, vendor=None, order_ref=None,
         entered_at=None):
    rng = ctx.rng
    amount = amount or int(rng.loguniform(*ctx.prof["amounts"]["card"]))
    card_id, _ = card_pair or rng.choice(ctx.cards)
    vendor = vendor or rng.choice(ctx.suppliers)
    doc = ctx.doc("CARDTX", posting)
    order_ref = order_ref or ctx.doc("PO", posting)
    lines = [line("6200", amount, department=ADMIN, description="법인카드 구매"),
             line("2300", credit=amount, department=ADMIN, description="법인카드 구매")]
    je = post(ctx, book, "카드", posting, lines, "법인카드 구매", doc, entered_at=entered_at)
    book.attach("card_transactions", je, transaction_id=doc, card_id=card_id,
                transaction_date=posting, vendor_id=vendor,
                merchant_category=rng.choice(["5311", "5943"]), order_ref=order_ref,
                amount=amount)
    return je


def manual(ctx, book, je_type, posting, lines, description, document_id, entered_at=None,
           approved_by=None):
    return post(ctx, book, je_type, posting, lines, description, document_id, source="수기",
                entered_at=entered_at, approved_by=approved_by)


def misc_payment(ctx, book, posting, amount=None, vendor=None):
    rng = ctx.rng
    if amount is None:
        amount = int(rng.loguniform(*ctx.prof["amounts"]["misc_payment"]))
        if amount % 1000 == 0:
            amount += 137
    lines = [line("6200", amount, vendor=vendor or rng.choice(ctx.suppliers), department=ADMIN,
                  description="기타 용역비 지급"),
             line("1010", credit=amount, department=ADMIN, description="기타 용역비 지급")]
    return post(ctx, book, "기타지급", posting, lines, "기타 용역비 지급",
                ctx.doc("MISC", posting))


def payroll_month(ctx, book, posting):
    rng, fixed = ctx.rng, ctx.prof["fixed"]
    for number, employee in enumerate(ctx.employees, start=1):
        base = ctx.salaries[employee]
        bonus = 0
        if ctx.month_index(posting) % 3 == 0 and rng.random() < fixed["bonus_probability"]:
            bonus = rng.choice(fixed["bonus_choices"])
        gross = base + bonus
        withheld = gross * fixed["withholding_percent"] // 100
        doc = ctx.doc("PAY", posting)
        lines = [line("6100", gross, department=ADMIN, description="월 급여 지급"),
                 line("1010", credit=gross - withheld, department=ADMIN, description="월 급여 지급"),
                 line("2200", credit=withheld, department=ADMIN, description="월 급여 지급")]
        je = post(ctx, book, "급여", posting, lines, "월 급여 지급", doc,
                  entered_at=stamp(posting, 10, 0 + number * 3))
        book.attach("payroll", je, employee_id=employee,
                    pay_month=f"{posting.year}-{posting.month:02d}", hours=160,
                    base_salary=base, approved_bonus=bonus, gross_paid=gross)


def monthly_fixed(ctx, book, posting):
    fixed = ctx.prof["fixed"]
    payroll_month(ctx, book, posting)
    post(ctx, book, "감가상각",  posting,
         [line("6300", fixed["depreciation"], department=ADMIN, description="비품 월 감가상각"),
          line("1590", credit=fixed["depreciation"], department=ADMIN, description="비품 월 감가상각")],
         "비품 월 감가상각", ctx.doc("DEP", posting), entered_at=stamp(posting, 16, 10))
    post(ctx, book, "관리비", posting,
         [line("6400", fixed["rent"], department=ADMIN, description="월 창고 임차료"),
          line("1010", credit=fixed["rent"], department=ADMIN, description="월 창고 임차료")],
         "월 창고 임차료", ctx.doc("RENT", posting), entered_at=stamp(posting, 16, 30))


def capex(ctx, book):
    rng = ctx.rng
    for _ in range(ctx.prof["fixed"]["capex_count"]):
        day = ctx.pick_day(0.2, 0.7)
        amount = rng.randint(*(x // 50000 for x in ctx.prof["amounts"]["capex"])) * 50000
        vendor = rng.choice(ctx.suppliers)
        post(ctx, book, "설비", day,
             [line("1500", amount, description="물류 설비 매입"),
              line("2010", credit=amount, vendor=vendor, description="물류 설비 매입")],
             "물류 설비 매입", ctx.doc("CAPEX", day))


def a2_rule(book, evidence_id, kind, je_type, first, last, start, end, weekdays, journal=None):
    book.a2_rules.append(dict(evidence_id=evidence_id, kind=kind, source="자동", je_type=je_type,
                              from_date=first, to_date=last, start_time=start, end_time=end,
                              weekdays=weekdays, _je=journal))


def build_normal(ctx, book, plan):
    rng, vol = ctx.rng, ctx.prof["volume"]
    legit = ctx.prof["legit_exceptions"]
    opening(ctx, book)
    for day in ctx.days:
        for _ in range(rng.poisson(vol["sales_per_business_day"] * ctx.volume_scale)):
            sale(ctx, book, day)
        for _ in range(rng.poisson(vol["purchases_per_business_day"] * ctx.volume_scale)):
            purchase(ctx, book, day)
        for _ in range(rng.poisson(vol["expenses_per_business_day"] * ctx.volume_scale)):
            expense(ctx, book, day)
        for _ in range(rng.poisson(vol["cards_per_business_day"] * ctx.volume_scale)):
            card(ctx, book, day)
    year, month = ctx.start.year, ctx.start.month
    while (year, month) <= (ctx.end.year, ctx.end.month):
        last = month_end(year, month)
        if last <= ctx.end:
            monthly_fixed(ctx, book, next_business(last) if last.weekday() < 5
                          else last - timedelta(days=last.weekday() - 4))
        year, month = year + (month == 12), month % 12 + 1
    capex(ctx, book)
    for _ in range(legit["misc_payments_normal"]):
        misc_payment(ctx, book, ctx.pick_day())
    legit_returns(ctx, book, plan, legit["C7_sales_returns"])
    settle(ctx, book, plan, legit["A2_weekend_batch"])
    legit_misc(ctx, book, plan, legit)


def legit_returns(ctx, book, plan, count):
    if count <= 0:
        return
    rng = ctx.rng
    pool = [rec for rec in ctx.receivables if rec["date"] <= ctx.end - timedelta(days=40)
            and rec["collect"] and rec["date"] >= ctx.start]
    for rec in rng.sample(pool, max(2, count)):
        posting = rec["date"] + timedelta(days=rng.randint(4, 10))
        posting = next_business(posting)
        part = rng.uniform(0.3, 0.6)
        gross = int(rec["gross"] * part)
        net = gross * 10 // 11
        vat = gross - net
        cost = int(rec["cost"] * gross / rec["gross"])
        lines = [line("4100", net, description="매출 환입"),
                 line("2100", vat, description="매출 환입"),
                 line("1300", cost, description="매출 환입"),
                 line("1100", credit=gross, vendor=rec["customer"], description="매출 환입"),
                 line("5100", credit=cost, description="매출 환입")]
        je = post(ctx, book, "매출환입", posting, lines, "매출 환입", ctx.doc("RET", posting),
                  entered_by="U03", approved_by="U05")
        rec["returned"] += gross
        plan.exception(je, "C7", "승인된 매출 환입 (정상잔액 반대 방향 기재)")


def settle(ctx, book, plan, batch_count):
    rng, lags = ctx.rng, ctx.prof["lags"]
    receipts = []
    for rec in ctx.receivables:
        if not rec["collect"]:
            continue
        due = next_business(rec["date"] + timedelta(days=rng.randint(*lags["receipt_days"])))
        if due <= ctx.end:
            receipts.append((rec, due))
    fridays = [index for index, (_, due) in enumerate(receipts) if due.weekday() == 4]
    batch = set(rng.sample(fridays, min(batch_count, len(fridays))))
    batch_journals = []
    for index, (rec, due) in enumerate(receipts):
        if index in batch:
            saturday = due + timedelta(days=1)
            minutes = rng.randint(10 * 60, 16 * 60 + 50)
            je = receipt(ctx, book, rec, due, stamp(saturday, minutes // 60, minutes % 60))
            plan.exception(je, "A2", "토요일 정기 자동 입금 배치, 배치 일정에 등록")
            batch_journals.append(je)
        else:
            receipt(ctx, book, rec, due)
    if batch_journals:
        a2_rule(book, "LEGIT-BATCH-001", "batch", "매출입금", ctx.start.isoformat(),
                ctx.end.isoformat(), "10:00", "17:00", "5")
    for rec in ctx.payables:
        due = next_business(rec["date"] + timedelta(days=rng.randint(*lags["payment_days"])))
        if due <= ctx.end:
            payment(ctx, book, rec, due)


def legit_misc(ctx, book, plan, legit):
    rng = ctx.rng
    for number in range(1, legit["A2_after_hours_approved"] + 1):
        day = ctx.pick_day(0.2, 0.8)
        minutes = rng.randint(19 * 60 + 20, 20 * 60 + 40)
        je = expense(ctx, book, day, entered_at=stamp(day, minutes // 60, minutes % 60))
        a2_rule(book, f"LEGIT-APP-{number:03d}", "approval", "경비", day.isoformat(),
                day.isoformat(), "19:00", "21:00", str(day.weekday()), journal=je)
        plan.exception(je, "A2", "마감 지원 야간 입력, 사전 승인 기록 있음")
    for _ in range(legit["A2_weekend_no_record"]):
        friday = ctx.pick_day(0.2, 0.8)
        friday -= timedelta(days=(friday.weekday() - 4) % 7)
        friday = max(friday, ctx.days[0])
        saturday = friday + timedelta(days=1)
        if saturday.weekday() != 5 or saturday > ctx.end:
            continue
        je = expense(ctx, book, friday, entered_at=stamp(saturday, 11, rng.randint(0, 50)))
        plan.exception(je, "A2", "주말 정산 입력, 승인 증빙은 별도 서류 보관")
    for number in range(1, legit["A4_closing_adjustment"] + 1):
        amount = rng.randint(800000, 3500000)
        if amount % 1000 == 0:
            amount += 211
        entered = next_business(ctx.end + timedelta(days=rng.randint(9, 12)))
        je = manual(ctx, book, "결산조정", ctx.end,
                    [line("6200", amount, department=ADMIN, description="결산 미지급비용 계상"),
                     line("2300", credit=amount, department=ADMIN, description="결산 미지급비용 계상")],
                    "결산 미지급비용 계상", f"ADJ-CL-{number}",
                    entered_at=stamp(entered, 10, rng.randint(0, 50)), approved_by="U02")
        plan.exception(je, "A4", "결산 미지급비용 계상, 기간 종료 후 승인된 조정 입력")
    limit = ctx.prof["card_policy"]["per_transaction_limit"]
    for _ in range(legit["B2_near_limit_quote"]):
        amount = rng.randint(limit - 7000, limit - 1000)
        if amount % 1000 == 0:
            amount -= 13
        je = card(ctx, book, ctx.pick_day(), amount=amount)
        plan.exception(je, "B2", "견적서상 정상 단가가 한도 직하인 구매")
    for _ in range(legit["B6_split_delivery"]):
        day, pair, vendor = ctx.pick_day(), rng.choice(ctx.cards), rng.choice(ctx.suppliers)
        order = ctx.doc("PO", day)
        for part in range(2):
            when = next_business(day + timedelta(days=part * 2))
            je = card(ctx, book, when if when <= ctx.end else day,
                      amount=rng.randint(270000, 320000), card_pair=pair, vendor=vendor,
                      order_ref=order)
            plan.exception(je, "B6", "계약상 분할 납품에 따른 건별 결제")
    for _ in range(legit["B3_special_spec"]):
        je = purchase(ctx, book, ctx.pick_day(), sku="SKU1", unit_factor=1.45)
        plan.exception(je, "B3", "특수 규격 상품, 계약 단가가 일반 단가보다 높음")
