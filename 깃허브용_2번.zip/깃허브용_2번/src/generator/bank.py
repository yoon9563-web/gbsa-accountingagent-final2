"""Full bank statement derived from final cash (1010) journal lines, then perturbed for H1.

Own Rng stream (seed + 1299709). Like the subledger, this tests whether differences are found;
it is not an independent bank simulation. Balance file carries opening/closing balances.
"""

from datetime import timedelta

from common import Rng
from subledger import transpose


def bank_rng(seed):
    return Rng(seed + 1299709)


def derive_statement(book):
    rows = []
    for je in sorted(book.journals, key=lambda j: j.seq):
        if je.je_type == "기초":
            continue
        net = sum(item["debit"] - item["credit"] for item in je.lines if item["account"] == "1010")
        if net == 0:
            continue
        party = next((item["vendor"] for item in je.lines if item["vendor"]), "")
        rows.append(dict(_je=je, date=je.posting_date, description="입금" if net > 0 else "출금",
                         reference=je.document_id, counterparty=party, amount=net))
    return rows


def opening_balance(book):
    return sum(item["debit"] - item["credit"] for je in book.journals if je.je_type == "기초"
               for item in je.lines if item["account"] == "1010")


def perturb(ctx, book, plan, rows, counts, legit_timing, rng):
    by_je = {id(row["_je"]): row for row in rows}
    cutoff = ctx.end - timedelta(days=4)
    timing = [je for je in sorted(book.journals, key=lambda j: j.seq)
              if je.je_type == "매출입금" and je not in plan.used and je.posting_date >= cutoff
              and id(je) in by_je]
    for je in rng.sample(timing, min(legit_timing, len(timing))):
        rows.remove(by_je.pop(id(je)))
        plan.exception(je, "H1", "기말 입금 시차 (장부 기록 후 은행 반영이 다음 영업일 이후)")

    def candidates(transposable):
        found = []
        for je in sorted(book.journals, key=lambda j: j.seq):
            row = by_je.get(id(je))
            if row is None or je in plan.used or je.je_type not in ("매입지급", "매출입금", "경비", "기타지급"):
                continue
            if je.posting_date > ctx.end - timedelta(days=6):
                continue
            if transposable:
                try:
                    transpose(row["amount"])
                except ValueError:
                    continue
            found.append(je)
        return found

    pool = rng.shuffled(candidates(True))
    if len(pool) < counts["book_without_bank"] + counts["amount_differs"]:
        raise ValueError("은행 대사 주입 후보 전표가 부족합니다.")
    for je in pool[:counts["book_without_bank"]]:
        rows.remove(by_je.pop(id(je)))
        plan.anomaly(je, "H1", "bank_entry_missing_for_book", "높음", "보통")
    for je in pool[counts["book_without_bank"]:counts["book_without_bank"] + counts["amount_differs"]]:
        row = by_je[id(je)]
        row["amount"] = transpose(row["amount"])
        plan.anomaly(je, "H1", "bank_amount_differs_from_book", "중간", "어려움")
