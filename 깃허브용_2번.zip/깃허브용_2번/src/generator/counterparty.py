"""Vendor master (registration date, bank account), employee master and E1/E2 injection.

Post-hoc and independent of the earlier random streams: it uses its own Rng and only
reassigns existing purchase journals (and their payments) to newly created vendors.
Account numbers are synthetic.
"""

from datetime import timedelta

from common import Rng

BANKS = ["KB", "SH", "WR", "NH", "IBK"]


def ext_rng(seed):
    return Rng(seed + 104729)


def account(rng, used):
    while True:
        value = f"{rng.choice(BANKS)}-{rng.randint(100, 999)}-{rng.randint(100000, 999999)}"
        if value not in used:
            used.add(value)
            return value


def build_master(ctx, book, rng):
    """Base vendors and customers registered well before the period; employees with accounts."""
    used = set()
    book.vendor_master = {}
    for vendor in ctx.suppliers:
        book.vendor_master[vendor] = dict(name=f"가상공급사 {vendor[1:]}", kind="도소매·업무서비스",
                                          registered=ctx.start - timedelta(days=rng.randint(300, 1500)),
                                          account=account(rng, used))
    for customer in ctx.customers:
        book.vendor_master[customer] = dict(name=f"가상고객사 {customer[1:]}", kind="도소매",
                                            registered=ctx.start - timedelta(days=rng.randint(300, 1500)),
                                            account=account(rng, used))
    book.employee_master = {emp: dict(account=account(rng, used)) for emp in ctx.employees}
    book._used_accounts = used
    book._next_vendor = len(ctx.suppliers) + 1


def purchases_with_payment(book, plan, minimum, maximum, end_cut):
    """Unlabeled 상품매입 journals (amount in range, before end_cut) that already have a payment."""
    pay_by_invoice = {}
    for row in book.aux["bank_tx"]:
        if row["direction"] == "출금":
            pay_by_invoice[row["invoice_id"]] = row["_je"]
    invoices = {row["_je"]: row for row in book.aux["supplier_invoices"]}
    found = []
    for je in sorted(book.journals, key=lambda j: j.seq):
        row = invoices.get(je)
        if je.je_type != "상품매입" or je in plan.used or row is None or je.posting_date > end_cut:
            continue
        payment = pay_by_invoice.get(row["invoice_id"])
        if payment is None or payment in plan.used:
            continue
        if minimum <= row["invoice_amount"] <= maximum:
            found.append((je, payment, row))
    return found


def move_to_new_vendor(book, rng, purchase, payment, row, registered_days_before, kind_account=None):
    vendor = f"V{book._next_vendor}"
    book._next_vendor += 1
    for item in purchase.lines + payment.lines:
        if item["vendor"]:
            item["vendor"] = vendor
    row["vendor_id"] = vendor
    for bank in book.aux["bank_tx"]:
        if bank["_je"] is payment:
            bank["vendor_id"] = vendor
    book.vendor_master[vendor] = dict(
        name=f"가상공급사 {vendor[1:]}", kind="도소매·업무서비스",
        registered=purchase.posting_date - timedelta(days=registered_days_before),
        account=kind_account or account(rng, book._used_accounts))
    return vendor


def inject(ctx, book, plan, counts, legit, rng):
    large = (8_000_000, 25_000_000)
    small = (400_000, 3_500_000)
    end_cut = ctx.end
    need = (counts["large_new_vendor"] + legit["E1_large_with_contract"] + counts["employee_account"]
            + 2 * counts["shared_account_pairs"] + 2 * legit["E2_shared_branch_account_pairs"])
    pool_large = purchases_with_payment(book, plan, *large, end_cut)
    pool_small = purchases_with_payment(book, plan, *small, end_cut)
    if len(pool_large) < need or len(pool_small) < legit["E1_new_vendor_small"] + need:
        raise ValueError("신규 거래처로 옮길 매입 전표가 부족합니다.")
    pool_large = rng.shuffled(pool_large)
    pool_small = rng.shuffled(pool_small)

    def take(pool):
        while True:
            purchase, payment, row = pool.pop()
            if purchase not in plan.used and payment not in plan.used:
                plan.used.update({purchase, payment})
                return purchase, payment, row

    for _ in range(counts["large_new_vendor"]):
        purchase, payment, row = take(pool_large)
        move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(2, 9))
        plan.anomaly(purchase, "E1", "new_vendor_large_first_transaction", "높음", "보통")
    for _ in range(counts["employee_account"]):
        purchase, payment, row = take(pool_small)
        employee = rng.choice(list(book.employee_master))
        move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(40, 200),
                           kind_account=book.employee_master[employee]["account"])
        for je in (purchase, payment):
            plan.anomaly(je, "E2", "vendor_account_matches_employee", "높음", "어려움")
    for _ in range(counts["shared_account_pairs"]):
        shared = account(rng, book._used_accounts)
        for _ in range(2):
            purchase, payment, row = take(pool_small)
            move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(40, 200), kind_account=shared)
            for je in (purchase, payment):
                plan.anomaly(je, "E2", "vendors_share_bank_account", "중간", "보통")
    for _ in range(legit["E1_new_vendor_small"]):
        purchase, payment, row = take(pool_small)
        move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(3, 12))
        plan.exception(purchase, "E1", "신규 등록 거래처의 소액 첫 거래 (기준 금액 미만)")
    for _ in range(legit["E1_large_with_contract"]):
        purchase, payment, row = take(pool_large)
        move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(3, 10))
        plan.exception(purchase, "E1", "신규 거래처 거액 첫 거래, 계약서·실사 기록 있음")
    for _ in range(legit["E2_shared_branch_account_pairs"]):
        shared = account(rng, book._used_accounts)
        for _ in range(2):
            purchase, payment, row = take(pool_small)
            move_to_new_vendor(book, rng, purchase, payment, row, rng.randint(40, 200), kind_account=shared)
            for je in (purchase, payment):
                plan.exception(je, "E2", "같은 법인의 본점·지점 거래처가 대표 계좌를 공유 (사업자 확인됨)")
