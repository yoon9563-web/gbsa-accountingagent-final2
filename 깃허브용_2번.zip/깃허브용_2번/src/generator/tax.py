"""Tax invoices (전자세금계산서) derived from VAT lines of final journals, then perturbed for I4/F3.

Own Rng stream (seed + 15485863). Each invoice carries the linked journal id (system link).
Journals injected as duplicates still get their own invoice here (simplification).
"""

from datetime import timedelta

from common import Rng, pick
from subledger import transpose


def tax_rng(seed):
    return Rng(seed + 15485863)


def derive_invoices(book):
    rows = []
    for je in sorted(book.journals, key=lambda j: j.seq):
        def total(account, side):
            return sum(item[side] - item["credit" if side == "debit" else "debit"]
                       for item in je.lines if item["account"] == account)
        vat_out = -total("2100", "debit")
        vat_in = total("1200", "debit")
        party = next((item["vendor"] for item in je.lines if item["vendor"]), "")
        if vat_out != 0:
            rows.append(dict(_je=je, direction="매출", issue_date=je.posting_date, counterparty=party,
                             doc_ref=je.document_id, supply=-total("4100", "debit"), vat=vat_out))
        elif vat_in != 0:
            rows.append(dict(_je=je, direction="매입", issue_date=je.posting_date, counterparty=party,
                             doc_ref=je.document_id, supply=total("1300", "debit"), vat=vat_in))
    return rows


def perturb(ctx, book, plan, rows, counts, legit_lag, rng):
    by_je = {id(row["_je"]): row for row in rows}
    for je in pick(book, rng, plan, "상품매입", counts["vat_amount_differs"]):
        row = by_je[id(je)]
        row["vat"] = transpose(row["vat"])
        plan.anomaly(je, "I4", "tax_invoice_vat_differs", "중간", "어려움")
    for je in pick(book, rng, plan, "상품매입", counts["purchase_without_invoice"]):
        rows.remove(by_je.pop(id(je)))
        plan.anomaly(je, "I4", "purchase_without_tax_invoice", "높음", "보통")
    for je in pick(book, rng, plan, "외상매출", counts["sale_without_invoice"]):
        rows.remove(by_je.pop(id(je)))
        plan.anomaly(je, "F3", "sale_without_tax_invoice", "높음", "보통")
    for je in pick(book, rng, plan, "외상매출", legit_lag):
        row = by_je[id(je)]
        row["issue_date"] = je.posting_date + timedelta(days=rng.randint(3, 9))
        plan.exception(je, "I4", "세금계산서 발행일이 전기일보다 늦음 (월합계 발행 관행, 금액 일치)")
