"""Shared building blocks for the synthetic ledger generator (standard library only)."""

import csv
import hashlib
import math
import random
from datetime import date, datetime, time, timedelta, timezone

KST = timezone(timedelta(hours=9))
GENERATOR_VERSION = "0.8.0"
AUX_FILES = ("supplier_invoices", "expense_claims", "payroll", "card_transactions", "bank_tx")


class Rng:
    """Deterministic helpers built only on random.random() so streams do not depend on
    implementation details of random.choice/shuffle/sample across Python versions."""

    def __init__(self, seed):
        self._random = random.Random(seed)

    def random(self):
        return self._random.random()

    def uniform(self, low, high):
        return low + (high - low) * self.random()

    def randint(self, low, high):
        return low + int(self.random() * (high - low + 1))

    def choice(self, items):
        return items[int(self.random() * len(items))]

    def weighted(self, pairs):
        total = sum(weight for _, weight in pairs)
        point = self.random() * total
        for value, weight in pairs:
            point -= weight
            if point < 0:
                return value
        return pairs[-1][0]

    def loguniform(self, low, high):
        return math.exp(self.uniform(math.log(low), math.log(high)))

    def poisson(self, mean):
        if mean <= 0:
            return 0
        limit, count, product = math.exp(-mean), 0, self.random()
        while product > limit:
            count += 1
            product *= self.random()
        return count

    def shuffled(self, items):
        values = list(items)
        for index in range(len(values) - 1, 0, -1):
            other = self.randint(0, index)
            values[index], values[other] = values[other], values[index]
        return values

    def sample(self, items, count):
        return self.shuffled(items)[:count]


def is_business(day):
    return day.weekday() < 5


def business_days(start, end):
    days, day = [], start
    while day <= end:
        if is_business(day):
            days.append(day)
        day += timedelta(days=1)
    return days


def next_business(day):
    while not is_business(day):
        day += timedelta(days=1)
    return day


def prev_business(day):
    while not is_business(day):
        day -= timedelta(days=1)
    return day


def month_end(year, month):
    first = date(year + (month == 12), month % 12 + 1, 1)
    return first - timedelta(days=1)


def stamp(day, hour, minute):
    return datetime(day.year, day.month, day.day, hour, minute, tzinfo=KST)


def office_stamp(rng, day):
    minutes = rng.randint(9 * 60 + 10, 17 * 60 + 40)
    return stamp(day, minutes // 60, minutes % 60)


def default_approval(entered_at):
    day = entered_at.date()
    if is_business(day) and entered_at.time() < time(17, 0):
        return stamp(day, 17, 30)
    return stamp(next_business(day + timedelta(days=1)), 9, 30)


def vat_of(net):
    return (net + 5) // 10


def line(account, debit=0, credit=0, vendor="", department="영업물류", description=""):
    return {"account": account, "debit": debit, "credit": credit, "vendor": vendor,
            "department": department, "description": description}


class Journal:
    def __init__(self, order, je_type, source, posting_date, entered_at, entered_by,
                 approved_by, approved_at, description, document_id, lines):
        self.order = order
        self.je_type = je_type
        self.source = source
        self.posting_date = posting_date
        self.entered_at = entered_at
        self.entered_by = entered_by
        self.approved_by = approved_by
        self.approved_at = approved_at
        self.description = description
        self.document_id = document_id
        self.lines = lines
        self.id = None
        self.seq = None

    def debit_total(self):
        return sum(item["debit"] for item in self.lines)

    def credit_total(self):
        return sum(item["credit"] for item in self.lines)


class Book:
    def __init__(self):
        self.journals = []
        self.aux = {name: [] for name in AUX_FILES}
        self.a2_rules = []
        self.subledger = []
        self._order = 0

    def add(self, **fields):
        self._order += 1
        for item in fields.get("lines", []):
            if not item.get("description"):
                item["description"] = fields.get("description", "")
        journal = Journal(order=self._order, **fields)
        self.journals.append(journal)
        return journal

    def attach(self, name, journal, **row):
        row["_je"] = journal
        self.aux[name].append(row)

    def remove(self, journal):
        self.journals.remove(journal)
        for name in AUX_FILES:
            self.aux[name] = [row for row in self.aux[name] if row["_je"] is not journal]
        self.a2_rules = [row for row in self.a2_rules if row.get("_je") is not journal]


class Plan:
    """Answer-key bookkeeping. Written only to evaluator-only/labels/, never to the analysis input."""

    def __init__(self):
        self.anomalies = []
        self.exceptions = []
        self.used = set()

    def lock(self, journal):
        self.used.add(journal)

    def anomaly(self, journal, type_id, method, severity, concealment, line_no=""):
        self.anomalies.append(dict(journal=journal, type_id=type_id, method=method,
                                   severity=severity, concealment=concealment, line_no=line_no))
        self.used.add(journal)

    def exception(self, journal, type_id, reason):
        self.exceptions.append(dict(journal=journal, type_id=type_id, reason=reason))
        self.used.add(journal)


def pick(book, rng, plan, je_type, count, *, after=None, before=None):
    pool = [item for item in book.journals
            if item.je_type == je_type and item not in plan.used
            and (after is None or item.posting_date >= after)
            and (before is None or item.posting_date <= before)]
    if len(pool) < count:
        raise ValueError(f"{je_type} 전표가 부족해 {count}건을 고를 수 없습니다.")
    chosen = rng.sample(pool, count)
    plan.used.update(chosen)
    return chosen


def write_csv(path, header, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()
