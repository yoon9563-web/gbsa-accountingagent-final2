# evaluation/

## 자동 채점

프로젝트 루트에서 아래 명령을 실행한다. 보고서 폴더 또는 `report.json`을 지정할 수 있다.

```powershell
python -B evaluation/score_audit.py reports/20261125T033035Z-1aad2d06 --before reports/20261125T032909Z-1e8d09cf
```

기본 정답표는 2026년 1분기 더미 원장용이다. 다른 데이터셋에는 해당 원장의 정답표 폴더를 `--labels-dir`로 지정한다. 전표 ID와 유형을 비교하며 D1은 중복 그룹 전체를 확인한다. 주입 정답과 정상 예외표 어디에도 해당하지 않는 후보는 판정 대기로 표시한다. 미구현 유형과 미실행 검사를 미탐 건수에 포함하지 않는다. 일부 보조자료를 읽지 못한 검사는 부분 채점으로 표시하고 재현율 산출을 보류한다.

정답표(`evaluator-only/labels/`)와 에이전트 출력을 비교해 유형별로 평가한다 (평균 하나로 뭉뚱그리지 않는다).

| 지표 | 정의 |
|---|---|
| 유형별 재현율 | 주입한 이상 중 플래그된 비율 |
| precision@K | 위험도 상위 K건 중 실제 이상 비율 |
| 유형 분류 정확도 | 에이전트 유형ID vs 정답 (혼동행렬) |
| 위치 정확도 | 하이라이트한 라인·셀이 정답 라인과 일치하는 비율 |
| 오탐률 | 정당한 예외 중 플래그된 비율 |
| 근거 충실도 | 리포트 수치·전표ID가 도구 출력과 일치하는 비율 (목표 100%) |
| 체크리스트 유용성 | 회계사 1~5점 루브릭 (구체성, 실행 가능성, 누락) |

일반화 검증: 학계 합성 원장(Gronewald et al. 2024 DFKI, Schreyer et al. 합성 SAP, Zenodo 공개 합성 원장 등)에서 탐지기가 동작하는지 확인. 계정체계 매핑 필요.

## 생성기 산출물 채점

`src/generator/`로 만든 원장은 정답표 폴더 이름을 같게 지정한다.

```powershell
python -B evaluation/score_audit.py reports/<run_id> --labels-dir evaluator-only/labels/2026Q2-s1
```

`--clean`으로 만든 정상 기준 원장(`2026Q2-s1-clean`)은 정답표에 이상이 없고 정당한 예외만 있다. 이 원장에서 `flagged_normal`은 의도한 오탐 유도 건이고, `pending_candidates`나 A1·B4 경보가 나오면 검사기 쪽 오탐으로 본다. 주입 방식과 정당한 예외 목록은 `docs/generator.md`.

## 시험 채점
다른 사용자가 푸는 블라인드 시험은 `src/exam/grade_exam.py`로 채점한다. 사용법과 한계는 `docs/exam.md`.
