"""Score completed audit reports against the synthetic ledger labels."""

import argparse
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LABELS = ROOT / "evaluator-only/labels/2026Q1"


def read_labels(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_report(path):
    if path.is_dir():
        path = path / "report.json"
    report = json.loads(path.read_text(encoding="utf-8-sig"))
    if report["status"] != "completed":
        raise ValueError(f"검사가 완료된 보고서만 채점할 수 있습니다 ({path}).")
    return report


def members(finding):
    ids = {finding["je_id"]}
    if finding["type_id"] == "D1":
        ids.update(row["je_id"] for row in finding["evidence"].get("journals", []))
    return ids


def score(report, anomaly_rows, normal_rows):
    findings = report["findings"]
    implemented = set(report.get("implemented", ("D4", "D1", "A2")))
    implemented.difference_update(report["not_implemented"])
    skipped = report.get("skipped", {})
    types = sorted(implemented | {row["type_id"] for row in anomaly_rows + normal_rows + findings})
    results = {}
    for kind in types:
        injected = {row["je_id"] for row in anomaly_rows if row["type_id"] == kind}
        normal = {row["je_id"] for row in normal_rows if row["type_id"] == kind}
        if injected & normal:
            raise ValueError(f"{kind} 정답표와 정상 예외표에 같은 전표가 있습니다.")
        if kind not in implemented or kind in skipped:
            results[kind] = {"status": "not_run", "labeled_anomalies": len(injected)}
            continue
        if kind in report.get("population_checks", {}):
            checks = report["population_checks"][kind]
            results[kind] = {
                "status": "population_check",
                "alert_count": sum(item.get("flagged", True) for item in checks),
            }
            continue
        candidates = [members(row) for row in findings if row["type_id"] == kind]
        flagged = set().union(*candidates)
        confirmed = flagged & injected
        partial = any(key.startswith(f"{kind} · ") for key in skipped)
        results[kind] = {
            "status": "partial" if partial else "scored",
            "candidate_count": len(candidates),
            "detected": sorted(confirmed),
            "missed": sorted(injected - confirmed) if not partial else [],
            "unevaluated": sorted(injected - confirmed) if partial else [],
            "flagged_normal": sorted(flagged & normal),
            "pending_candidates": [sorted(group) for group in candidates
                                   if not group & (injected | normal)],
            "recall": len(confirmed) / len(injected) if injected and not partial else None,
        }
    return results


def compare_a2(before, after, anomaly_rows, normal_rows):
    if before["reconciliation"] != after["reconciliation"]:
        raise ValueError("대사 결과가 다른 원장은 전후 비교할 수 없습니다.")
    for report in (before, after):
        if "A2" in report.get("skipped", {}) or "A2" in report["not_implemented"]:
            raise ValueError("두 보고서 모두 A2 검사를 완료해야 합니다.")
    prior, current = (
        {row["je_id"] for row in report["findings"] if row["type_id"] == "A2"}
        for report in (before, after)
    )
    exceptions = {row["je_id"]: row["matched_records"] for row in after.get("exceptions", [])
                  if row["type_id"] == "A2"}
    anomalies = {row["je_id"] for row in anomaly_rows if row["type_id"] == "A2"}
    normals = {row["je_id"] for row in normal_rows if row["type_id"] == "A2"}
    return {
        "before_candidate_count": len(prior),
        "after_candidate_count": len(current),
        "retained_anomalies": sorted(anomalies & prior & current),
        "lost_anomalies": sorted((anomalies & prior) - current),
        "normal_exceptions_with_evidence": {key: exceptions[key]
                                            for key in sorted(normals & prior & exceptions.keys())},
        "removed_without_evidence": sorted(prior - current - exceptions.keys()),
        "new_candidates": sorted(current - prior),
    }


def main():
    parser = argparse.ArgumentParser(description="합성 원장 탐지 결과 채점")
    parser.add_argument("report", type=Path, help="최종 report.json 또는 보고서 폴더")
    parser.add_argument("--before", type=Path, help="A2 일정 적용 전 보고서")
    parser.add_argument("--labels-dir", type=Path, default=DEFAULT_LABELS)
    args = parser.parse_args()
    try:
        report = read_report(args.report)
        anomalies = read_labels(args.labels_dir / "anomaly_labels.csv")
        normals = read_labels(args.labels_dir / "normal_exceptions.csv")
        result = {"run_id": report["run_id"], "types": score(report, anomalies, normals)}
        if args.before:
            before = read_report(args.before)
            result["a2_comparison"] = compare_a2(before, report, anomalies, normals)
    except (OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        parser.exit(1, f"채점 실패 · {exc}\n")
    print(json.dumps(result, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
