"""Incident-level ranking evaluation: precision/recall of the top-K dossier incidents.

python -B evaluation/eval_incidents.py --report R/report.json --db X.sqlite --labels L.csv [--id-col je_id]
Answer keys are read here only, after detection (evaluation stage).
"""
import argparse
import csv
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src/agent"))
import dossier  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--db", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--id-col", default="je_id")
    parser.add_argument("--positive-col")
    args = parser.parse_args()
    with args.labels.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=","))
    labeled = {r[args.id_col] for r in rows if not args.positive_col or r.get(args.positive_col) == "1"}
    data = dossier.build_dossier(args.report, args.db, 50)
    top = [item["je_id"] for item in data["incidents"]]
    out = {"labeled": len(labeled), "flagged_journals": data["flagged_journal_count"]}
    for k in (10, 20, 50):
        hit = sum(j in labeled for j in top[:k])
        out[f"P@{k}"] = round(hit / min(k, len(top)), 3) if top else None
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
