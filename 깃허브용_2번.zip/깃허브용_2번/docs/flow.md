# 처리 경로와 구조 (AI용 아키텍처 정보 + 폴더 트리)

시범데이터 또는 외부 파일이 어떤 경로를 거쳐 보고서가 되는지 정리한다.

## 1. 처리 경로
```
[입력 선택]
 ① 시범데이터  data/synthetic/202601-202612-s10
 ② 비교용      data/synthetic/202601-202612-s10-clean
 ③ 외부 파일   data/raw/<이름>/  ──변환──▶  data/external/<이름>-input/
        │  (je_header.csv · je_line.csv · source_control_totals.json · 선택 보조 CSV)
        ▼
 python src/agent/demo.py [--input <폴더>] [--k 20]
   │
   ├─1 src/agent/audit.py  (결정적 코드, 읽기 전용)
   │    L0 모집단 대사(전표 수·라인 수·차변·대변 합계 vs 통제합계)
   │       └ 하나라도 다르면 중단 → 불일치 보고
   │    전표 결번·개별 전표 차대 검사(D4: 표시 후 계속)
   │    규칙·통계 탐지기 src/detectors/ (구현 29유형, 미구현 19유형은 사유 표기)
   │    임계값 config/thresholds.yaml, 유형 이름 config/type-names.json
   │    ▶ reports/<실행ID>/report.md · report.json · runs/<실행ID>.json(로그)
   │
   ├─2 src/tools/ledger_store.py build   → data/db/<폴더>.sqlite (읽기 전용 조회용)
   │
   ├─3 src/agent/dossier.py  (config/agent-review.json)
   │    플래그 → 사건 묶음(전표·거래처·입력자·패턴) → 위험도 순위(상위 K=20)
   │    유사 전표·거래처/입력자 이력·은행/세금계산서 대사(investigate.py)
   │    가설 3갈래(오류 / 부정 징후 / 정당한 예외) + 확인 방법
   │    validator.py: 근거 없는 je_id·수치·단정 표현 제거, 입력자·계좌 마스킹
   │    ▶ reports/<실행ID>/dossier.md · dossier.json
   │
   └─4 src/agent/make_pdf.py
        report.md + dossier.md → report.html → report.pdf
        (Chrome/Edge → LibreOffice → reportlab 순으로 시도, 유형은 자연어 이름)
        ▶ reports/<실행ID>/report.pdf   ← 검토자가 여는 최종 산출물
```

## 2. 계층별 책임
| 계층 | 위치 | 하는 일 | LLM 사용 |
|---|---|---|---|
| L0 무결성 | audit.py | 통제합계 대사, 결번, 차대 | 아니오 |
| L1 규칙 / L2 통계 | src/detectors/ | 유형별 플래그와 0~1 점수 | 아니오 |
| 조사 도구 | src/tools/ | 유사 전표, 이력, 대사(읽기 전용) | 아니오 |
| 사건 정리 | src/agent/dossier.py | 묶음, 순위, 가설 초안 | 규칙 기반(LLM 층은 미검증) |
| 검증 | src/agent/validator.py | 근거 없는 지적 삭제 | 아니오 |
| 보고서 | src/agent/make_pdf.py | PDF 생성 | 아니오 |

수치는 모두 코드가 계산한다. 보고서의 모든 지적은 je_id(+라인)와 근거 수치를 가진다.

## 3. 읽기·쓰기 경계
- 읽기 전용: `data/raw/`, `data/synthetic/`, `data/external/`(입력), `data/coa/`.
- 쓰기: `reports/<실행ID>/`, `runs/`, `data/db/`, 외부 변환본(`data/external/<이름>-input/`).
- 접근 금지: `evaluator-only/`(정답표, 시험 자료). 탐지·에이전트 코드는 `labels` 경로를 차단한다.
- 원장을 수정하는 도구는 없다.

## 4. 폴더 트리
```
회계에이전트/
├─ CLAUDE.md                 ← 1순위. 맨 위 "검토자 모드"가 안내서로 연결
├─ README.md                 ← 2순위. 시작 문장·파일 안내·선택지
├─ docs/
│   ├─ flow.md               ← 이 문서(처리 경로·구조·트리)
│   ├─ external-input.md     ← 외부 파일 투입 절차
│   ├─ reviewer-guide.md     ← 실행 명령·결과 설명
│   ├─ status.md · coverage.md · decisions.md · agent-design.md
│   └─ validation-dib.md · validation-plan.md · exam.md · demo.md · data-model.md · anomaly-types.md
├─ config/                   thresholds.yaml · agent-review.json · type-names.json
├─ data/
│   ├─ coa/korean_coa.csv    한국형 계정과목표
│   ├─ synthetic/
│   │   ├─ 202601-202612-s10/        ★ 시범데이터
│   │   ├─ 202601-202612-s10-clean/  ★ 비교용 정상 원장
│   │   └─ …                         개발용 더미 원장
│   ├─ external/             DIB 변환본, 외부 파일 변환본(<이름>-input/)
│   ├─ raw/                  외부 원본(읽기 전용)
│   └─ db/                   실행 중 생성되는 SQLite
├─ src/
│   ├─ agent/   demo.py · audit.py · dossier.py · validator.py · make_pdf.py · type_names.py · investigator.py
│   ├─ detectors/  review_rules.py 외 유형별 탐지기
│   ├─ tools/   ledger_store.py · investigate.py
│   ├─ generator/  더미 원장 생성
│   └─ exam/    시험 패키지 생성·채점(평가자용)
├─ evaluation/               평가 스크립트
├─ tests/                    단위 테스트
├─ reports/<날짜_실행ID>/    report.pdf · report.md · report.json · dossier.md · dossier.json
├─ runs/                     실행 로그
└─ evaluator-only/           ✖ 검토자 열람 금지(정답표·시험 자료)
```

## 5. 실행 명령 요약
| 목적 | 명령 |
|---|---|
| 시범데이터 보고서 | `python src/agent/demo.py` |
| 정상 원장 비교 | `python src/agent/demo.py --input data/synthetic/202601-202612-s10-clean` |
| 외부 파일 | `python src/agent/demo.py --input data/external/<이름>-input` |
| PDF 생략 | `--no-pdf` |
| 테스트 | `python tests/test_agent_layer.py` |
