# 외부 파일 투입 절차

시범데이터 대신 검토자가 가진 원장 파일로 탐지를 돌릴 때의 규칙이다. AI는 아래 순서로 진행한다.

## 1. 원칙
- 원본은 `data/raw/<이름>/`에 그대로 둔다(읽기 전용, 수정·삭제 금지). 변환본은 `data/external/<이름>-input/`에 만든다.
- 실제 회사 자료는 익명화·승인된 환경에서만 쓰고 외부로 전송하지 않는다. 입력자·계좌는 보고서에서 마스킹된다.
- `evaluator-only/`에는 파일을 넣지 않는다.
- 값을 지어내지 않는다. 필요한 값이 없으면 검토자에게 묻고, 그래도 없으면 해당 유형을 "미실행(데이터 부족)"으로 표시한다.

## 2. 필요한 파일 (분석 입력 폴더)
| 파일 | 필수 | 내용 |
|---|---|---|
| `je_header.csv` | 필수 | `je_id, company_code, posting_date, entered_at, entered_by, approved_by, approved_at, source, je_type, description, document_id, sequence_no` |
| `je_line.csv` | 필수 | `je_id, line_no, account_code, debit, credit, vendor_id, department, description, currency` |
| `source_control_totals.json` | 필수 | 원천 시스템의 통제합계: `journal_count, line_count, debit_total, credit_total`(정수) |
| 그 밖의 보조 CSV | 선택 | 거래처·은행·세금계산서·급여 등(`docs/data-model.md`). 없으면 해당 유형은 미실행으로 표시 |

형식 조건: 금액은 0 이상의 **정수**(원화 가정, 소수 통화는 최소 단위로 환산하고 기록), `entered_at`은 시간대 오프셋 포함 ISO 형식, 계정코드는 `data/coa/korean_coa.csv`에 있어야 한다. 열이 비어 있으면 그 열이 필요한 유형만 미실행이 된다(예: 승인자 열이 전부 비면 승인 누락 검사는 실행하지 않는다).

## 3. 진행 순서
1. **파일 확인**: 형식, 기간(몇 개월인지), 전표·라인 수, 차대 합계, 사용 가능한 열을 AI가 확인해 보고한다.
2. **변환(필요 시)**: 위 표준 형식으로 바꾼 파일을 `data/external/<이름>-input/`에 만든다. 계정 매핑이 필요하면 매핑 표를 검토자에게 보여 주고 확인받는다.
3. **통제합계 확인**: 원천 합계를 받을 수 있으면 그 값을 쓴다. 받을 수 없어 파일 자체에서 계산했다면 **독립 대조가 아니라 형식상 통과**임을 보고서에 적는다.
4. **실행**: `python src/agent/demo.py --input data/external/<이름>-input`
5. **결과 전달**: `reports/<실행ID>/report.pdf` 경로와 요약. 미실행 항목과 한계를 함께 알린다.

## 4. 기간·유형별 제약
- 12개월 미만이면 월별 추이·희소 계정 등 기간이 필요한 유형은 "추가 데이터 필요"로 표시된다.
- 모집단 대사(전표 수, 라인 수, 차대 합계)가 통제합계와 하나라도 다르면 탐지는 하지 않고 중단한다. 이때도 `reports/<실행ID>/report.pdf`에 불일치 표와 조치 안내가 나오고, 터미널에도 차이 금액이 출력된다.
- 개별 전표의 차대 불일치는 표시하고 계속 진행한다.

## 5. 이미 해 본 사례
독일 DFKI DIB 합성 원장(102,429전표)을 같은 방식으로 변환해 실행했다. 결과와 한계는 `docs/validation-dib.md`.
