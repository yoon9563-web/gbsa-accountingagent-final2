# 입력 데이터 모델

내부 표준은 관계형 테이블(SQLite 또는 Parquet). 분개 단위를 JE 헤더/라인으로 나누는 SAP 전표 구조(BKPF/BSEG)를 따른다. Beancount는 선택적 입출력 포맷으로만 둔다. 한국형 계정과목은 `data/coa/korean_coa.csv`를 쓴다.

| 테이블 | 핵심 컬럼 | 용도 |
|---|---|---|
| je_header | je_id, 회사코드, 전기일, 입력일시, 입력자, 승인자, 승인일시, 원천(수기/자동), 전표유형, 적요, 증빙번호 | 시점·사용자·승인 이상 (A, D) |
| je_line | je_id, 라인번호, 계정코드, 차변, 대변, 거래처ID, 부서, 적요, 통화 | 금액·계정 조합 이상 (B, C) |
| coa | 계정코드, 계정명, 정상잔액방향, FS표시항목, DART ID | 계정 의미·분류 기준 (C, I) |
| vendor_master | 거래처ID, 등록일, 사업자번호, 계좌, 주소, 특수관계 여부 | 거래상대방 이상 (E) |
| user_master | 사용자ID, 직위, 부서, 권한, 재직 기간 | 입력자·직무분리 (A5, A6) |
| bank_tx | 거래일, 계좌, 입출금, 금액, 상대방, 적요 | 은행조정·자금흐름 (H) |
| tax_invoice | 발행일, 공급가액, 부가세, 상대방, 연결 je_id | 매출·세금 대사 (F3, I4) |
| anomaly_labels | je_id, 라인번호, 유형ID, 주입 방식, 심각도 | 더미데이터 정답표 (탐지 단계 열람 금지) |

## 필수 규칙
1. 모집단 대사를 통과한 파일에서 개별 JE의 차변 합계와 대변 합계가 다르면 D4로 기록·보고하고 다음 단계로 넘긴다. 근거에는 전표 ID, 차변 합계, 대변 합계, 차이 금액을 포함한다.
2. 전기일과 입력일시를 분리 저장한다 (구분하지 않으면 A3·A4 판정 불가).
3. L0에서 입력 파일 전체의 전표 수, 라인 수, 차변 합계, 대변 합계를 원천 시스템의 대응 통제합계와 각각 대사한다. 하나라도 다르면 불일치 항목과 차이를 보고하고 분석을 중단한다. 이 대사를 통과한 뒤 개별 전표를 검사한다. 관련 감사기준의 국내 반영 여부는 확인이 필요하다.
4. 누락 컬럼은 허용하되, 그 컬럼이 필요한 유형은 자동으로 "데이터 부족으로 미실행" 표시.

## 플래그 출력 스키마
flag_id, je_id, line_no(널 허용), type_id, score(0~1), evidence(JSON: 계산된 수치·비교 기준·모집단 크기), detector, run_id

## 보조원장 `subledger_entries.csv`
entry_id, ledger(AR/AP), counterparty_id, doc_type, doc_ref, doc_date, je_id(원장 전표 연결), amount(잔액 증가 +). D4 보조원장 대사의 입력이며 없으면 미실행(데이터 부족)으로 보고한다. 설정은 `config/subledger-review.json`.

## 거래처·은행·세금계산서 자료
| 파일 | 열 | 쓰는 유형 |
|---|---|---|
| vendor_master.csv | vendor_id, name, business_type, registered_date, bank_account | E1, E2 |
| employee_master.csv | employee_id, bank_account | E2 |
| bank_statement.csv | bank_tx_id, tx_date, description, reference(증빙번호), counterparty_id, amount(입금 +) | H1 |
| bank_balance.json | period_start, period_end, opening_balance, closing_balance | H1 |
| tax_invoices.csv | tax_invoice_id, direction(매출·매입), issue_date, counterparty_id, doc_ref, je_id(연결 전표, 빈칸 가능), supply_amount, vat_amount | I4, F3 |
없으면 해당 유형은 미실행(데이터 부족)으로 보고한다. 설정은 `config/external-review.json`.

## SQLite 저장소
`src/tools/ledger_store.py`가 입력 폴더를 `data/db/<이름>.sqlite`로 적재한다. 위 표의 `je_header`, `je_line`, `coa`와 폴더에 있는 보조 CSV를 같은 이름의 테이블로 만들고 `control_totals`, `meta`(통제합계 대사 결과 포함)와 뷰 `v_journal_totals`를 추가한다. 정답표는 적재하지 않는다. 자세한 사용법은 `docs/generator.md`.
