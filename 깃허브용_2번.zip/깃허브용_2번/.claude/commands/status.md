---
description: 구현 현황을 점검하고 docs/status.md를 갱신한다
---

폴더의 실제 파일(src/, data/, reports/, runs/)을 확인해 docs/status.md의 완료/미구현 체크리스트를 실제 상태와 맞게 갱신하고, 다음 할 일 3개를 제시한다.
