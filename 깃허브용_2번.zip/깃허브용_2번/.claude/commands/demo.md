---
description: 시범데이터(또는 지정한 원장)로 감사를 돌리고 PDF 보고서를 만든다
argument-hint: [원장 폴더 경로, 비우면 시범데이터]
---

프로젝트 루트에서 `python src/agent/demo.py`를 실행한다. 원장 폴더가 $ARGUMENTS로 주어지면 `--input`으로 경로를 단일 인수로 안전하게 전달한다. 표준 출력 JSON의 `pdf`(보고서 PDF), `report`, `dossier` 경로를 알려 주고, `report.md`와 `investigation_dossier.md`를 읽어 대사 결과, 탐지 후보 건수, 먼저 볼 3건, 검사하지 않은 유형 수를 요약한다. PDF 변환기가 없으면 출력의 안내를 그대로 전한다. 결과는 검토 보조 자료이며 판정이 아니다. `evaluator-only/`는 읽지 않는다.
